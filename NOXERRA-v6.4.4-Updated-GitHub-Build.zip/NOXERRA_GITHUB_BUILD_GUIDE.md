# NOXERRA v6.4.4 — GitHub Actions build guide

This ZIP contains the `Erosion-CN-1.0.6` Xcode project folder and a `.github/workflows/build.yml` workflow at the ZIP root. **Import the ZIP contents into the root of your GitHub repository**, without adding another enclosing folder.

It also supports a repository where the Xcode project files have been moved directly to the root (`Erosion.xcodeproj`, `Erosion/`, `ipabuild.sh`). If using that layout, use the `.github` folder inside `Erosion-CN-1.0.6/` instead.

On iPhone: use Working Copy to clone the GitHub repository, import/extract this ZIP into the cloned repository, commit all changes including hidden `.github` folder, and push. On GitHub open **Actions → Build NOXERRA IPA → Run workflow**. Once the workflow is green, download **NOXERRA-unsigned-IPA** under Artifacts and extract the artifact ZIP to get `NOXERRA_v6.4.4_Release.ipa`.

This is an **unsigned** IPA, and it needs appropriate code signing before installation. The actual iOS build has not been executed in this environment. If it fails, download the **NOXERRA-build-log** artifact and share the first `error:` line(s).

## 2026-11-24 Swift build fix

The Xcode log reported six missing-member errors from `LiveCAPreviewView.swift`. `CamloCAStageController` only exposes a decoded `CALayer`, not a `CAStateController` or named state APIs, so the preview now uses its existing known-property animation path and removes only the real root layers on teardown. The unsupported named-state functionality was not faked.

The fixed archive also removes a hard-coded iOS 27.0 framework SDK path, aligns the reported version with 6.4.4, and packages unsigned IPAs without trying to perform ad-hoc signing. No sandbox-exploit implementation was changed.
