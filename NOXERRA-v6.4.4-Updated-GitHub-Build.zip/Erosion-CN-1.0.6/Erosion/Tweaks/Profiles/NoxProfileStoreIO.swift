// NOXERRA Profile Store IO
// Explicit, backed-up operations against the directory already exposed in NoxFiles.
// A filesystem edit is not equivalent to an iOS configuration profile installation.
import Foundation

private enum NoxProfileIOError: LocalizedError {
    case invalidLocation
    case notWritable(String)
    case verificationFailed
    case changedOnDisk
    case fileTooLarge

    var errorDescription: String? {
        switch self {
        case .invalidLocation: return "Only .stub entries or UserSettings.plist inside the ConfigurationProfiles directory are supported."
        case .notWritable(let detail): return "Write access is unavailable: \(detail)"
        case .verificationFailed: return "The file did not match the requested bytes after writing. Inspect the backup and original."
        case .changedOnDisk: return "This file changed since it was opened. Refresh before applying edits."
        case .fileTooLarge: return "This file is too large for the inline editor (256 KB limit)."
        }
    }
}

enum NoxProfileStoreIO {
    static let root = FSURL.configProfiles
    static let userSettings = root.appendingPathComponent("UserSettings.plist")
    static let maxEditableStubBytes = 256_000
    private static let fm = FileManager.default

    static func stubURL(named name: String) throws -> URL {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.utf8.count <= 200,
              !trimmed.contains("/"), !trimmed.contains("\\"),
              trimmed != ".", trimmed != "..", !trimmed.hasPrefix("."),
              trimmed.lowercased().hasSuffix(".stub") else { throw NoxProfileIOError.invalidLocation }
        return root.appendingPathComponent(trimmed, isDirectory: false)
    }

    static func validate(_ url: URL) throws {
        guard url.standardizedFileURL.deletingLastPathComponent().path == root.standardizedFileURL.path,
              url.lastPathComponent.lowercased().hasSuffix(".stub") || url.standardizedFileURL.path == userSettings.standardizedFileURL.path
        else { throw NoxProfileIOError.invalidLocation }
    }

    static func withAccess<T>(write: Bool, _ action: () throws -> T) throws -> T {
        let backend = NoxExploitSelection.current
        let path = root.path
        let wasHeld = wq.hasActiveAccess(path: path, backend: backend)
        var acquired = false
        let currentlyReadable = (try? fm.contentsOfDirectory(atPath: path)) != nil
        let currentlyWritable = fm.isWritableFile(atPath: path)
        if !currentlyReadable || (write && !currentlyWritable) {
            let granted = wq.grantAccess(path: path, requireWrite: write, backend: backend)
            acquired = !wasHeld && wq.hasActiveAccess(path: path, backend: backend)
            if !granted.0 && (write ? !fm.isWritableFile(atPath: path) : (try? fm.contentsOfDirectory(atPath: path)) == nil) {
                if acquired { wq.releaseAccess(path: path, backend: backend) }
                throw NoxProfileIOError.notWritable(granted.2)
            }
        }
        defer { if acquired { wq.releaseAccess(path: path, backend: backend) } }
        guard !write || fm.isWritableFile(atPath: path) else {
            throw NoxProfileIOError.notWritable("Directory remains read-only after the access request")
        }
        return try action()
    }

    static func read(_ url: URL, maxBytes: Int = 4_000_000) throws -> Data {
        try validate(url)
        return try withAccess(write: false) {
            let attrs = try fm.attributesOfItem(atPath: url.path)
            if (attrs[.size] as? NSNumber)?.intValue ?? 0 > maxBytes { throw NoxProfileIOError.fileTooLarge }
            return try Data(contentsOf: url)
        }
    }

    // Backups are placed in Documents so users can export them using iOS Files.
    // They are still app-local and disappear when the app itself is deleted.
    @discardableResult
    static func backup(_ url: URL) throws -> URL {
        try validate(url)
        let directory = URL.documentsDirectory
            .appendingPathComponent("NOXERRA", isDirectory: true)
            .appendingPathComponent("ProfileBackups", isDirectory: true)
        try fm.createDirectory(at: directory, withIntermediateDirectories: true)
        let filename = "\(Int(Date().timeIntervalSince1970))-\(UUID().uuidString.prefix(8))-\(url.lastPathComponent)"
        let destination = directory.appendingPathComponent(filename)
        try fm.copyItem(at: url, to: destination)
        return destination
    }

    @discardableResult
    static func write(_ data: Data, to url: URL, expectedOriginal: Data?, createNew: Bool = false) throws -> URL? {
        try validate(url)
        return try withAccess(write: true) {
            if fm.fileExists(atPath: url.path) {
                let original = try Data(contentsOf: url)
                if let expectedOriginal, original != expectedOriginal { throw NoxProfileIOError.changedOnDisk }
                if createNew { throw CocoaError(.fileWriteFileExists) }
                let backupURL = try backup(url)
                do {
                    try data.write(to: url, options: .atomic)
                    guard (try? Data(contentsOf: url)) == data else { throw NoxProfileIOError.verificationFailed }
                    return backupURL
                } catch {
                    // Best-effort rollback; always report the saved backup's path.
                    if let previous = try? Data(contentsOf: backupURL) {
                        try? previous.write(to: url, options: .atomic)
                    }
                    throw NSError(domain: "NOXERRA.ProfileStore", code: 3, userInfo: [
                        NSLocalizedDescriptionKey: "Write failed (rollback attempted): \(error.localizedDescription). Backup: \(backupURL.path)"
                    ])
                }
            } else {
                if !createNew { throw CocoaError(.fileNoSuchFile) }
                try data.write(to: url, options: .atomic)
                guard (try? Data(contentsOf: url)) == data else { throw NoxProfileIOError.verificationFailed }
                return nil
            }
        }
    }

    @discardableResult
    static func renameStub(_ source: URL, to name: String) throws -> URL {
        try validate(source)
        guard source.pathExtension.lowercased() == "stub" else { throw NoxProfileIOError.invalidLocation }
        let destination = try stubURL(named: name)
        guard source.standardizedFileURL.path != destination.standardizedFileURL.path else { return destination }
        return try withAccess(write: true) {
            guard !fm.fileExists(atPath: destination.path) else { throw CocoaError(.fileWriteFileExists) }
            _ = try backup(source)
            try fm.moveItem(at: source, to: destination)
            return destination
        }
    }

    @discardableResult
    static func deleteStub(_ source: URL) throws -> URL {
        try validate(source)
        guard source.pathExtension.lowercased() == "stub" else { throw NoxProfileIOError.invalidLocation }
        return try withAccess(write: true) {
            let saved = try backup(source)
            try fm.removeItem(at: source)
            return saved
        }
    }
}
