//
//  KeypadView.swift
//  Erosion
//
//  Created by lunginspector on 8/28/26.
//

import SwiftUI

import PhotosUI

struct KeypadView: View {
    @StateObject private var kpMgr = KeypadManager.shared
    @AppStorage("mpContainerPath") private var mpContainerPath = ""
    @State private var isReady = false
    @State private var hasAccess = false
    let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 3)
    @State private var size: KPSize = KPSize.defSize
    @State private var showSizeAlert = false
    @State private var custW = 0
    @State private var custH = 0
    @State private var showFileImporter = false
    
    var body: some View {
        ScrollView {
          VStack(spacing: 12) {
            NoxCard {
                VStack(alignment: .leading, spacing: 10) {
                    Label("PHONE KEYPAD THEMES", systemImage: "phone.arrow.up.right")
                        .font(.subheadline.weight(.heavy))
                        .foregroundStyle(NoxStyle.cyan)
                    if let url = URL(string: "https://cowabun.ga/") {
                        Link(destination: url) {
                            Label("Get Custom Phone Keypad Themes on Cowabunga", systemImage: "globe")
                                .font(.subheadline.weight(.semibold))
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .tint(NoxStyle.accent)
                    }
                    Text("Opens Cowabunga's official site. Availability of Phone keypad packs is not guaranteed.")
                        .font(.caption2)
                        .foregroundStyle(NoxStyle.pale)
                }
            }
            NoxPhoneDialerPreview(manager: kpMgr)
            VStack(alignment: .leading, spacing: 8) {
                Text("PHONE APP · THEME WORKSPACE").font(.caption.weight(.bold)).foregroundStyle(NoxStyle.accent)
                Text(mpContainerPath.isEmpty ? "Not found yet" : mpContainerPath)
                    .font(.caption2.monospaced()).textSelection(.enabled)
                Button("Re-fetch Phone Container Path") { setupPhoneContainer(forceRefresh: true) }
                .buttonStyle(.bordered)
                HStack(spacing: 8) {
                    Button("Import Theme") { showFileImporter = true }
                        .disabled(!hasAccess)
                    Button("Restore System Default") { restoreOriginalKeys() }
                        .disabled(!hasAccess)
                }.buttonStyle(.bordered)
            }
            .padding(12)
            .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 16))
            Text("Import images to customize the keypad, preview your changes below, then apply. Restore System Default returns to the original theme.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
                .frame(maxWidth: .infinity, alignment: .leading)
            HStack(spacing: 8) {
                Button("Read Current") {
                    size = .defSize
                    kpMgr.getCurrentKeypads()
                }
                .disabled(!isReady || !hasAccess)
                Button("Refresh") { setupPhoneContainer(forceRefresh: true) }
                Button("Open Phone") { openApp(withBID: SysBID.phone) }
            }
            .font(.caption)
            .buttonStyle(.bordered)
            HStack(spacing: 8) {
                Button("Crop Circular") { kpMgr.maskKeysIntoCircle(size: size, custW: custW, custH: custH) }
                Button("Clear Edits") { kpMgr.clearKeypads() }
            }
            .font(.caption)
            .buttonStyle(.bordered)
            .disabled(!isReady)
            if !isReady {
                VStack(spacing: 8) {
                    ProgressView()
                        .scaleEffect(1.25)
                    Text("Finding the Phone app container…")
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
            } else {
                LazyVGrid(columns: columns, alignment: .center, spacing: 16) {
                    ForEach($kpMgr.mpKeypad) { $item in
                        KeyItem(size: $size, kpID: item.kpID, imgData: $item.imgData)
                            .environmentObject(kpMgr)
                    }
                }
                .safeAreaInset(edge: .top) {
                    VStack(spacing: 2) {
                        Text("Keypad image size")
                        Picker("", selection: $size) {
                            ForEach(KPSize.allCases, id: \.self) { kpSize in
                                Text(kpSize.label + (kpSize == .custom ? " (\(custW)x\(custH))" : "")).tag(kpSize)
                            }
                        }
                        .alert("请输入自定义按键尺寸（像素）", isPresented: $showSizeAlert) {
                            TextField("宽度", value: $custW, format: .number)
                                .keyboardType(.numberPad)
                            TextField("高度", value: $custH, format: .number)
                                .keyboardType(.numberPad)
                            Button("取消", role: .cancel) {
                                size = .defSize
                            }
                            Button("设定") {
                                kpMgr.changeSizeOfKeypads(size: size, custW: custW, custH: custH)
                            }
                        }
                        .onChange(of: size) { _, newSize in
                            if newSize != KPSize.custom {
                                kpMgr.changeSizeOfKeypads(size: newSize)
                            } else {
                                showSizeAlert.toggle()
                            }
                        }
                    }
                    .padding(6)
                    .background(Color(.systemBackground), in: .rect(cornerRadius: cornerRad.component))
                }
                .safeAreaInset(edge: .bottom) {
                    Button {
                        let res = kpMgr.applyKeypadItems()
                        if res {
                            Alertinator.shared.alert(title: L("拨号键盘主题应用成功！"), body: KPMsg.applyComp, actionLabel: L("打开电话"), action: {
                                openApp(withBID: SysBID.phone)
                            })
                            Haptic.shared.play(.soft)
                        } else {
                            Alertinator.shared.alert(title: L("应用拨号键盘主题失败！"), body: AppMsg.opFailed)
                        }
                    } label: {
                        Image(systemName: "checkmark")
                    }
                    .buttonStyle(KeypadButtonStyle(isConfirm: true))
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding(.top, 10)
                    .disabled(!hasAccess)
                }
            }
        }
        }
        .navigationTitle("Phone App Dialer Keypad Themes")
        .frame(maxWidth: 325)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            setupPhoneContainer(forceRefresh: false)
        }
        .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.item]) { result in
            handleImport(result)
        }
    }
    
    private func restoreOriginalKeys() {
        Alertinator.shared.alert(title: "Restore system keypad?", body: KPMsg.resetWarn, actionLabel: "Restore", action: {
            let result = kpMgr.resetKeypadItems()
            if result {
                kpMgr.mpKeypad = emptyKeypadArray
                kpMgr.getCurrentKeypads()
                Alertinator.shared.alert(title: "Restored", body: "Original Phone keypad restored.")
            } else {
                Alertinator.shared.alert(title: "Restore failed", body: AppMsg.opFailed)
            }
        })
    }

    private func setupPhoneContainer(forceRefresh: Bool) {
        if forceRefresh {
            isReady = false
        }
        DispatchQueue.global(qos: .userInitiated).async {
            var targetPath = forceRefresh ? "" : mpContainerPath
            var accessOK = false
            if !targetPath.isEmpty {
                let grant = wq.grantAccess(path: targetPath)
                if grant.0 && fm.fileExists(atPath: targetPath) {
                    accessOK = true
                } else {
                    targetPath = ""
                }
            }
            if targetPath.isEmpty {
                let fetched = fsHandlers.getContainerPath(forMatch: "com.apple.mobilephone")
                if !fetched.isEmpty {
                    targetPath = fetched
                    let grant = wq.grantAccess(path: targetPath)
                    accessOK = grant.0 && fm.fileExists(atPath: targetPath)
                }
            }
            if accessOK {
                let cachesPath = "\(targetPath)/Library/Caches"
                if fm.fileExists(atPath: cachesPath) {
                    _ = wq.grantAccess(path: cachesPath)
                }
                let tpPath = "\(targetPath)/Library/Caches/TelephonyUI-10"
                if fm.fileExists(atPath: tpPath) {
                    _ = wq.grantAccess(path: tpPath)
                }
            }
            DispatchQueue.main.async {
                if !targetPath.isEmpty {
                    mpContainerPath = targetPath
                }
                hasAccess = accessOK
                if accessOK {
                    kpMgr.getCurrentKeypads(size: size, saveOgData: true)
                } else {
                    Alertinator.shared.alert(title: L("无法访问电话应用容器！"), body: L("未能定位或授权 com.apple.mobilephone 容器，请先打开一次系统“电话”应用，或在右上角菜单点击“重新获取电话容器路径”。"))
                }
                isReady = true
            }
        }
    }
    
    private struct KeyItem: View {
        @EnvironmentObject private var kpMgr: KeypadManager
        @Binding var size: KPSize
        @State var kpID: KeypadID
        @Binding var imgData: Data
        @State private var showPicker = false
        
        var body: some View {
            Button {
                showPicker = true
            } label: {
                if let img = UIImage(data: imgData) {
                    let denoVal: Float = isPad() ? 2.1 : 3.0
                    Image(uiImage: img)
                        .resizable()
                        .frame(width: CGFloat(Float(img.size.width)/denoVal), height: CGFloat(Float(img.size.height)/denoVal))
                        .background {
                            Circle()
                                .fill(Color.clear)
                                .glassEffect(.clear, in: .circle)
                                .frame(width: 78, height: 78)
                        }
                } else {
                    Image(systemName: "plus")
                        .font(.system(size: 24))
                        .frame(width: 78, height: 78)
                        .foregroundStyle(Color(.label))
                        .fontWeight(.medium)
                        .glassEffect(.clear.interactive(), in: .circle)
                }
            }
            .frame(width: 80, height: 80)
            .sheet(isPresented: $showPicker) {
                ImagePickerView() { data in
                    imgData = data
                    guard let img = UIImage(data: imgData) else { return }
                    let imgData = {
                        switch size {
                        case .defSize: return kpMgr.resizeAndRet(withData: data, isDefault: true)
                        case .custom: return kpMgr.resizeAndRet(withData: data, customSize: CGSize(width: Int(img.size.width), height: Int(img.size.height)))
                        default: return kpMgr.resizeAndRet(withData: data, newSize: size.float)
                        }
                    }()
                    kpMgr.updateKeypadItem(forID: kpID, withData: imgData, ogData: imgData)
                }
            }
        }
    }
    
    // MARK: handle import
    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .success(let fileURL):
            do {
                let stopAccess = fileURL.startAccessingSecurityScopedResource()
                defer {
                    if stopAccess {
                        fileURL.stopAccessingSecurityScopedResource()
                    }
                }
                let res = kpMgr.importTheme(fromURL: fileURL)
                if res {
                    Haptic.shared.play(.soft)
                } else {
                    throw "failed to import theme!"
                }
            } catch {
                print("(kp) failed to import theme: \(error.localizedDescription)")
                Alertinator.shared.alert(title: L("导入主题失败！"), body: AppMsg.opFailed)
            }
        case .failure(let error):
            print("(kp) failed to import file: \(error.localizedDescription)")
            Alertinator.shared.alert(title: L("导入主题失败！"), body: "\(error.localizedDescription)")
        }
    }
    
}

// MARK: UI
struct KeypadButtonStyle: ButtonStyle {
    var isConfirm = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 24))
            .frame(width: 75, height: 75)
            .foregroundStyle(Color(.label))
            .fontWeight(.medium)
            .glassEffect(.clear.tint(isConfirm ? Color.accentColor : Color.clear).interactive(), in: .circle)
    }
}


// Interactive local-only Phone dialer preview. Taps change only the demonstration number;
// the image data comes from the actual staged KeypadManager contents.
private struct NoxPhoneDialerPreview: View {
    @ObservedObject var manager: KeypadManager
    @State private var dialed = ""
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 13), count: 3)
    private let characters: [KeypadID: String] = [
        .one: "", .two: "ABC", .three: "DEF", .four: "GHI", .five: "JKL", .six: "MNO",
        .seven: "PQRS", .eight: "TUV", .nine: "WXYZ", .star: "", .zero: "+", .pound: ""
    ]

    var body: some View {
        VStack(spacing: 15) {
            HStack(spacing: 8) {
                Image(systemName: "eye.fill")
                    .foregroundStyle(NoxStyle.cyan)
                Text("LIVE THEME PREVIEW")
                    .font(.caption.weight(.heavy))
                    .tracking(1.0)
                    .foregroundStyle(NoxStyle.accent)
                Spacer(minLength: 0)
                Text("LOCAL ONLY")
                    .font(.system(size: 9, weight: .heavy))
                    .foregroundStyle(NoxStyle.pale)
            }
            HStack(spacing: 8) {
                Text(dialed.isEmpty ? "Enter a number" : dialed)
                    .font(.title3.monospacedDigit().weight(.medium))
                    .foregroundStyle(dialed.isEmpty ? NoxStyle.pale : .white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .frame(maxWidth: .infinity, alignment: .center)
                Button {
                    if !dialed.isEmpty { dialed.removeLast() }
                } label: {
                    Image(systemName: "delete.left")
                        .font(.headline)
                        .foregroundStyle(NoxStyle.pale)
                }
                .accessibilityLabel("Delete preview digit")
            }
            .padding(.horizontal, 12)
            .frame(height: 53)
            .background(NoxStyle.background.opacity(0.94), in: RoundedRectangle(cornerRadius: 14))
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(KeypadID.allCases, id: \.rawValue) { key in
                    Button {
                        if dialed.count < 22 { dialed += keyString(key) }
                    } label: {
                        ZStack {
                            Circle()
                                .fill(RadialGradient(colors: [NoxStyle.accent.opacity(0.30), NoxStyle.surface, NoxStyle.background], center: .topLeading, startRadius: 0, endRadius: 83))
                            Circle()
                                .stroke(NoxStyle.accent.opacity(0.60), lineWidth: 1.1)
                            if let data = manager.mpKeypad.first(where: { $0.kpID == key })?.imgData,
                               let image = UIImage(data: data) {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 69, height: 69)
                                    .clipShape(Circle())
                            } else {
                                VStack(spacing: 1) {
                                    Text(keyString(key))
                                        .font(.system(size: 28, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white)
                                    Text(characters[key] ?? "")
                                        .font(.system(size: 9, weight: .medium))
                                        .tracking(1.1)
                                        .foregroundStyle(NoxStyle.pale)
                                }
                            }
                        }
                        .frame(width: 75, height: 75)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Preview \(keyString(key))")
                }
            }
            Image(systemName: "phone.fill")
                .font(.title2)
                .foregroundStyle(.white)
                .frame(width: 65, height: 65)
                .background(Color.green, in: Circle())
                .accessibilityLabel("Preview only, does not place a call")
            Text("Preview updates when you import or edit keys. Dialing here never calls a number. Apply below to write the theme to Phone.")
                .font(.caption2)
                .foregroundStyle(NoxStyle.pale)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(16)
        .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(NoxStyle.accent.opacity(0.45), lineWidth: 1))
    }

    private func keyString(_ key: KeypadID) -> String {
        switch key {
        case .one: return "1"
        case .two: return "2"
        case .three: return "3"
        case .four: return "4"
        case .five: return "5"
        case .six: return "6"
        case .seven: return "7"
        case .eight: return "8"
        case .nine: return "9"
        case .star: return "*"
        case .zero: return "0"
        case .pound: return "#"
        }
    }
}
