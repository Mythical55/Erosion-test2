//
//  FileHelpers.swift
//  Filos
//
//  Created by lunginspector on 7/22/26.
//

import SwiftUI
import ZIPFoundation
import UniformTypeIdentifiers

extension FileManager {
    func createDirectoryIfNeeded(at url: URL) throws {
        if !self.fileExists(atPath: url.path) {
            try self.createDirectory(at: url, withIntermediateDirectories: true)
        }
    }
}

func getFileDict(_ url: URL) -> [String : Any]? {
    if let data = try? Data(contentsOf: url),
       let dict = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String : Any] {
        return dict
    }
    
    return nil
}

func getFileText(_ url: URL) -> String {
    do {
        let data = try Data(contentsOf: url)
        
        if let text = String(data: data, encoding: .utf8) {
            return text
        }
        
        return String(decoding: data, as: UTF8.self)
    } catch {
        print("(fm) failed to get text! path: \(error.localizedDescription)")
        return ""
    }
}

func makeTemp(_ fileURL: URL) -> URL? {
    do {
        let neededAccess = fileURL.startAccessingSecurityScopedResource()
        defer {
            if neededAccess {
                fileURL.stopAccessingSecurityScopedResource()
            }
        }
        
        let tempURL = URL.temporaryDirectory.appendingPathComponent("\(fileURL.lastPathComponent)")
        if fm.fileExists(atPath: tempURL.path) {
            try fm.removeItem(at: tempURL)
        }
        try fm.copyItem(at: fileURL, to: tempURL)
        return tempURL
    } catch {
        print("(fm) failed to make temp: \(error.localizedDescription)")
    }
    return nil
}

func generateNavPath(path: String) -> String {
    if !path.contains("/") || path.isEmpty {
        return ""
    }
    
    let file = getFileItem(at: URL(fileURLWithPath: path))
    
    if file.type == .folder || file.type == .symlink {
        return path
    }
    
    if file.type == .file {
        let navPath = URL(fileURLWithPath: path).deletingLastPathComponent().path
        return navPath
    }
    return ""
}

func renameFile(_ url: URL, to newName: String) -> Bool {
    let trimmed = newName.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !trimmed.isEmpty, !trimmed.contains("/"), trimmed != ".", trimmed != ".." else {
        return false
    }
    do {
        let targetURL = url.deletingLastPathComponent().appendingPathComponent(trimmed)
        guard targetURL != url else { return true }
        guard !fm.fileExists(atPath: targetURL.path) else {
            print("(fm) rename refused: target already exists")
            return false
        }
        // Atomic POSIX rename() via moveItem — never delete original before writing (SEC-M4-07)
        try fm.moveItem(at: url, to: targetURL)
        return true
    } catch {
        print("(fm) failed to rename file: \(error.localizedDescription)")
    }
    return false
}

func zipFile(_ url: URL) -> Bool {
    do {
        let zipDest = url
            .deletingLastPathComponent()
            .appendingPathComponent(url.lastPathComponent + ".zip")
        try FileManager.default.zipItem(at: url, to: zipDest, shouldKeepParent: true)
        return true
    } catch {
        print("(fm) failed to zip file: \(error.localizedDescription)")
    }
    return false
}

func unzipFile(_ url: URL) -> Bool {
    do {
        guard let archive = try? Archive(url: url, accessMode: .read) else {
            throw L("无法读取 ZIP 压缩包！")
        }
        let unzipDest = url.deletingLastPathComponent().standardizedFileURL
        let destPrefix = unzipDest.path.hasSuffix("/") ? unzipDest.path : unzipDest.path + "/"
        for entry in archive {
            let entryPath = entry.path
            if entryPath.hasPrefix("/") || entryPath.split(separator: "/").contains("..") || entryPath.split(separator: "\\").contains("..") {
                throw L("检测到压缩包包含非法路径穿越条目 (\(entryPath))，已拒绝解压！")
            }
            let resolvedPath = unzipDest.appendingPathComponent(entryPath).standardizedFileURL.path
            if resolvedPath != unzipDest.path && !resolvedPath.hasPrefix(destPrefix) {
                throw L("检测到压缩包条目越界 (\(entryPath))，已拒绝解压！")
            }
        }
        try fm.createDirectory(at: unzipDest, withIntermediateDirectories: true)
        try fm.unzipItem(at: url, to: unzipDest)
        return true
    } catch {
        print("(fm) failed to uncompress file: \(error.localizedDescription)")
    }
    return false
}

func duplicateFile(_ url: URL) -> Bool {
    do {
        let targetURL = {
            if url.pathExtension == "" {
                return url
                    .deletingLastPathComponent()
                    .appendingPathComponent("\(url.deletingPathExtension().lastPathComponent)_copy")
            }
            return url
                .deletingLastPathComponent()
                .appendingPathComponent("\(url.deletingPathExtension().lastPathComponent)_copy.\(url.pathExtension)")
        }()
        let data = try Data(contentsOf: url)
        try data.write(to: targetURL)
        return true
    } catch {
        print("(fm) failed to duplicate file: \(error.localizedDescription)")
    }
    return false
}

func copyFileToClipboard(_ url: URL) -> Bool {
    do {
        guard let tempURL = makeTemp(url) else {
            throw "failed to make temp!"
        }
        let data = try Data(contentsOf: tempURL)
        let utType = UTType(filenameExtension: tempURL.pathExtension) ?? .data
        
        UIPasteboard.general.setData(data, forPasteboardType: utType.identifier)
        return true
    } catch {
        print("(fm) failed to copy file: \(error.localizedDescription)")
    }
    return false
}

func conformsToPlistViewer(_ url: URL) -> Bool {
    do {
        guard let data = try? Data(contentsOf: url) else { return false }
        let _ = try PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? [String : Any]
        return true
    } catch {
        return false
    }
}

func conformsToTextViewer(_ url: URL) -> Bool {
    do {
        let _ = try String(contentsOf: url, encoding: .utf8)
        return true
    } catch {
        return false
    }
}
