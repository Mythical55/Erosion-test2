import Foundation

/// Provides descriptions for legacy MobileGestalt controls that did not include an info sheet.
/// Existing detailed Erosion warnings always take precedence.
enum NoxMGHelp {
    static func explanation(for label: String) -> String {
        let s = label.lowercased()
        if s.contains("灵动岛") || s.contains("island") { return "Dynamic Island changes the device capability flags reported to supported system interfaces. Appearance and stability depend on the hardware and iOS release. Create a verified MobileGestalt backup first." }
        if s.contains("全天候") || s.contains("aod") { return "Always-On Display enables related configuration flags. The hardware may not support this feature, and some versions ignore the override." }
        if s.contains("充电") || s.contains("battery") { return "This exposes battery or charging capability flags. It does not physically add charging or battery hardware functions." }
        if s.contains("开机提示音") { return "Enables the startup chime capability on supported devices. A restart may be required." }
        if s.contains("srd") || s.contains("安全研究") { return "Security Research Device interface flag. This does not turn a retail iPhone into an Apple security research device." }
        if s.contains("地区") || s.contains("region") || s.contains("销售") { return "Region and sales-region settings may affect regional service eligibility, regulatory behavior and device identification. Keep a clean backup before applying; many restrictions are checked elsewhere in iOS." }
        if s.contains("camera") || s.contains("相机") { return "Camera-related capability switch. Availability depends on your camera hardware, firmware and iOS version." }
        if s.contains("pencil") || s.contains("手写") { return "Apple Pencil and handwriting-related settings. A configuration flag cannot add unsupported hardware." }
        if s.contains("face") || s.contains("wapi") || s.contains("wifi") || s.contains("wi-fi") || s.contains("无线") { return "Wireless or regional network capability flag. Changing it may affect the Wi-Fi/WAPI settings shown by the system; inspect the device-specific warning before applying." }
        if s.contains("ipad") || s.contains("分屏") || s.contains("台前调度") { return "iPad-like interface capability flag. On iPhones this can be incompatible with SpringBoard and can prevent a normal boot. NOXERRA preserves original protective checks." }
        if s.contains("智能") || s.contains("intelligence") || s.contains("ai") { return "Apple Intelligence and internal feature flags depend on hardware, language, region and server-side eligibility. Toggling a flag does not guarantee functionality." }
        if s.contains("操作按钮") || s.contains("action") { return "Action Button configuration flags require compatible physical hardware. The toggle cannot create a missing button." }
        if s.contains("crash") || s.contains("车祸") { return "Crash Detection UI capability flag. This does not add motion-sensing hardware and must never be relied on to provide emergency detection." }
        return "MobileGestalt changes the capabilities iOS reports about this device. The option may require a respring or reboot and may be unsupported on your hardware or iOS version. Export a verified backup before applying; use Factory Restore to recover supported original values."
    }
}
