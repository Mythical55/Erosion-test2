import SwiftUI
import UIKit
import AVFoundation

enum NoxStyle {
    static let accent = Color(red: 0.75, green: 0.28, blue: 1.0)
    static let violet = Color(red: 0.42, green: 0.23, blue: 1.0)
    static let cyan = Color(red: 0.22, green: 0.91, blue: 0.98)
    static let background = Color(red: 0.034, green: 0.023, blue: 0.068)
    static let surface = Color(red: 0.087, green: 0.062, blue: 0.145)
    static let pale = Color(red: 0.76, green: 0.71, blue: 0.86)
    static let glow = LinearGradient(colors: [accent, violet, cyan.opacity(0.65)], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let electricBorder = LinearGradient(colors: [accent.opacity(0.85), cyan.opacity(0.26), violet.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing)
}

// Centralized visual tokens: a single user preference controls neon strength everywhere.
struct NoxAmbientBackground: View {
    @AppStorage("noxNeonGlow") private var neon = true
    var body: some View {
        ZStack {
            NoxStyle.background
            if neon {
                RadialGradient(colors: [NoxStyle.violet.opacity(0.26), .clear], center: .topLeading, startRadius: 15, endRadius: 410)
                RadialGradient(colors: [NoxStyle.cyan.opacity(0.10), .clear], center: .bottomTrailing, startRadius: 20, endRadius: 330)
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct NoxCard<Content: View>: View {
    @AppStorage("noxNeonGlow") private var neon = true
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }
    var body: some View {
        content
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(17)
            .background {
                RoundedRectangle(cornerRadius: 22)
                    .fill(LinearGradient(colors: [NoxStyle.surface, NoxStyle.background.opacity(0.96)], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
            .overlay {
                RoundedRectangle(cornerRadius: 22)
                    .strokeBorder(neon ? NoxStyle.electricBorder : LinearGradient(colors: [NoxStyle.pale.opacity(0.22)], startPoint: .top, endPoint: .bottom), lineWidth: neon ? 1.05 : 0.7)
            }
            .shadow(color: neon ? NoxStyle.accent.opacity(0.17) : .clear, radius: 14, y: 5)
    }
}

@MainActor
final class NoxSound {
    static let shared = NoxSound()
    private var player: AVAudioPlayer?
    func playTap() {
        guard UserDefaults.standard.object(forKey: "noxSoundEffects") as? Bool ?? true else { return }
        guard let asset = NSDataAsset(name: "NoxTap") else { return }
        do {
            let next = try AVAudioPlayer(data: asset.data)
            next.volume = 0.65
            next.prepareToPlay()
            next.play()
            player = next
        } catch { print("[sound] Unable to play tap: \(error.localizedDescription)") }
    }
}
