# NOXERRA — integrated Tendie Maker (experimental)

**Where:** Tweaks → Custom Wallpapers (PosterBoard) → **Create .tendies from Video**

The new screen supports:
- Import a source video from Photos (`PHPickerViewController`) or Files.
- Choose **Cover**, **Fit**, or **Native** framing, then enter a wallpaper name.
- Extract up to 400 JPEG animation frames at 12 fps, with a maximum duration of approximately 33 seconds; audio is omitted.
- Build a `.tendies` ZIP package with PosterBoard descriptor metadata and CoreAnimation `main.caml` sequence.
- Save/share the generated package, or import it into NOXERRA's existing PosterBoard wallpaper list.

The original app's `.tendies` importer, MobileGestalt, File Manager, and sandbox handling are unchanged by this feature. The builder only reads input video and writes to NOXERRA's own temporary and Documents folders. Applying the generated wallpaper still uses Erosion's existing PosterBoard workflow.

## Important verification boundary

- The uploaded `tendiemaker-1.0.11.zip` includes a README and sample packages, but **does not contain the Swift engine files** mentioned in its README.
- Therefore this is a new native generator written for NOXERRA based on publicly distributed `.tendies` package examples, **not** a verbatim port of Tendie Maker's code.
- Swift files passed a syntax *parser* check on Linux. We cannot run Xcode/iOS, so the Swift type check, IPA build, frame extraction, animation rendering, and PosterBoard compatibility **remain unverified**.
- Generated `.tendies` packs may not work on every OS/device, particularly with HDR or unsupported codecs. Test a short SDR video first.
- The generated package is saved in the app Documents directory under `NOXERRA Tendies` for reuse, and can be shared from the new screen.

## Sources / acknowledgements

The `.tendies` archive layout was modeled from sample packages distributed with **Tendie Maker** by Miguel Villarroel (MIT-licensed archive, 2026). Their samples and documentation informed the metadata format; no missing app source files were invented or represented as imported.

The original Erosion-CN source retains its license and upstream attribution. Consult the root license files when redistributing this derivative.
