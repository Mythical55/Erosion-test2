import SwiftUI
import Foundation
import Combine
import UIKit

struct NoxShellLine: Identifiable {
    let id = UUID()
    let text: String
    let isCommand: Bool
    let isError: Bool
}

/// Built-in shell-like interpreter. It does not spawn a Unix shell or claim root.
/// Commands perform real FileManager operations subject to iOS sandbox rights.
@MainActor
final class NoxShellEngine: ObservableObject {
    @Published private(set) var directory = URL.documentsDirectory.standardizedFileURL.path
    @Published private(set) var lines: [NoxShellLine] = [
        NoxShellLine(text: "NOXERRA NoxShell 1.0 · Type help for commands", isCommand: false, isError: false),
        NoxShellLine(text: "File commands use real iOS permissions; selected exploit engine requests container access.", isCommand: false, isError: false)
    ]
    @Published private(set) var history: [String] = []
    private struct OwnedGrant: Hashable {
        let path: String
        let backend: NoxExploitBackend
    }
    private var ownedGrants: Set<OwnedGrant> = []
    private let fm = FileManager.default
    private let maxOutput = 1000

    func submit(_ raw: String) {
        let input = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !input.isEmpty else { return }
        history.append(input)
        if history.count > 80 { history.removeFirst() }
        append("nox@iphone:\(shortDirectory)$ \(input)", command: true)
        do {
            let args = try tokenize(input)
            guard let command = args.first?.lowercased() else { return }
            try execute(command, Array(args.dropFirst()))
        } catch {
            append("Error: \(error.localizedDescription)", error: true)
        }
    }

    func clear() { lines.removeAll() }

    func releaseOwnedGrants() {
        for grant in ownedGrants { wq.releaseAccess(path: grant.path, backend: grant.backend) }
        ownedGrants.removeAll()
    }

    var shortDirectory: String {
        if directory == URL.documentsDirectory.standardizedFileURL.path { return "~" }
        return URL(fileURLWithPath: directory).lastPathComponent
    }

    private func execute(_ command: String, _ args: [String]) throws {
        switch command {
        case "help":
            append("NAVIGATION  pwd, cd [dir], ls [-a] [dir], find [dir] [name]")
            append("FILES       touch <file>, mkdir [-p] <dir>, cat <file>, head [-n N] <file>, stat <path>")
            append("OPERATIONS  cp <src> <dst>, mv <src> <dst>, trash <path>, rm <path> (trash alias)")
            append("RECOVERY    trash list, trash restore <ID>")
            append("ACCESS      access run | compare | report | status | grant <path> | release <path>")
            append("ENGINE      wq or bq run | report | status | grant <path> | release <path>")
            append("UTILITY     whoami, uname, date, history, clear, echo <text>, help")
            append("No sudo, chmod, pipes, shell scripts or unrestricted root access.")
        case "pwd": append(directory)
        case "whoami": append("noxerra · running with app sandbox permissions")
        case "uname": append("\(UIDevice.current.systemName) \(UIDevice.current.systemVersion) · \(UIDevice.current.model)")
        case "date": append(Date().formatted(date: .complete, time: .standard))
        case "echo": append(args.joined(separator: " "))
        case "history": for (i, value) in history.enumerated() { append("\(i + 1)  \(value)") }
        case "clear": clear()
        case "cd":
            guard args.count <= 1 else { throw problem("Usage: cd [directory]") }
            let url = resolve(args.first ?? "~")
            try requireReadable(url)
            try requireDirectory(url)
            directory = url.path
            append(directory)
        case "ls":
            let displayHidden = args.contains("-a") || args.contains("-la") || args.contains("-al")
            let paths = args.filter { !$0.hasPrefix("-") }
            guard paths.count <= 1 else { throw problem("Usage: ls [-a] [directory]") }
            let url = resolve(paths.first ?? ".")
            try requireReadable(url)
            try requireDirectory(url)
            let contents = try fm.contentsOfDirectory(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: displayHidden ? [] : [.skipsHiddenFiles])
            if contents.isEmpty { append("(empty)") }
            for entry in contents.sorted(by: { $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending }).prefix(200) {
                let isDir = (try? entry.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
                append((isDir ? "📁 " : "    ") + entry.lastPathComponent + (isDir ? "/" : ""))
            }
            if contents.count > 200 { append("... limited to 200 entries") }
        case "touch":
            guard args.count == 1 else { throw problem("Usage: touch <filename>") }
            let url = resolve(args[0])
            try ensureParentWritable(url)
            if fm.fileExists(atPath: url.path) {
                try fm.setAttributes([.modificationDate: Date()], ofItemAtPath: url.path)
            } else if !fm.createFile(atPath: url.path, contents: Data()) {
                throw problem("Could not create \(url.path); check write permission.")
            }
            append("✓ \(url.path)")
        case "mkdir":
            let recursive = args.contains("-p")
            let paths = args.filter { $0 != "-p" }
            guard paths.count == 1 else { throw problem("Usage: mkdir [-p] <directory>") }
            let url = resolve(paths[0])
            try ensureParentWritable(url, recursive: recursive)
            try fm.createDirectory(at: url, withIntermediateDirectories: recursive)
            append("✓ Created \(url.path)")
        case "cat":
            guard args.count == 1 else { throw problem("Usage: cat <file>") }
            let url = resolve(args[0]); try requireReadable(url)
            let data = try Data(contentsOf: url, options: .mappedIfSafe)
            guard data.count < 128 * 1024, let text = String(data: data, encoding: .utf8) else {
                throw problem("Not a small UTF-8 text file (limit: 128 KB). Use Files to inspect it.")
            }
            append(text.isEmpty ? "(empty file)" : text)
        case "head":
            var count = 12
            var p = args
            if p.count >= 2 && p[0] == "-n" {
                count = min(100, max(1, Int(p[1]) ?? 12)); p.removeFirst(2)
            }
            guard p.count == 1 else { throw problem("Usage: head [-n 12] <file>") }
            let url = resolve(p[0]); try requireReadable(url)
            let data = try Data(contentsOf: url, options: .mappedIfSafe)
            guard data.count < 256 * 1024, let content = String(data: data, encoding: .utf8) else { throw problem("Text file too large or not UTF-8.") }
            append(content.components(separatedBy: .newlines).prefix(count).joined(separator: "\n"))
        case "stat":
            guard args.count == 1 else { throw problem("Usage: stat <path>") }
            let url = resolve(args[0]); try requireReadable(url)
            let attrs = try fm.attributesOfItem(atPath: url.path)
            append("Path: \(url.path)")
            append("Type: \(attrs[.type] ?? "unknown")")
            append("Size: \(attrs[.size] ?? 0) bytes")
            append("Modified: \(attrs[.modificationDate] ?? "unknown")")
            append("Read: \(fm.isReadableFile(atPath: url.path)) · Write: \(fm.isWritableFile(atPath: url.path))")
        case "cp", "mv":
            guard args.count == 2 else { throw problem("Usage: \(command) <source> <destination>") }
            let source = resolve(args[0]); let destination = resolve(args[1])
            try requireReadable(source)
            try ensureParentWritable(destination)
            guard !fm.fileExists(atPath: destination.path) else { throw problem("Destination already exists; refusing to overwrite.") }
            guard NoxTrash.shared.canTrash(source) else { throw problem("Cannot change this protected source path.") }
            if command == "cp" { try fm.copyItem(at: source, to: destination) }
            else { try fm.moveItem(at: source, to: destination) }
            append("✓ \(command == "cp" ? "Copied" : "Moved") → \(destination.path)")
            ErosionManager.shared.refreshFiles.toggle()
        case "rm", "trash":
            if args.first == "list" && command == "trash" {
                let list = NoxTrash.shared.entries
                if list.isEmpty { append("NoxTrash is empty.") }
                for item in list.prefix(50) { append("\(item.id.uuidString.prefix(8))  \(item.displayName)  ←  \(item.originalPath)") }
                return
            }
            if args.count == 2 && args[0] == "restore" && command == "trash" {
                let item = try NoxTrash.shared.restore(matching: args[1])
                append("✓ Restored \(item.originalPath)")
                ErosionManager.shared.refreshFiles.toggle()
                return
            }
            guard args.count == 1 else { throw problem("Usage: trash <path> | trash list | trash restore <ID>") }
            let url = resolve(args[0])
            let item = try NoxTrash.shared.moveToTrash(url)
            append("✓ Moved to NoxTrash: \(item.displayName) [\(item.id.uuidString.prefix(8))]")
            ErosionManager.shared.refreshFiles.toggle()
        case "find":
            guard args.count <= 2 else { throw problem("Usage: find [directory] [name fragment]") }
            let url = resolve(args.first ?? ".")
            let fragment = args.count > 1 ? args[1] : ""
            try requireReadable(url); try requireDirectory(url)
            let enumerator = fm.enumerator(at: url, includingPropertiesForKeys: [.isDirectoryKey], options: [.skipsPackageDescendants], errorHandler: { _, _ in true })
            var scanned = 0; var matches = 0
            while let found = enumerator?.nextObject() as? URL, scanned < 300 {
                scanned += 1
                if fragment.isEmpty || found.lastPathComponent.localizedCaseInsensitiveContains(fragment) {
                    append(found.path); matches += 1
                    if matches >= 60 { break }
                }
            }
            append("\(matches) shown · scanned \(scanned) items (max 300)")
        case "access": try accessQuery(args, backend: NoxExploitSelection.current)
        case "wq": try accessQuery(args, backend: .worseQuery)
        case "bq": try accessQuery(args, backend: .badQuery)
        default: throw problem("Unknown command '\(command)'. Try help.")
        }
    }

    private func accessQuery(_ args: [String], backend: NoxExploitBackend) throws {
        let name = backend == .badQuery ? "bq" : "wq"
        guard let action = args.first else { throw problem("Usage: access/wq/bq run | compare | report | status | grant <path> | release <path>") }
        switch action {
        case "compare":
            guard args.count == 1 else { throw problem("Usage: access compare") }
            let launcher = NoxExploitLauncher.shared
            guard !launcher.isRunning else { throw problem("An access check is already running.") }
            launcher.compareEngines()
            append("Comparing Bad Query and Worse Query. Temporary launcher grants are released between tests.")
        case "status":
            append("Selected Home engine: \(NoxExploitSelection.current.displayName)")
            append("This command uses: \(backend.displayName)")
            if backend == .worseQuery {
                append("Worse Query OS rule: \(isWorseQueryPatchedOS() ? "patched/unverified" : "potentially supported")")
            } else {
                append("Bad Query: experimental PoC; real access must be verified per path.")
            }
            append("NoxShell-owned \(name) grants: \(ownedGrants.filter { $0.backend == backend }.count)")
        case "run":
            guard args.count == 1 else { throw problem("Usage: \(name) run") }
            let launcher = NoxExploitLauncher.shared
            guard !launcher.isRunning else { throw problem("A launcher check is already running. Open Access Center for progress.") }
            launcher.run(engine: backend)
            append("Started \(backend.displayName) three-target check. See Access Center for live results.")
        case "report":
            guard args.count == 1 else { throw problem("Usage: \(name) report") }
            let launcher = NoxExploitLauncher.shared
            let checks = launcher.reports(for: backend)
            guard !checks.isEmpty else {
                append("No launcher report for \(backend.displayName). Run 'access run' or '\(name) run'.")
                return
            }
            append("\(backend.displayName): \(checks.filter(\.readable).count)/3 readable; \(checks.filter(\.newAccessVerified).count) newly verified")
            for report in checks {
                append("\(report.target.rawValue): \(report.stateText) — \(report.message)")
            }
        case "grant":
            guard args.count == 2 else { throw problem("Usage: \(name) grant <absolute path>") }
            let path = resolve(args[1]).path
            let wasActive = wq.hasActiveAccess(path: path, backend: backend)
            let result = wq.grantAccess(path: path, requireWrite: false, backend: backend)
            guard result.0 else { throw problem("\(backend.displayName): \(result.2)") }
            if !wasActive { ownedGrants.insert(OwnedGrant(path: path, backend: backend)) }
            append("✓ \(result.2) \(path)")
        case "release":
            guard args.count == 2 else { throw problem("Usage: \(name) release <path>") }
            let path = resolve(args[1]).path
            let grant = OwnedGrant(path: path, backend: backend)
            guard ownedGrants.contains(grant) else { throw problem("No NoxShell-owned \(backend.displayName) grant for that path.") }
            wq.releaseAccess(path: path, backend: backend)
            ownedGrants.remove(grant)
            append("✓ Released \(backend.displayName) access to \(path)")
        default: throw problem("Usage: access/wq/bq run | compare | report | status | grant <path> | release <path>")
        }
    }

    private func eligibleForAccess(_ path: String) -> Bool {
        let roots = [FSPaths.appContainers, FSURL.appPlugins.path, FSURL.appGroup.path,
                     FSURL.internalDaemons.path, FSURL.sysGroup.path, FSURL.systemData.path]
        return roots.contains { path == $0 || path.hasPrefix($0 + "/") }
    }

    private func requireReadable(_ url: URL) throws {
        if fm.isReadableFile(atPath: url.path) { return }
        let path = FMNavigationStore.canonicalPath(url.path)
        if eligibleForAccess(path) {
            let alreadyActive = wq.hasActiveAccess(path: path)
            let result = wq.grantAccess(path: path, requireWrite: false)
            if result.0 && !alreadyActive { ownedGrants.insert(OwnedGrant(path: path, backend: NoxExploitSelection.current)) }
        }
        guard fm.isReadableFile(atPath: url.path) else { throw problem("Permission denied: \(url.path). Try access status / access grant for eligible container paths.") }
    }

    private func requireDirectory(_ url: URL) throws {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else {
            throw problem("Not an accessible directory: \(url.path)")
        }
    }

    private func ensureParentWritable(_ url: URL, recursive: Bool = false) throws {
        let parent = url.deletingLastPathComponent()
        var candidate = parent
        if recursive {
            // The nearest existing ancestor needs write permission.
            while !fm.fileExists(atPath: candidate.path) && candidate.path != "/" {
                candidate.deleteLastPathComponent()
            }
        }
        try requireReadable(candidate)
        try requireDirectory(candidate)
        if !fm.isWritableFile(atPath: candidate.path) {
            let path = FMNavigationStore.canonicalPath(candidate.path)
            if eligibleForAccess(path) {
                let alreadyActive = wq.hasActiveAccess(path: path)
                let result = wq.grantAccess(path: path, requireWrite: true)
                if result.0 && !alreadyActive { ownedGrants.insert(OwnedGrant(path: path, backend: NoxExploitSelection.current)) }
            }
        }
        guard fm.isWritableFile(atPath: candidate.path) else { throw problem("Write access denied: \(candidate.path)") }
    }

    private func resolve(_ raw: String) -> URL {
        let docPath = URL.documentsDirectory.standardizedFileURL.path
        let expanded = raw == "~" ? docPath : raw.hasPrefix("~/") ? docPath + String(raw.dropFirst(1)) : raw
        return URL(fileURLWithPath: expanded, relativeTo: URL(fileURLWithPath: directory, isDirectory: true)).standardizedFileURL
    }

    private func append(_ message: String, command: Bool = false, error: Bool = false) {
        lines.append(NoxShellLine(text: message, isCommand: command, isError: error))
        if lines.count > maxOutput { lines.removeFirst(lines.count - maxOutput) }
    }

    private func problem(_ message: String) -> NSError {
        NSError(domain: "NOXERRA.NoxShell", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private func tokenize(_ text: String) throws -> [String] {
        var args: [String] = []; var current = ""; var quoted: Character?; var escaped = false; var active = false
        for ch in text {
            if escaped { current.append(ch); escaped = false; active = true; continue }
            if ch == "\\" && quoted != "'" { escaped = true; active = true; continue }
            if let quote = quoted {
                if ch == quote { quoted = nil } else { current.append(ch) }
                continue
            }
            if ch == "\"" || ch == "'" { quoted = ch; active = true; continue }
            if ch.isWhitespace {
                if active { args.append(current); current = ""; active = false }
            } else { current.append(ch); active = true }
        }
        if quoted != nil { throw problem("Unclosed quote.") }
        if escaped { current.append("\\") }
        if active { args.append(current) }
        return args
    }
}

struct NoxShellView: View {
    @StateObject private var shell = NoxShellEngine()
    @State private var command = ""
    @State private var historyIndex: Int?
    @FocusState private var inputFocused: Bool
    @AppStorage(NoxExploitSelection.storageKey) private var selectedEngine = NoxExploitBackend.worseQuery.rawValue

    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Label("NOXSHELL", systemImage: "terminal.fill")
                    .font(.caption.weight(.black)).tracking(2).foregroundStyle(NoxStyle.accent)
                Spacer()
                Text((NoxExploitBackend(rawValue: selectedEngine) ?? .worseQuery).displayName.uppercased())
                    .font(.system(size: 10, weight: .semibold, design: .monospaced))
                    .foregroundStyle(NoxStyle.pale)
            }
            HStack {
                Image(systemName: "folder.fill").foregroundStyle(NoxStyle.cyan)
                Text(shell.directory).font(.caption2.monospaced())
                    .lineLimit(1).truncationMode(.middle)
                    .textSelection(.enabled)
                Spacer(minLength: 0)
            }.padding(12)
                .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 12))
            ScrollViewReader { reader in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(shell.lines) { line in
                            Text(line.text)
                                .font(.system(size: 12, design: .monospaced))
                                .foregroundStyle(line.isError ? Color.orange : line.isCommand ? NoxStyle.cyan : Color(red: 0.76, green: 0.94, blue: 0.78))
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .textSelection(.enabled)
                        }
                        Color.clear.frame(height: 1).id("terminalBottom")
                    }.padding(12)
                }
                .background(Color(red: 0.024, green: 0.019, blue: 0.046), in: RoundedRectangle(cornerRadius: 17))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(NoxStyle.accent.opacity(0.35)))
                .onChange(of: shell.lines.count) { _, _ in reader.scrollTo("terminalBottom", anchor: .bottom) }
            }
            HStack(spacing: 7) {
                Text("$").font(.system(.body, design: .monospaced).bold()).foregroundStyle(NoxStyle.cyan)
                TextField("Enter command · help", text: $command)
                    .font(.system(size: 14, design: .monospaced))
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.go).focused($inputFocused).onSubmit(runCommand)
                Button { runCommand() } label: {
                    Image(systemName: "arrow.turn.down.left").font(.headline)
                }.disabled(command.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            .padding(13).background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 12))
            HStack(spacing: 8) {
                Button("help") { shell.submit("help") }
                Button("ls") { shell.submit("ls") }
                Button("pwd") { shell.submit("pwd") }
                Button("↑") { cycleHistory() }
                Button("Clear") { shell.clear() }
            }
            .font(.caption.monospaced())
            .buttonStyle(.bordered)
            .tint(NoxStyle.accent)
            .frame(maxWidth: .infinity, alignment: .leading)
            Text("Built-in commands, not Bash or root. Files outside the sandbox require real access grants.")
                .font(.caption2).foregroundStyle(.secondary)
        }
        .padding(14)
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("NoxShell")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear { shell.releaseOwnedGrants() }
    }

    private func runCommand() {
        let submitted = command
        command = ""; historyIndex = nil
        shell.submit(submitted)
    }

    private func cycleHistory() {
        guard !shell.history.isEmpty else { return }
        let newIndex = max(0, (historyIndex ?? shell.history.count) - 1)
        historyIndex = newIndex
        command = shell.history[newIndex]
        inputFocused = true
    }
}
