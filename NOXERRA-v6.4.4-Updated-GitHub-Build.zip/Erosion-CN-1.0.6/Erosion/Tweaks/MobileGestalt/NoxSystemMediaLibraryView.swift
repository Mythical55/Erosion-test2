import SwiftUI
import UniformTypeIdentifiers
import AVFoundation

struct NoxSystemMediaLibraryView: View {
    enum Mode { case launchImages, audioLibrary }
    let mode: Mode
    @State private var imported: [URL] = []
    @State private var showImporter = false
    @State private var selectedImage: UIImage?
    @State private var errorText: String?
    @State private var player: AVAudioPlayer?

    private var folder: URL {
        let root = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return root.appendingPathComponent(mode == .launchImages ? "NOXERRA-Launch-Images" : "NOXERRA-Audio-Library", isDirectory: true)
    }
    private var title: String { mode == .launchImages ? "App Launch Images" : "App Audio Library" }

    var body: some View {
        List {
            Section {
                Text("Import, organize and preview assets in NOXERRA. This library does not modify another app or iOS system files.")
                    .font(.footnote).foregroundStyle(.secondary)
                Button { showImporter = true } label: {
                    Label(mode == .launchImages ? "Import Images" : "Import Audio", systemImage: "square.and.arrow.down")
                }
            }
            Section("Imported Assets") {
                if imported.isEmpty { Text("No assets imported yet").foregroundStyle(.secondary) }
                ForEach(imported, id: \.path) { url in
                    Button {
                        if mode == .launchImages {
                            selectedImage = UIImage(contentsOfFile: url.path)
                        } else {
                            player = try? AVAudioPlayer(contentsOf: url)
                            player?.play()
                        }
                    } label: {
                        HStack {
                            Image(systemName: mode == .launchImages ? "photo" : "waveform")
                            Text(url.lastPathComponent).lineLimit(1)
                            Spacer()
                            Image(systemName: "play.circle")
                        }
                    }
                }
                .onDelete { indexes in
                    for i in indexes { try? FileManager.default.removeItem(at: imported[i]) }
                    refresh()
                }
            }
            if let selectedImage, mode == .launchImages {
                Section("Image Preview") {
                    Image(uiImage: selectedImage)
                        .resizable().scaledToFit().frame(maxHeight: 260)
                }
            }
            if let errorText { Section { Text(errorText).foregroundStyle(.red) } }
        }
        .navigationTitle(title)
        .onAppear(perform: refresh)
        .fileImporter(isPresented: $showImporter,
                      allowedContentTypes: mode == .launchImages ? [.image] : [.audio],
                      allowsMultipleSelection: true) { result in
            do {
                let urls = try result.get()
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                for url in urls {
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let destination = folder.appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
                    try FileManager.default.copyItem(at: url, to: destination)
                }
                refresh()
            } catch { errorText = error.localizedDescription }
        }
    }
    private func refresh() {
        imported = (try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil))?.sorted { $0.lastPathComponent < $1.lastPathComponent } ?? []
    }
}
