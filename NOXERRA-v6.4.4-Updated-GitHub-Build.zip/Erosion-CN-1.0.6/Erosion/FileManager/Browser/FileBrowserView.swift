//
//  FileBrowserView.swift
//  AccessiblePlus
//
//  Created by lunginspector on 5/12/26.
//

import SwiftUI

import QuickLook
import Combine

enum FileSortMode: String, CaseIterable, Codable, Hashable {
    case system, name, date, type, size
    
    var id: String { rawValue }
    
    var label: String {
        switch self {
        case .system: return L("默认")
        case .name: return L("名称")
        case .date: return L("日期")
        case .type: return L("类型")
        case .size: return L("大小")
        }
    }
}

struct FileBrowserView: View {
    @EnvironmentObject var mgr: ErosionManager
    var path: URL = URL(fileURLWithPath: "/")
    var isContainer = false
    var shouldGrant = false
    var highlightTargetURL: URL? = nil
    
    @State private var dirFiles: [FileItem] = []
    @State private var unfilteredFiles: [FileItem] = []
    @State private var rawFiles: [FileItem] = []
    @State private var searchText = ""
    @AppStorage("maxInode") var maxInode = 15000000
    @AppStorage("chosenSort") var chosenSort: FileSortMode = .system
    @AppStorage("filesAscend") var filesAscend = true
    @AppStorage("listStyle") var listStyle = 1
    @AppStorage("hideDates") var hideDates = false
    @AppStorage("textViewerSize") var textViewerSize = 10
    @AppStorage("useMonospaced") var useMonospaced = true
    
    @State private var showFileImporter = false
    @State private var showWiFiShare = false
    @State private var showFolderAnalysis = false
    @State private var pendingAnalysisNavURL: URL?
    @State private var analysisNavigateURL: URL?
    @State private var showFailure = false
    @State private var failMsg = ""
    @State private var isLoading = false
    @State private var hasLoaded = false
    @State private var didAutoScrollToHighlight = false
    
    var body: some View {
        ScrollViewReader { scrollProxy in
            List {
                Section {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Label("NOXFILES / BROWSER", systemImage: "folder.fill")
                                .font(.caption.weight(.heavy)).tracking(1.2)
                                .foregroundStyle(NoxStyle.accent)
                            Spacer()
                            Text("\(dirFiles.count) items")
                                .font(.caption2.monospaced()).foregroundStyle(NoxStyle.pale)
                        }
                        Text(path.path)
                            .font(.caption2.monospaced())
                            .foregroundStyle(NoxStyle.pale)
                            .lineLimit(2).truncationMode(.middle)
                            .textSelection(.enabled)
                        HStack {
                            Button { mgr.refreshFiles.toggle() } label: {
                                Label("Refresh", systemImage: "arrow.clockwise")
                            }
                            .buttonStyle(.bordered).tint(NoxStyle.cyan)
                            NavigationLink(destination: NoxTrashView()) {
                                Label("NoxTrash", systemImage: "trash")
                            }
                            .buttonStyle(.bordered).tint(NoxStyle.accent)
                        }.font(.caption)
                    }.padding(.vertical, 5)
                }
                .listRowBackground(NoxStyle.surface)
                if isLoading {
                    Section {
                        VStack(alignment: .leading) {
                            HStack {
                                ProgressView()
                                    .offset(y: 0.5)
                                Text("正在加载文件...")
                                    .fontWeight(.medium)
                            }
                            if isContainer {
                                Text("由于容器路径扫描耗时较长，首次加载可能需要 30 秒以上，请耐心等待。")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                        }
                    }
                } else if showFailure {
                    CompactAlert(title: "无法加载目录文件！", symbol: "folder.badge.questionmark", text: failMsg)
                        .listRowInsets(EdgeInsets())
                        .listRowBackground(Color.clear)
                } else {
                    ForEach(dirFiles) { file in
                        Group {
                            if file.type == .folder {
                                FolderRow(file: file, shouldGrant: isContainer ? true : false, isContainer: isContainer)
                            } else {
                                FileRow(file: file)
                            }
                        }
                        .id(file.id)
                        .listRowBackground(matchesHighlight(file) ? Color.orange.opacity(0.22) : NoxStyle.surface)
                    }
                }
            }
            .onChange(of: dirFiles.map(\.id)) {
                scrollToHighlightedIfNeeded(using: scrollProxy)
            }
            .onAppear {
                scrollToHighlightedIfNeeded(using: scrollProxy)
            }
        }
        .navigationTitle(path.lastPathComponent)
        .navigationBarTitleDisplayMode(.inline)
        .scrollContentBackground(.hidden)
        .background(NoxStyle.background.ignoresSafeArea())
        .tint(NoxStyle.accent)
        .customListStyle(listStyle)
        .adaptiveListMargin()
        .searchable(text: $searchText, prompt: "搜索文件或 Bundle ID")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    ForEach(FileSortMode.allCases, id: \.self) { option in
                        Button {
                            chosenSort = option
                        } label: {
                            if chosenSort == option {
                                Label(option.label, systemImage: "checkmark")
                                    .tag(option)
                            } else {
                                Text(option.label)
                                    .tag(option)
                            }
                        }
                    }
                    Divider()
                    Button {
                        filesAscend.toggle()
                    } label: {
                        if filesAscend {
                            Label("升序", systemImage: "chevron.up")
                        } else {
                            Label("降序", systemImage: "chevron.down")
                        }
                    }
                    .disabled(chosenSort == .system)
                } label: {
                    Label("排序", systemImage: "line.3.horizontal.decrease")
                }
                .labelStyle(.iconOnly)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    if !isContainer {
                        Menu {
                            Button {
                                Alertinator.shared.prompt(title: L("请输入新文件名称（请附带文件扩展名）："), placeholder: "new.txt", completion: { name in
                                    let name = name ?? ""
                                    if !name.isEmpty {
                                        do {
                                            let fileURL = path.appendingPathComponent(name)
                                            try Data().write(to: fileURL)
                                            mgr.refreshFiles.toggle()
                                        } catch {
                                            print("(fm) failed to create file: \(error.localizedDescription)")
                                            Alertinator.shared.alert(title: L("新建文件失败！"), body: Errors.checkLogs)
                                        }
                                    }
                                })
                            } label: {
                                Label("文件", systemImage: "doc")
                            }
                            
                            Button {
                                Alertinator.shared.prompt(title: L("请输入新建 Plist 属性列表名称："), placeholder: L("配置名称"), completion: { name in
                                    let name = name ?? ""
                                    if !name.isEmpty {
                                        do {
                                            let fileURL = path.appendingPathComponent(name + ".plist")
                                            let data = try PropertyListSerialization.data(fromPropertyList: NSMutableDictionary(), format: .xml, options: 0)
                                            try data.write(to: fileURL)
                                            mgr.refreshFiles.toggle()
                                        } catch {
                                            print("(fm) failed to create plist: \(error.localizedDescription)")
                                            Alertinator.shared.alert(title: L("新建 Plist 失败！"), body: Errors.checkLogs)
                                        }
                                    }
                                })
                            } label: {
                                Label("属性列表 (Plist)", systemImage: "tablecells")
                            }
                            
                            Button {
                                Alertinator.shared.prompt(title: L("请输入新建文件夹名称："), placeholder: L("新建文件夹"), completion: { name in
                                    let name = name ?? ""
                                    if !name.isEmpty {
                                        do {
                                            try fm.createDirectoryIfNeeded(at: path.appendingPathComponent(name))
                                            mgr.refreshFiles.toggle()
                                        } catch {
                                            print("(fm) failed to create folder: \(error.localizedDescription)")
                                            Alertinator.shared.alert(title: L("新建文件夹失败！"), body: Errors.checkLogs)
                                        }
                                    }
                                })
                            } label: {
                                Label("文件夹", systemImage: "folder")
                            }
                            
                            Button {
                                Alertinator.shared.prompt(title: L("请输入符号链接指向的目标路径："), placeholder: "/path/to/dir", completion: { symPath in
                                    let symPath = symPath ?? ""
                                    if !symPath.isEmpty {
                                        do {
                                            try fm.createSymbolicLink(atPath: path.appendingPathComponent(URL(fileURLWithPath: symPath).lastPathComponent).path, withDestinationPath: symPath)
                                            mgr.refreshFiles.toggle()
                                        } catch {
                                            print("(fm) failed to create symlink: \(error.localizedDescription)")
                                            Alertinator.shared.alert(title: L("创建符号链接失败！"), body: "\(error.localizedDescription)")
                                        }
                                    }
                                })
                            } label: {
                                Label("符号链接 (Symlink)", systemImage: "arrow.up.right.circle")
                            }
                        } label: {
                            Label("新建...", systemImage: "plus")
                        }
                        
                        Button {
                            showFileImporter.toggle()
                        } label: {
                            Label("导入文件", systemImage: "arrow.down.doc")
                        }

                        Button {
                            showFolderAnalysis = true
                        } label: {
                            Label(
                                LocalizationManager.isEnglish ? "Deep Search & Large Files" : "深度搜索与大文件",
                                systemImage: "magnifyingglass.circle"
                            )
                        }

                        Button {
                            showWiFiShare = true
                        } label: {
                            Label(
                                LocalizationManager.isEnglish ? "Wi-Fi File Sharing" : "Wi-Fi 无线传输",
                                systemImage: "wifi"
                            )
                        }
                        Divider()
                    }
                    NavigationLink {
                        FileBrowserView(path: URL.documentsDirectory)
                    } label: {
                        Label("打开应用文档目录", systemImage: "folder")
                    }
                    NavigationLink {
                        List {
                            Section {
                                HStack {
                                    Text("最大 Inode 扫描上限")
                                    TextField("15000000", value: $maxInode, format: .number)
                                        .multilineTextAlignment(.trailing)
                                }
                            } header: {
                                HeaderLabel("容器路径扫描", symbol: "externaldrive")
                            } footer: {
                                Text("控制扫描容器目录时的最大 Inode 范围。数值越小扫描越快，但可能遗漏高 Inode 容器（建议设为 15000000）。")
                            }
                            
                            Section {
                                Picker("列表样式", selection: $listStyle) {
                                    Text("默认").tag(1)
                                    Text("平铺").tag(2)
                                    Text("分组").tag(3)
                                }
                                Toggle("隐藏修改日期", isOn: $hideDates)
                            } header: {
                                HeaderLabel("显示选项", symbol: "eye")
                            }
                            
                            Section {
                                Stepper(value: $textViewerSize) {
                                    HStack {
                                        Text("字号大小")
                                        Spacer()
                                        Text(textViewerSize.description)
                                    }
                                }
                                Toggle("等宽字体", isOn: $useMonospaced)
                            } header: {
                                HeaderLabel("文本查看器", symbol: "doc.plaintext")
                            }
                        }
                        .navigationTitle("文件浏览设置")
                    } label: {
                        Label("浏览设置", systemImage: "gearshape")
                    }
                } label: {
                    Label("操作", systemImage: "ellipsis")
                }
                .labelStyle(.iconOnly)
            }
        }
        .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.item]) { result in
            handleImport(result)
        }
        .sheet(isPresented: $showWiFiShare) {
            WiFiShareSheet(rootURL: path)
        }
        .sheet(isPresented: $showFolderAnalysis, onDismiss: {
            if let target = pendingAnalysisNavURL {
                pendingAnalysisNavURL = nil
                analysisNavigateURL = target
            }
        }) {
            FolderAnalysisSheet(rootURL: path) { targetURL in
                let targetCanon = FMNavigationStore.canonicalPath(targetURL.path)
                let currentCanon = FMNavigationStore.canonicalPath(path.path)
                if targetCanon != currentCanon {
                    pendingAnalysisNavURL = targetURL
                }
                showFolderAnalysis = false
            }
        }
        .navigationDestination(item: $analysisNavigateURL) { targetURL in
            FileBrowserView(path: targetURL, shouldGrant: true)
        }
        .refreshable {
            mgr.refreshFiles.toggle()
        }
        .onAppear {
            if !mgr.storedFiles.isEmpty && mgr.storedURL == path {
                rawFiles = mgr.storedFiles
                let sorted = sortFiles(files: mgr.storedFiles)
                unfilteredFiles = sorted
                dirFiles = filterFiles(sorted, query: searchText)
                if !isContainer {
                    FMNavigationStore.shared.record(url: path)
                }
            } else if isContainer && hasLoaded {
                // do nothing as it's already being stored in the variable
            } else {
                if shouldGrant {
                    let res = wq.grantAccess(path: path.path, requireWrite: false)
                    if res.0 {
                        if !isContainer {
                            FMNavigationStore.shared.record(url: path)
                        }
                        loadFilesFromPath()
                    } else {
                        showFailure = true
                        failMsg = L("无权访问该目录。")
                    }
                } else {
                    if !isContainer {
                        FMNavigationStore.shared.record(url: path)
                    }
                    loadFilesFromPath()
                }
            }
        }
        .onChange(of: searchText) { _, newSearch in
            dirFiles = filterFiles(unfilteredFiles, query: newSearch)
        }
        .onChange(of: chosenSort) {
            let source = rawFiles.isEmpty ? unfilteredFiles : rawFiles
            let sorted = sortFiles(files: source)
            unfilteredFiles = sorted
            dirFiles = filterFiles(sorted, query: searchText)
        }
        .onChange(of: filesAscend) {
            let source = rawFiles.isEmpty ? unfilteredFiles : rawFiles
            let sorted = sortFiles(files: source)
            unfilteredFiles = sorted
            dirFiles = filterFiles(sorted, query: searchText)
        }
        .onChange(of: mgr.refreshFiles) {
            loadFilesFromPath()
        }
    }
    
    private func matchesHighlight(_ item: FileItem) -> Bool {
        guard let highlightTargetURL else { return false }
        let targetCanon = FMNavigationStore.canonicalPath(highlightTargetURL.standardizedFileURL.path)
        let itemCanon = FMNavigationStore.canonicalPath(item.fileURL.standardizedFileURL.path)
        return itemCanon == targetCanon
    }

    private func scrollToHighlightedIfNeeded(using proxy: ScrollViewProxy) {
        guard !didAutoScrollToHighlight,
              highlightTargetURL != nil,
              let matched = dirFiles.first(where: { matchesHighlight($0) }) else {
            return
        }
        didAutoScrollToHighlight = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            withAnimation(.easeInOut(duration: 0.25)) {
                proxy.scrollTo(matched.id, anchor: .center)
            }
        }
    }

    private func filterFiles(_ files: [FileItem], query: String) -> [FileItem] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return files }
        return files.filter {
            $0.name.localizedCaseInsensitiveContains(trimmed) ||
            $0.fileURL.lastPathComponent.localizedCaseInsensitiveContains(trimmed)
        }
    }
    
    // MARK: handle files
    private func loadFilesFromPath() {
        isLoading = true
        let requestedPath = path
        let requestedMaxInode = Int64(maxInode)
        let requestedContainerMode = isContainer
        DispatchQueue.global(qos: .userInitiated).async {
            loadFilesInBackground(at: requestedPath,
                                  maxInode: requestedMaxInode,
                                  containerMode: requestedContainerMode)
        }
    }

    // Keep filesystem enumeration separate from SwiftUI state mutation.
    // In particular, avoid capturing a mutable array across nested dispatch closures.
    private func loadFilesInBackground(at requestedPath: URL,
                                       maxInode requestedMaxInode: Int64,
                                       containerMode: Bool) {
        do {
            let files: [FileItem]
            if containerMode {
                let paths = fsHandlers.getDirPaths(requestedPath.path, maxInode: requestedMaxInode)
                files = paths.map { entryPath -> FileItem in
                    getFileItem(at: URL(fileURLWithPath: entryPath), isContainer: true)
                }
            } else {
                let properties: [URLResourceKey] = [
                    .isDirectoryKey, .isSymbolicLinkKey,
                    .fileSizeKey, .contentModificationDateKey
                ]
                let urls = try fm.contentsOfDirectory(at: requestedPath,
                                                       includingPropertiesForKeys: properties)
                let useContainerItems = requestedPath == FSURL.appGroup || requestedPath == FSURL.systemData
                files = urls.map { url -> FileItem in
                    getFileItem(at: url, isContainer: useContainerItems)
                }
            }
            DispatchQueue.main.async {
                finishLoadingFiles(files, from: requestedPath, containerMode: containerMode)
            }
        } catch {
            print("(fm) failed to load files from \(requestedPath): \(error.localizedDescription)")
            DispatchQueue.main.async {
                showFailure = true
                failMsg = L("你可能没有查看此目录的权限，请前往主页查看运行日志了解详情。")
                isLoading = false
            }
        }
    }

    private func finishLoadingFiles(_ files: [FileItem], from requestedPath: URL,
                                    containerMode: Bool) {
        showFailure = false
        rawFiles = files
        let sorted = sortFiles(files: files)
        unfilteredFiles = sorted
        dirFiles = filterFiles(sorted, query: searchText)
        if containerMode {
            mgr.storedFiles = files
            mgr.storedURL = requestedPath
        }
        hasLoaded = true
        isLoading = false
    }

    private func sortFiles(files: [FileItem]) -> [FileItem] {
        var sortedFiles: [FileItem]
        
        switch chosenSort {
        case .system:
            sortedFiles = files
        case .name:
            sortedFiles = files.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        case .date:
            sortedFiles = files.sorted { $0.modifiedDate > $1.modifiedDate }
        case .type:
            sortedFiles = files.sorted { $0.type.sortOrder < $1.type.sortOrder }
        case .size:
            sortedFiles = files.sorted { $0.size < $1.size }
        }

        sortedFiles = filesAscend ? sortedFiles : sortedFiles.reversed()
        sortedFiles = sortedFiles.sorted { a, b in
            a.hidden && !b.hidden
        }
        return sortedFiles
    }
    
    // MARK: handle import
    private func handleImport(_ result: Result<URL, Error>) {
        switch result {
        case .success(let fileURL):
            do {
                let stopAccess = fileURL.startAccessingSecurityScopedResource()
                defer {
                    if stopAccess {
                        fileURL.stopAccessingSecurityScopedResource()
                    }
                }
                let data = try Data(contentsOf: fileURL)
                
                let newURL = path.appendingPathComponent(fileURL.lastPathComponent)
                if newURL.lastPathComponent.lowercased() == "com.apple.mobilegestalt.plist" {
                    Alertinator.shared.alert(title: L("已拦截高危系统文件覆盖！"), body: L("禁止在文件浏览器中直接导入覆盖 com.apple.MobileGestalt.plist，请使用 MobileGestalt 专用模块。"))
                    return
                }
                if fm.fileExists(atPath: newURL.path) {
                    let atomicRes = writeFileAtomically(data, to: newURL, allowEmpty: true)
                    if !atomicRes.0 {
                        throw atomicRes.1
                    }
                } else {
                    try data.write(to: newURL, options: .atomic)
                }
                mgr.refreshFiles.toggle()
            } catch {
                print("(fm) failed to import file: \(error.localizedDescription)")
                Alertinator.shared.alert(title: L("导入文件失败！"), body: "\(error.localizedDescription)")
            }
        case .failure(let error):
            print("(fm) failed to import file: \(error.localizedDescription)")
            Alertinator.shared.alert(title: L("导入文件失败！"), body: "\(error.localizedDescription)")
        }
    }
}

// MARK: user interface
extension View {
    @ViewBuilder
    func customListStyle(_ selection: Int) -> some View {
        switch selection {
        case 2: self.listStyle(.inset)
        case 3: self.listStyle(.grouped)
        default: self.listStyle(.insetGrouped)
        }
    }
    
    @ViewBuilder
    func adaptiveListMargin() -> some View {
        if #available(iOS 26.0, *) {
            self.contentMargins(.top, 1)
        }
    }
}

struct KeyboardDismissObserver: ViewModifier {
    var action: () -> Void
    
    func body(content: Content) -> some View {
        content
            .onReceive(Publishers.keyboardDismissed) { _ in
                action()
            }
    }
}

extension Publishers {
    static var keyboardDismissed: AnyPublisher<Void, Never> {
        NotificationCenter.default
            .publisher(for: UIResponder.keyboardDidHideNotification)
            .map { _ in () }
            .eraseToAnyPublisher()
    }
}
