//
//  GestaltView.swift
//  Erosion
//
//  Created by lunginspector on 8/14/26.
//

import SwiftUI
import Combine

import UniformTypeIdentifiers

struct GestaltView: View {
    @EnvironmentObject private var mgr: ErosionManager
    @StateObject private var store = GestaltStore.shared
    @AppStorage("mgOverrideGates") private var mgOverrideGates = false
    @AppStorage("mgWriteAtomically") private var mgWriteAtomically = true
    @AppStorage("noxerra.mg.extraSafetyReview") private var extraSafetyReview = true
    @State private var mgPage = 0
    @AppStorage("autoRespring") var autoRespring = false
    @AppStorage("hasShownSheet") private var hasShownSheet = false
    @Environment(\.dismiss) private var dismiss
    
    @State private var mgSubtype = 0
    @State private var mgOgSubtype = 0
    @State private var mgOgDeviceName = ""
    @State private var mgEnableDeviceName = false
    @AppStorage("mgDeviceName") private var mgDeviceName = ""
    @AppStorage("ogMachineName") private var ogMachineName = ""
    @AppStorage("showRegionTweak") private var showRegionTweak = false
    @AppStorage("showCustomKeys") private var showCustomKeys = true
    @AppStorage("mgCustKeyArray") var customKeys: [MGCustomKey] = []
    @State private var mgProductType = ""
    @State private var modelPreset = "Custom"
    private let modelPresets: [String] = [
        "Custom", "iPhone", "iPhone 3G", "iPhone 3GS", "iPhone 4", "iPhone 4s", "iPhone 5", "iPhone 5c", "iPhone 5s", "iPhone 6", "iPhone 6 Plus", "iPhone 6s", "iPhone 6s Plus", "iPhone SE", "iPhone 7", "iPhone 7 Plus", "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XR", "iPhone XS", "iPhone XS Max", "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2nd generation)", "iPhone 12 mini", "iPhone 12", "iPhone 12 Pro", "iPhone 12 Pro Max", "iPhone 13 mini", "iPhone 13", "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone SE (3rd generation)", "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro", "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max", "iPhone 16", "iPhone 16 Plus", "iPhone 16 Pro", "iPhone 16 Pro Max", "iPhone 16e", "iPhone 17", "iPhone Air", "iPhone 17 Pro", "iPhone 17 Pro Max", "iPhone 18", "iPhone 18 Pro", "iPhone 18 Pro Max", "iPad", "iPad 2", "iPad (3rd generation)", "iPad (4th generation)", "iPad (5th generation)", "iPad (6th generation)", "iPad (7th generation)", "iPad (8th generation)", "iPad (9th generation)", "iPad (10th generation)", "iPad mini", "iPad mini 2", "iPad mini 3", "iPad mini 4", "iPad mini (5th generation)", "iPad mini (6th generation)", "iPad Air", "iPad Air 2", "iPad Air (3rd generation)", "iPad Air (4th generation)", "iPad Air (5th generation)", "iPad Pro 9.7-inch", "iPad Pro 10.5-inch", "iPad Pro 11-inch", "iPad Pro 12.9-inch", "iPad Pro 13-inch"
    ]
    
    @State private var showInfoSheet = false
    @State private var pendingPreviewAfterInfoSheet = false
    @State private var idiotButtonTimerComplete = false
    @State private var mgBaselineDict: NSDictionary = [:]
    @State private var diffPreviewPayload: MGDiffPreviewPayload? = nil
    @State private var showInspectorSheet = false
    @State private var hasLoadedInitialData = false
    @State private var hasPromptedBuildMismatch = false
    @State private var hasWriteAccess = false
    @State private var showBackupImporter = false
    @State private var dualVaultReady = false
    @State private var noxSpoofVersionText = ""
    @State private var noxSpoofBuildText = ""
    @State private var noxDemoConfirmation = false


    private struct MGDiffPreviewPayload: Identifiable {
        let id = UUID()
        let diffs: [MGDiffItem]
        let candidate: NSMutableDictionary
    }
    
    var body: some View {
        VStack(spacing: 0) {
            Picker("MobileGestalt workspace", selection: $mgPage) {
                Text("System Values").tag(0)
                Text("Key Editor").tag(1)
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 16)
            .padding(.vertical, 11)
            .background(NoxStyle.background)
            .onChange(of: mgPage) { _, page in
                // Enabling the pre-existing custom-key system is required for staged keys to apply.
                if page == 1 { showCustomKeys = true }
            }

            if mgPage == 1 {
                CustomKeyView()
            } else {
                List {
                Section {
                    HStack(spacing: 12) {
                        Image(systemName: "cpu.fill")
                            .font(.title2.weight(.semibold))
                            .foregroundStyle(NoxStyle.cyan)
                            .frame(width: 43, height: 43)
                            .background(NoxStyle.accent.opacity(0.14), in: RoundedRectangle(cornerRadius: 14))
                        VStack(alignment: .leading, spacing: 4) {
                            Text("NOXERRA · SYSTEM VALUES")
                                .font(.caption.weight(.heavy))
                                .tracking(1.1)
                                .foregroundStyle(NoxStyle.accent)
                            Text("MobileGestalt controls")
                                .font(.title3.weight(.bold))
                        }
                    }
                    Text("Stage device capabilities, inspect the exact changes, and apply with a verified original backup. Unsupported features stay locked rather than pretending to work.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                coreSystemSection
                importedUniqueTweaksSection
                customizationSection
                systemUtilitiesSection
                Section {
                    NavigationLink {
                        MGInspectorView(store: store)
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "waveform.path.ecg.rectangle.fill")
                                .font(.title3)
                                .foregroundStyle(Color.accentColor)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("真机生效核验与动态槽位实时探针")
                                    .font(.subheadline.weight(.semibold))
                                Text("对比原厂备份、当前配置与 MGCopyAnswer 真机返回值（纯只读）")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 2)
                    }

                    HStack(spacing: 10) {
                        Image(systemName: dualVaultReady ? "checkmark.shield.fill" : "shield.lefthalf.filled")
                            .font(.title3)
                            .foregroundStyle(dualVaultReady ? Color.green : Color.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(dualVaultReady ? L("双重原厂安全备份已锁定") : L("本地原厂备份已就绪"))
                                .font(.subheadline.weight(.semibold))
                            Text(dualVaultReady ? L("沙盒备份 + 系统金库双冗余 · SHA-256 已校验（卸载重装不丢失）") : L("已启用 SHA-256 完整性校验与防零字节原位回滚"))
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 4)
                        Button {
                            promptFactoryRestore()
                        } label: {
                            Text("一键恢复原厂")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color.orange.opacity(0.16), in: Capsule())
                                .foregroundStyle(Color.orange)
                        }
                        .buttonStyle(.plain)
                        .disabled(!hasWriteAccess && !weOnADebugBuild)
                    }
                    .padding(.vertical, 2)
                }
                Section {
                    if mgOverrideGates {
                        HStack {
                            Picker("屏幕子类型", selection: $mgSubtype) {
                                Text("原始默认 (\(mgOgSubtype))").tag(mgOgSubtype)
                                if mgOgSubtype != 2436 {
                                    if isDynamIslandHD() && doubleSysVrs() < 19.0 {
                                        Text("禁用灵动岛 (2436)").tag(2436)
                                    } else if isHomeButtonHD() {
                                        Text("iPhone X 全面屏手势 (2436)").tag(2436)
                                    }
                                }
                                if mgOgSubtype != 2556 {
                                    Text("iPhone 14 Pro / 15 Pro (2556)").tag(2556)
                                }
                                if mgOgSubtype != 2796 {
                                    Text("iPhone 14 Pro Max / 15 Pro Max (2796)").tag(2796)
                                }
                                if doubleSysVrs() >= 18.0 {
                                    if mgOgSubtype != 2622 {
                                        Text("iPhone 16 Pro / 17 Pro (2622)").tag(2622)
                                    }
                                    if mgOgSubtype != 2868 {
                                        Text("iPhone 16 Pro Max / 17 Pro Max (2868)").tag(2868)
                                    }
                                }
                                if doubleSysVrs() >= 26.0 && mgOgSubtype != 2736 {
                                    Text("iPhone Air (2736)").tag(2736)
                                }
                                if doubleSysVrs() >= 27.0 && mgOgSubtype != 2670 {
                                    Text("iPhone 18 Pro Max (2670)").tag(2670)
                                }
                            }
                            Spacer()
                            Button {
                                Alertinator.shared.alert(title: L("屏幕子类型说明"), body: MGMsg.subtype)
                            } label: {
                                Image(systemName: "info.circle")
                                    .frame(width: 24, height: 22)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    HStack {
                        Toggle("Custom Model Name", isOn: $mgEnableDeviceName)
                        Button {
                            Alertinator.shared.alert(title: "Custom Model Name", body: "Choose a model-name preset or enter your own label. This changes supported MobileGestalt display values, not your device hardware. Some iOS screens cache model information.")
                        } label: { Image(systemName: "info.circle").foregroundStyle(NoxStyle.cyan) }
                        .buttonStyle(.plain)
                    }
                    if mgEnableDeviceName {
                        Picker("Model name preset", selection: $modelPreset) {
                            ForEach(modelPresets, id: \.self) { model in
                                Text(model).tag(model)
                            }
                        }
                        .onChange(of: modelPreset) { _, selected in
                            if selected != "Custom" { mgDeviceName = selected }
                        }
                        TextField("Custom model name", text: $mgDeviceName)
                    }
                    PlainToggle(L("液态玻璃低功耗渲染（省电模式）"), infoType: .info, infoMessage: MGMsg.liquidGlass, minVrs: 26.0, isOn: store.mgKeyBinding([MGKey.liquidGlassLowPower]))
                } header: {
                    HeaderLabel(L("外观与显示特征"), symbol: "paintbrush.pointed")
                }
                
                if !isDynamIslandHD() || !isAODHD() || !isBootChimeHD() || !isChargeLimitHD() || mgOverrideGates {
                    Section {
                        if !isDynamIslandHD() || mgOverrideGates {
                            PlainToggle(L("启用灵动岛"), minVrs: 19.0, isOn: store.mgKeyBinding([MGKey.island]))
                        }
                        if !isAODHD() || mgOverrideGates {
                            PlainToggle(L("启用全天候显示 (AOD)"), minVrs: 18.0, isOn: store.mgKeyBinding([MGKey.AOD, MGKey.AOTime]))
                            if store.isEnabled([MGKey.AOD]) {
                                PlainToggle(L("启用全天候显示鲜艳度"), minVrs: 18.0, isOn: store.mgKeyBinding([MGKey.AODVibrancy]))
                            }
                        }
                        if !isChargeLimitHD() || mgOverrideGates {
                            PlainToggle(L("启用 80% 充电上限"), minVrs: 17.0, isOn: store.mgKeyBinding([MGKey.chargeLim]))
                        }
                        if !isBootChimeHD() || mgOverrideGates {
                            PlainToggle(L("启用开机提示音"), isOn: store.mgKeyBinding([MGKey.bootChime]))
                        }
                    } header: {
                        HeaderLabel(L("硬件特性解锁"), symbol: "gearshape")
                    }
                }
                
                Section {
                    let internalGateLocked = store.isEnabled([MGKey.appIntell]) || (isAppleIntellHD() && !mgOverrideGates)
                    PlainToggle(L("启用 Apple 内部安装模式"), infoType: .info, infoMessage: MGMsg.intInstall, isOn: store.mgKeyBinding([MGKey.intInstall]))
                        .disabled(internalGateLocked && !store.isKeyEnabled(MGKey.intInstall))
                    PlainToggle(L("启用内部版本标识 (Internal Build)"), infoType: .info, infoMessage: MGMsg.intBuild, isOn: store.mgKeyBinding([MGKey.intBuild]))
                        .disabled(internalGateLocked && !store.isKeyEnabled(MGKey.intBuild))
                } header: {
                    HeaderLabel(L("内部调试选项"), symbol: "ant")
                } footer: {
                    if isAppleIntellHD() && !mgOverrideGates {
                        Text("已自动锁定：Apple 内部安装模式与 Apple 智能互斥，开启会导致原生 AI 机型无法激活 Apple 智能。")
                    }
                }
                
                NoxMGIdentitySection(store: store,
                                     noxSpoofVersionText: $noxSpoofVersionText,
                                     noxSpoofBuildText: $noxSpoofBuildText,
                                     noxDemoConfirmation: $noxDemoConfirmation)

                Section {
                    AppleIntelligenceCheckupCard(store: store, hasWriteAccess: hasWriteAccess) {
                        Alertinator.shared.runWhenPresentationIdle {
                            showInspectorSheet = true
                        }
                    }

                    if isIOS27_3Beta1() {
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: "info.circle.fill")
                                .foregroundStyle(.orange)
                                .padding(.top, 2)
                            Text(
                                LocalizationManager.isEnglish
                                    ? "iOS 27.3 beta 1 Notice: On China (CH/A) devices, Photos Clean Up / Wand / Camera Siri are blocked locally by eligibilityd CN region policy and cannot be bypassed via MobileGestalt. iOS 27.2.1 is recommended."
                                    : "iOS 27.3 beta 1 提示：国行 (CH/A) 设备上的照片「消除 / 魔棒」与相机 Siri 会被系统 eligibilityd CN 地区策略本地拦截（改 MobileGestalt 无法绕过），建议降回或停留在 iOS 27.2.1。"
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 2)
                    }

                    PlainToggle(L("启用安全研究设备界面 (SRD UI)"), minVrs: 26.0, isOn: store.mgKeyBinding([MGKey.srd]))
                    if showRegionTweak || mgOverrideGates || store.mgRegionRestrictionsBinding().wrappedValue {
                        PlainToggle(L("解除地区限制（国行 AI / 美版 LL/A）"), isOn: store.mgRegionRestrictionsBinding())
                        if store.mgRegionRestrictionsBinding().wrappedValue {
                            HStack(spacing: 10) {
                                Picker("修改模式", selection: store.mgRegionUnlockModeBinding()) {
                                    Text("完整美版 LL + LL/A").tag(MGRegionUnlockMode.fullUS)
                                    Text("仅改区域代码 LL（保留 CH/A 后缀与双卡兼容）").tag(MGRegionUnlockMode.regionCodeOnly)
                                }
                                Button {
                                    Alertinator.shared.alert(title: L("地区修改模式说明"), body: MGMsg.regionModeInfo)
                                } label: {
                                    Image(systemName: "info.circle")
                                        .frame(width: 24, height: 22)
                                }
                                .buttonStyle(.plain)
                            }
                            if store.currentRegionUnlockMode == .fullUS {
                                HStack {
                                    Text("美版监管型号")
                                    Spacer()
                                    TextField("如 A3473", text: store.mgRegModelBinding())
                                        .multilineTextAlignment(.trailing)
                                        .textInputAutocapitalization(.characters)
                                        .autocorrectionDisabled()
                                }
                            } else {
                                let keptSuffix = store.strVal(forKey: MGKey.regionSysconfig)
                                let keptModel = store.strVal(forKey: MGKey.regModelNumber)
                                let suffixDisplay = keptSuffix.isEmpty ? L("原厂") : keptSuffix
                                let modelDisplay = keptModel.isEmpty ? L("原厂") : keptModel
                                HStack {
                                    Text("保留销售后缀与型号")
                                    Spacer()
                                    Text("\(suffixDisplay) · \(modelDisplay)")
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    if !isAppleIntellHD() || mgOverrideGates {
                        PlainToggle(
                            L("启用 Apple 智能开关"),
                            subtitle: L("自动同步解锁相册“消除”与备忘录“手写体合成”"),
                            infoType: .info,
                            infoTitle: L("启用 Apple 智能说明"),
                            infoMessage: MGMsg.appleIntellInfo,
                            minVrs: 18.1,
                            isOn: store.mgKeyBinding(MGKey.appIntellAllKeys)
                        )
                        .onChange(of: store.mgKeyBinding(MGKey.appIntellAllKeys).wrappedValue) { (_, newVal) in
                            if newVal {
                                store.mgPullKeys([MGKey.intBuild, MGKey.intInstall])
                            }
                        }
                    }
                    if raveSupported() || mgOverrideGates {
                        let advNativeOn = isAdvAppleIntellHD()
                        let advConflictOn = store.isAdvAppleIntellConflictActive()
                        if advNativeOn && !mgOverrideGates {
                            PlainToggle(
                                L("解锁 iOS 27 进阶 AI 能力 [测试特性]"),
                                subtitle: L("✅ 本机硬件已原生开启（无需额外修改，已锁定防误关）"),
                                infoType: .info,
                                infoTitle: L("iOS 27 进阶 AI 能力说明"),
                                infoMessage: MGMsg.advAppleIntell,
                                isOn: .constant(true)
                            )
                            .disabled(true)
                        } else {
                            PlainToggle(
                                L("解锁 iOS 27 进阶 AI 能力 [测试特性]"),
                                subtitle: store.isPersonalTranslatorAccidentallyDisabled()
                                    ? L("⚠️ 检测到个人实时翻译槽位 (#266) 被旧版误关（会导致相册消除/扩图与相机 Siri 瞬间报错），请关闭此项或点顶部一键修复")
                                    : (advConflictOn
                                        ? L("⚠️ 检测到已开启非原生实验槽位（会导致照片“高质量”消除报错），请直接关闭并应用恢复")
                                        : (isNativePersonalTranslatorHD()
                                            ? L("✅ 本机已原生开启个人实时翻译；实验性音频智能槽位已锁定关闭（强开会导致照片高质量消除报错）")
                                            : L("已由防呆护栏自动锁定：iPhone/iPad 强开会导致照片“高质量”消除报错"))),
                                infoType: .warning,
                                infoTitle: L("iOS 27 进阶 AI 防呆锁定说明"),
                                infoMessage: MGMsg.advAppleIntell,
                                isOn: store.mgSafeAdvAppleIntellGuardrailBinding()
                            )
                            .disabled(!advConflictOn)
                        }
                    }
                    if !isAppleIntellHD() || mgOverrideGates {
                        HStack(spacing: 10) {
                            Picker("机型伪装", selection: $mgProductType) {
                                Text("保持默认").tag(ogMachineName)
                                if ogMachineName.contains("Pad") {
                                    if doubleSysVrs() >= 17.4 {
                                        Text("iPad Pro 11 英寸 (M4)").tag("iPad16,3")
                                        Text("iPad Pro 11 英寸 (M4, 蜂窝网络)").tag("iPad16,4")
                                    }
                                    Text("iPad Pro 11 英寸 (第 4 代)").tag("iPad14,3")
                                    Text("iPad Pro 11 英寸 (第 4 代, 蜂窝网络)").tag("iPad14,4")
                                } else {
                                    Text("iPhone 15 Pro").tag("iPhone16,1")
                                    Text("iPhone 15 Pro Max").tag("iPhone16,2")
                                    if doubleSysVrs() >= 18.0 {
                                        Text("iPhone 16").tag("iPhone17,3")
                                        Text("iPhone 16 Plus").tag("iPhone17,4")
                                        Text("iPhone 16 Pro").tag("iPhone17,1")
                                        Text("iPhone 16 Pro Max").tag("iPhone17,2")
                                    }
                                    if doubleSysVrs() >= 19.0 {
                                        Text("iPhone 17").tag("iPhone18,3")
                                        Text("iPhone 17 Pro").tag("iPhone18,1")
                                        Text("iPhone 17 Pro Max").tag("iPhone18,2")
                                        Text("iPhone Air").tag("iPhone18,4")
                                    }
                                    if doubleSysVrs() >= 27.0 {
                                        Text("iPhone 18 Pro").tag("iPhone19,2")
                                        Text("iPhone 18 Pro Max").tag("iPhone19,3")
                                        Text("iPhone Duo").tag("iPhone19,4")
                                    }
                                }
                            }
                            Button {
                                Alertinator.shared.alert(title: L("机型伪装说明"), body: isAppleIntellHD() ? MGMsg.spoofUseless : MGMsg.spoofAI)
                            } label: {
                                Image(systemName: "info.circle")
                                    .frame(width: 24, height: 22)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                } header: {
                    HeaderLabel(L("地区与功能准入 (Eligibility)"), symbol: "flag")
                } footer: {
                    Text("注：原生支持 Apple 智能的机型默认隐藏旧机型专用的“Apple 智能总开关”与“机型伪装”（国行机型仅需开启“解除地区限制”与下方“green-tea 底层限制”即可激活）；“解锁 iOS 27 进阶 AI 能力”将根据当前机型与固件版本实时展示开关或原生状态。")
                }

                Section {
                    let greenTeaReady = store.canModifyGreenTeaCache()
                    let wapiReady = store.canModifyWapiCache()
                    VStack(alignment: .leading, spacing: 6) {
                        HStack(spacing: 8) {
                            Image(systemName: greenTeaReady ? "checkmark.seal.fill" : "xmark.octagon.fill")
                                .foregroundStyle(greenTeaReady ? Color.green : Color.red)
                            Text(greenTeaReady ? L("已精确匹配本机缓存布局") : L("动态解析未通过（已拒绝修改）"))
                                .font(.subheadline.weight(.medium))
                                .foregroundStyle(greenTeaReady ? Color.primary : Color.red)
                            Spacer()
                            Button {
                                let report = MGCacheDataCoordinator.shared.diagnosticReport(for: store.mgCurrentDict)
                                Alertinator.shared.alert(title: L("本机 CacheData 动态解析详情"), body: report)
                            } label: {
                                HStack(spacing: 3) {
                                    Text("查看偏移")
                                        .font(.caption)
                                    Image(systemName: "info.circle")
                                }
                            }
                            .buttonStyle(.plain)
                            .foregroundStyle(Color.accentColor)
                        }
                        if let failReason = store.cacheResolutionFailureReason() {
                            Text(failReason)
                                .font(.caption)
                                .foregroundStyle(Color.red)
                        }
                    }
                    .padding(.vertical, 2)

                    PlainToggle(
                        L("解除国行底层限制（eSIM / FaceTime 音频）"),
                        subtitle: L("注：iOS 26/27 下解除 green-tea 同样会隐藏国行单应用“不允许联网”菜单"),
                        infoType: .info,
                        infoTitle: L("解除国行底层限制说明"),
                        infoMessage: MGMsg.chinaCacheUnlock,
                        isOn: store.mgChinaRestrictionCacheBinding()
                    )
                    .disabled(!greenTeaReady)

                    PlainToggle(
                        L("将“无线局域网”显示为“Wi-Fi”"),
                        subtitle: L("⚠️ 开启后会隐藏 WAPI 开关与国行单应用“不允许联网”功能"),
                        infoType: .warning,
                        infoTitle: L("无线局域网改 Wi-Fi 重要提示"),
                        infoMessage: MGMsg.wapiToWifi,
                        isOn: store.mgWapiWifiBinding()
                    )
                    .disabled(!wapiReady)
                } header: {
                    HeaderLabel(L("国行底层缓存限制 (CacheData 动态解析)"), symbol: "antenna.radiowaves.left.and.right")
                } footer: {
                    Text("运行时从本机内存中的 libMobileGestalt.dylib 实时解析偏移并严格核对 CacheUUID、长度与有效位；解析失败时严禁修改任何字节。注意：在 iOS 26/27 中，解除 green-tea 或将“无线局域网”改为“Wi-Fi”均会切换为国际版“蜂窝数据”开关逻辑（隐藏单应用“不允许联网”）。应用本组开关后请手动重启手机生效。")
                }

                Section {
                    featureSlotRow(
                        title: L("相册与相机“混音 (Audio Mix)”"),
                        subtitle: L("视频编辑支持标准 / 语音突显 / 录音棚 / 电影效果四档人声混音"),
                        infoTitle: L("混音 (Audio Mix) 说明"),
                        infoMessage: MGMsg.audioMixInfo,
                        keys: [MGKey.audioMix]
                    )
                    featureSlotRow(
                        title: L("FaceTime 空间音频"),
                        subtitle: L("解锁 FaceTime 通话 3D 空间声场渲染（纯软件渲染，兼容旧机型且不影响语音备忘录）"),
                        infoTitle: L("FaceTime 空间音频说明"),
                        infoMessage: MGMsg.spatialFaceTimeInfo,
                        keys: [MGKey.spatialFaceTimeAudio]
                    )
                    spatialAudioRecSlotRow()
                    featureSlotRow(
                        title: L("按下快门瞬间抓拍 (Responsive Shutter)"),
                        subtitle: L("降低相机按下快门至成像管线的触发延迟，实现零延迟抓拍"),
                        infoTitle: L("按下快门瞬间抓拍说明"),
                        infoMessage: MGMsg.responsiveShutterInfo,
                        keys: [MGKey.responsiveShutter]
                    )
                    featureSlotRow(
                        title: L("健康“高血压趋势评估与通知模式”"),
                        subtitle: L("开启健康 App 血压偏高趋势分析、风险评估与测量记录向导"),
                        infoTitle: L("高血压趋势评估说明"),
                        infoMessage: MGMsg.hypertensionInfo,
                        keys: [MGKey.hypertensionNotif]
                    )
                } header: {
                    HeaderLabel(L("影像与健康进阶能力 (CacheData 硬件槽位)"), symbol: "waveform.badge.mic")
                } footer: {
                    Text("本组能力由设备树 (IODeviceTree) 映射至二进制 CacheData 布尔槽位，必须通过动态槽位偏移直接写入 CacheData 才能绕过系统 _MGCacheSetValueForKey 有效性短路检查。本机已原生开启的硬件能力会自动锁定以防误关降级；应用后请手动重启手机生效。")
                }

                Section {
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: "flask.fill")
                            .foregroundStyle(Color.orange)
                            .padding(.top, 2)
                        VStack(alignment: .leading, spacing: 4) {
                            Text("测试特性专区（Experimental · CacheData 动态槽位）")
                                .font(.subheadline.weight(.semibold))
                            Text("以下能力全部通过本机 libMobileGestalt.dylib 实时解析二进制布尔槽位偏移并执行零白苹果写前校验。受各机型物理传感器与 eligibilityd 策略差异影响，实际表现可能因设备而异，修改后请重启设备测试。")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        Button {
                            Alertinator.shared.alert(title: L("测试特性说明"), body: MGMsg.expNotice)
                        } label: {
                            Image(systemName: "info.circle")
                                .foregroundStyle(Color.orange)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.vertical, 2)

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 日版/韩版真·相机快门静音"),
                        subtitle: L("组合修改 3 个真实 CacheData 快门音豁免槽位，无需改美版即可尝试静音快门"),
                        infoTitle: L("日韩版相机快门静音（测试特性）"),
                        infoMessage: MGMsg.expShutterMuteInfo,
                        rules: [
                            MGSlotRule(key: MGKey.shutterRelaxation, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.shutterKeyboardMutePreserve, targetValue: false, required: false),
                            MGSlotRule(key: MGKey.shutterLegacyMutePreserve, targetValue: false, required: false)
                        ]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 高低功耗双麦并发拾音 (录音棚叠录底座)"),
                        subtitle: L("解锁语音备忘录伴奏叠录与多轨人声分离所需的双麦并发硬件标记"),
                        infoTitle: L("高低功耗双麦并发（测试特性）"),
                        infoMessage: MGMsg.expStudioMicsInfo,
                        rules: [MGSlotRule(key: MGKey.concurrentHPLPMics, targetValue: true)]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 相册局部光影重绘与新一代色调映射"),
                        subtitle: L("开启 PhotosLocalLight + ToneMapping + HDR 深度延迟渲染管线"),
                        infoTitle: L("相册光影与色调映射增强（测试特性）"),
                        infoMessage: MGMsg.expPhotoToneInfo,
                        rules: [
                            MGSlotRule(key: MGKey.photosLocalLight, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.toneMapping, targetValue: true, required: false),
                            MGSlotRule(key: MGKey.hdrDeferredProcessing, targetValue: true, required: false)
                        ]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 超取景框捕获与 P3 广色域立体声视频"),
                        subtitle: L("同步开启 SpatialOverCapture、立体声视频拾音与 P3 广色域录制"),
                        infoTitle: L("空间超取景与立体声视频（测试特性）"),
                        infoMessage: MGMsg.expSpatialStereoInfo,
                        rules: [
                            MGSlotRule(key: MGKey.spatialOverCapture, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.stereoAudioRec, targetValue: true, required: false),
                            MGSlotRule(key: MGKey.p3VideoRec, targetValue: true, required: false)
                        ]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 相机控制电容滑动变焦与触觉阻尼完整面板"),
                        subtitle: L("补齐电容触敏相机控制、物理档位阻尼与微幅触觉反馈 4 项槽位"),
                        infoTitle: L("相机控制完整交互包（测试特性）"),
                        infoMessage: MGMsg.expCamControlInfo,
                        rules: [
                            MGSlotRule(key: MGKey.camButton, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.touchSensitiveCamControl, targetValue: true, required: false),
                            MGSlotRule(key: MGKey.hardwareDetents, targetValue: true, required: false),
                            MGSlotRule(key: MGKey.cameraHaptics, targetValue: true, required: false)
                        ]
                    )

                    let legacyBatteryRules = [
                        MGSlotRule(key: MGKey.legacyBatteryInfo, targetValue: true, required: true),
                        MGSlotRule(key: MGKey.legacyDynamicEndOfCharge, targetValue: true, required: false)
                    ]
                    let legacyBatteryExtendedInfo = MGMsg.expLegacyBatteryInfo + (LocalizationManager.isEnglish
                        ? "\n\nNote: iPhone 15 series and newer models (and modern M2/M4+ iPads) natively show Battery Cycle Count, Manufacture Date, and First Use Date in Settings → Battery → Battery Health since iOS 17.4+, so this legacy-hardware flag is unnecessary on those devices."
                        : "\n\n提示：iPhone 15 全系列及更新机型（以及新款 M2/M4+ iPad）自 iOS 17.4 起已在系统「设置 → 电池 → 电池健康」原生内置循环计数与生产日期，无需开启此旧机型实验开关。")
                    if isNativeBatteryCycleInfoHD() && !mgOverrideGates {
                        let legacyBatteryBinding = store.mgSlotRulesBinding(legacyBatteryRules)
                        if legacyBatteryBinding.wrappedValue {
                            PlainToggle(
                                L("[测试特性] 旧机型显示电池循环次数与生产日期"),
                                subtitle: LocalizationManager.isEnglish
                                    ? "⚠️ Native on your device (Settings → Battery → Battery Health); turn off this legacy flag and tap Apply"
                                    : "⚠️ 当前机型系统「电池健康」已原生内置循环与日期显示，建议关闭此旧机型开关并应用",
                                infoType: .info,
                                infoTitle: L("旧机型电池健康详情（测试特性）"),
                                infoMessage: legacyBatteryExtendedInfo,
                                isOn: legacyBatteryBinding
                            )
                        } else {
                            PlainToggle(
                                L("[测试特性] 旧机型显示电池循环次数与生产日期"),
                                subtitle: LocalizationManager.isEnglish
                                    ? "✅ Native on iPhone 15+ / modern iPad (Settings → Battery → Battery Health); no tweak needed (locked)"
                                    : "✅ 当前机型（iPhone 15 系列及更新机型 / 新款 iPad）系统「设置 → 电池」已原生内置，无需开启（已自动锁定）",
                                infoType: .info,
                                infoTitle: L("旧机型电池健康详情（测试特性）"),
                                infoMessage: legacyBatteryExtendedInfo,
                                isOn: .constant(false)
                            )
                            .disabled(true)
                        }
                    } else {
                        experimentalSlotRuleRow(
                            title: L("[测试特性] 旧机型显示电池循环次数与生产日期"),
                            subtitle: L("在旧款机型“关于本机 / 电池健康”中展示循环计数与首次使用日期"),
                            infoTitle: L("旧机型电池健康详情（测试特性）"),
                            infoMessage: legacyBatteryExtendedInfo,
                            rules: legacyBatteryRules
                        )
                    }

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 户外高亮全天候显示与翻页帧缓冲"),
                        subtitle: L("解锁 HighLuminanceAOD 与低功耗 Flipbook 息屏显示管线（非 LTPO 屏耗电较高）"),
                        infoTitle: L("户外高亮 AOD（测试特性）"),
                        infoMessage: MGMsg.expHighLumAODInfo,
                        rules: [
                            MGSlotRule(key: MGKey.highLuminanceAOD, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.aodFlipbook, targetValue: true, required: false)
                        ]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] CarPlay Ultra (新一代多屏全液晶车载)"),
                        subtitle: L("启用新一代多仪表盘接管 CarPlay 2.0 车载协议栈标记"),
                        infoTitle: L("CarPlay Ultra（测试特性）"),
                        infoMessage: MGMsg.expCarPlay2Info,
                        rules: [MGSlotRule(key: MGKey.carPlay2, targetValue: true)]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 120Hz 触控采样事件投递管线"),
                        subtitle: L("开启 TouchDelivery120Hz 触控上报（注：60Hz 屏幕无法突破物理显示刷新率）"),
                        infoTitle: L("120Hz 触控采样投递（测试特性）"),
                        infoMessage: MGMsg.expTouch120Info,
                        rules: [MGSlotRule(key: MGKey.touchDelivery120Hz, targetValue: true)]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] AirPods 临床听力均衡与低功耗助听器模式"),
                        subtitle: L("开启 hearingaid 均衡、低功耗音频与降功耗 3 个连续硬件槽位"),
                        infoTitle: L("临床听力与助听器模式（测试特性）"),
                        infoMessage: MGMsg.expHearingAidInfo,
                        rules: [
                            MGSlotRule(key: MGKey.hearingAidEQ, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.hearingAidLE, targetValue: true, required: false),
                            MGSlotRule(key: MGKey.hearingAidPowerRed, targetValue: true, required: false)
                        ]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 睡眠呼吸暂停风险趋势检测"),
                        subtitle: L("开启“健康 -> 呼吸紊乱”睡眠呼吸暂停评估页面支持"),
                        infoTitle: L("睡眠呼吸暂停检测（测试特性）"),
                        infoMessage: MGMsg.expSleepApneaInfo,
                        rules: [MGSlotRule(key: MGKey.breathingDisturbances, targetValue: true)]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 解除美版血氧软件专利限制"),
                        subtitle: L("将 USLegallyCompliantBloodOxygen 设为 false（国行机型原生未受限无需开启）"),
                        infoTitle: L("解除美版血氧限制（测试特性）"),
                        infoMessage: MGMsg.expUSBloodOxygenInfo,
                        rules: [MGSlotRule(key: MGKey.usBloodOxygen, targetValue: false)]
                    )

                    experimentalSlotRuleRow(
                        title: L("[测试特性] 户外极限运动模式与日光照射时长监测"),
                        subtitle: L("同步解锁 WorkoutUltraMode 与环境日光照射统计槽位"),
                        infoTitle: L("极限运动与日光监测（测试特性）"),
                        infoMessage: MGMsg.expWorkoutUltraInfo,
                        rules: [
                            MGSlotRule(key: MGKey.workoutUltra, targetValue: true, required: true),
                            MGSlotRule(key: MGKey.timeInDaylight, targetValue: true, required: false)
                        ]
                    )

                    PlainToggle(
                        L("[测试特性] 端侧 Siri Hub 路由与指令模型动态剪枝"),
                        subtitle: store.isSiriHubConflictActive()
                            ? L("⚠️ 检测到已开启（会卡死“正在添加 Siri 支持内容”），请直接关闭并重启恢复")
                            : L("已由防呆护栏自动锁定：SiriHub 属家居中枢专属路由，iPhone/iPad 开启会卡死 Siri"),
                        infoType: .warning,
                        infoTitle: L("端侧 Siri Hub 防呆锁定说明"),
                        infoMessage: MGMsg.expSiriHubInfo,
                        isOn: store.mgSafeSiriHubGuardrailBinding()
                    )
                    .disabled(!store.isSiriHubConflictActive())
                } header: {
                    HeaderLabel(L("实验性底层特性挖掘（测试特性）"), symbol: "flask")
                } footer: {
                    Text("所有标记 [测试特性] 的开关均严格运行在已校验的 8 字节布尔 CacheData 槽位内（零白苹果风险），但实际功能效果取决于本机协处理器与系统版本；修改后需手动重启手机生效。")
                }
                
                Section {
                    if !isCrashDectHD() || mgOverrideGates {
                        PlainToggle(L("车祸检测设置项"), isOn: store.mgKeyBinding([MGKey.crashDet]))
                    }
                    if !isPWMHD() || mgOverrideGates {
                        PlainToggle(L("PWM 调光开关"), minVrs: 19.0, isOn: store.mgKeyBinding([MGKey.pwm]))
                    }
                    if ogMachineName.contains("iPhone") || mgOverrideGates {
                        PlainToggle(L("Apple Pencil 设置项"), isOn: store.mgKeyBinding([MGKey.appPencil]))
                    }
                    if !isCamControlHD() || mgOverrideGates {
                        PlainToggle(L("相机控制按键设置项"), minVrs: 18.0, isOn: store.mgKeyBinding([MGKey.camButton, MGKey.grapPefr]))
                    }
                    if !isActionButtonHD() || mgOverrideGates {
                        PlainToggle(L("操作按钮 (Action Button)"), minVrs: 17.0, isOn: store.mgKeyBinding([MGKey.actButton]))
                    }
                    if isHomeButtonHD() || mgOverrideGates {
                        PlainToggle(L("轻点唤醒 (Tap to Wake)"), isOn: store.mgKeyBinding([MGKey.tapToWake]))
                    }
                } header: {
                    HeaderLabel(L("系统设置偏好面板"), symbol: "gear")
                }
                
                }
                .scrollContentBackground(.hidden)
                .background(NoxStyle.background)
            }
        }
            .navigationTitle("MobileGestalt (System Values)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("应用", role: .adaptiveConfirm) {
                        if extraSafetyReview && !hasShownSheet {
                            Alertinator.shared.runWhenPresentationIdle {
                                showInfoSheet = true
                            }
                        } else {
                            prepareApplyPreview()
                        }
                    }
                    .disabled(!hasWriteAccess && !weOnADebugBuild)
                }
            }
            .sheet(isPresented: $showInfoSheet, onDismiss: {
                if pendingPreviewAfterInfoSheet {
                    pendingPreviewAfterInfoSheet = false
                    prepareApplyPreview(isFromSheet: true)
                }
            }) {
                NavigationStack {
                    VStack {
                        InfoSheet(title: L("使用前必读")) {
                            InfoSheetCell(title: L("重要风险提示！"), symbol: "exclamationmark.triangle.fill", context: MGMsg.support)
                                .modifier(SectionPlatter())
                            InfoSheetCell(title: L("Apple 智能与机型伪装"), symbol: "apple.intelligence", context: MGMsg.spoofAI)
                            InfoSheetCell(title: L("iPadOS 界面模式"), symbol: "ipad", context: MGMsg.ipadOS)
                            InfoSheetCell(title: L("解除地区限制（国行解锁）"), symbol: "map", context: MGMsg.region)
                        } button: {
                            Button(idiotButtonTimerComplete ? L("我已知晓，查看变更预览") : L("请阅读上方提示（4 秒）...")) {
                                hasShownSheet = true
                                idiotButtonTimerComplete = false
                                pendingPreviewAfterInfoSheet = true
                                showInfoSheet = false
                            }
                            .buttonStyle(ConfirmButtonStyle())
                            .padding(.horizontal, 30)
                            .padding(.bottom, device.userInterfaceIdiom == .pad ? 25 : 0)
                            .disabled(!idiotButtonTimerComplete)
                        }
                    }
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                            idiotButtonTimerComplete = true
                        }
                    }
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("取消") {
                                pendingPreviewAfterInfoSheet = false
                                showInfoSheet = false
                                idiotButtonTimerComplete = false
                            }
                        }
                    }
                }
            }
            .sheet(item: $diffPreviewPayload) { payload in
                NavigationStack {
                    List {
                        Section {
                            ForEach(payload.diffs) { item in
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(item.label)
                                        .font(.subheadline.weight(.semibold))
                                    Text(item.keyPath)
                                        .font(.system(.caption2, design: .monospaced))
                                        .foregroundStyle(.secondary)
                                    HStack(alignment: .top, spacing: 6) {
                                        Text("修改前：")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                        Text(item.beforeText)
                                            .font(.system(.caption, design: .monospaced))
                                            .foregroundStyle(.secondary)
                                    }
                                    HStack(alignment: .top, spacing: 6) {
                                        Text("修改后：")
                                            .font(.caption.weight(.medium))
                                            .foregroundStyle(Color.accentColor)
                                        Text(item.afterText)
                                            .font(.system(.caption, design: .monospaced).weight(.semibold))
                                            .foregroundStyle(.primary)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                        } header: {
                            Text("共 \(payload.diffs.count) 项键值变更")
                        } footer: {
                            Text("点击“确认写入”后将自动备份当前缓存、执行原位写入并进行完整读回校验；若校验异常将自动回滚原文件。")
                        }
                    }
                    .navigationTitle("变更对比预览")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Button("取消") {
                                diffPreviewPayload = nil
                            }
                        }
                        ToolbarItem(placement: .topBarTrailing) {
                            Button("确认写入") {
                                let candidate = payload.candidate
                                diffPreviewPayload = nil
                                mgCommit(candidate)
                            }
                            .fontWeight(.semibold)
                        }
                    }
                }
            }
            .sheet(isPresented: $showInspectorSheet) {
                NavigationStack {
                    MGInspectorView(store: store)
                        .toolbar {
                            ToolbarItem(placement: .topBarLeading) {
                                Button("关闭") {
                                    showInspectorSheet = false
                                }
                            }
                        }
                }
            }
            .fileImporter(isPresented: $showBackupImporter,
                          allowedContentTypes: [.propertyList],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let url = urls.first else { return }
                    switch mgImportExternalOriginalBackup(from: url) {
                    case .success(let detail):
                        store.mgCurrentDict = mgLoadData()
                        Alertinator.shared.alert(title: "Backup imported", body: detail)
                    case .failure(let error):
                        Alertinator.shared.alert(title: "Backup import failed", body: error.localizedDescription)
                    }
                case .failure(let error):
                    Alertinator.shared.alert(title: "Backup picker failed", body: error.localizedDescription)
                }
            }
            .onAppear {
                if ogMachineName.isEmpty {
                    ogMachineName = machineName()
                }
                let isWritable = fm.isWritableFile(atPath: MGURL.fsGestaltURL.path)
                if isWritable {
                    hasWriteAccess = true
                } else {
                    let res = wq.grantAccess(path: MGURL.fsGestaltURL.deletingLastPathComponent().path)
                    hasWriteAccess = res.0 || fm.isWritableFile(atPath: MGURL.fsGestaltURL.path)
                    if !hasWriteAccess {
                        if res.1 == -1 {
                            Alertinator.shared.alert(
                                title: L("缺少 App Group 签名权限（result: -1）"),
                                body: L("当前侧载签名工具剥离了 App Group 容器权限，导致只能读取而无法写入 MobileGestalt。\n\n请更换保留 App Groups 能力的工具重新签名安装（免费个人自签推荐 SideStore / AltStore / Impactor / iLoader；证书重签请确保描述文件勾选了 App Groups 权限，切勿使用默认剥离权限的 Sideloadly 免费签）。")
                            )
                        } else {
                            Alertinator.shared.alert(title: L("获取 MobileGestalt 写入权限失败！"), body: L("错误码：\(res.1)（\(res.2)）。修改将无法保存生效，请尝试重启本应用后再试。"))
                        }
                    }
                }
                if !hasLoadedInitialData {
                    hasLoadedInitialData = true
                    store.mgCurrentDict = mgLoadData()
                } else {
                    dualVaultReady = mgHasSyncedSystemVault()
                }
                noxSpoofVersionText = store.noxSpoofedVersion
                noxSpoofBuildText = store.noxSpoofedBuild
            }
    }

    @ViewBuilder
    private func spatialAudioRecSlotRow() -> some View {
        let keys = [MGKey.spatialAudioRec]
        let canModify = store.canModifyFeatureSlot(keys)
        let isNativeOn = store.isFeatureSlotNativeEnabled(keys)
        let binding = store.mgFeatureSlotBinding(keys)
        let currentlyOn = binding.wrappedValue

        if isNativeOn && !mgOverrideGates {
            PlainToggle(
                L("空间音频录制（相机 / 语音备忘录录音室）"),
                subtitle: L("✅ 本机四麦克风阵列硬件已原生开启（无需额外修改，已锁定防误关）"),
                infoType: .info,
                infoTitle: L("空间音频录制说明"),
                infoMessage: MGMsg.spatialAudioRecInfo,
                isOn: .constant(true)
            )
            .disabled(true)
        } else if !isSpatialAudioRecHD() && !mgOverrideGates {
            PlainToggle(
                L("空间音频录制（相机 / 语音备忘录录音室）"),
                subtitle: currentlyOn
                    ? L("⚠️ 非四麦克风机型开启会导致语音备忘录出现无效“录音室”选项并点录音即停，请直接关闭并应用恢复")
                    : L("已由防呆护栏自动锁定：需 iPhone 16 系列起的四麦克风硬件（三麦克风旧机型强开会导致语音备忘录“录音室”无法录音）"),
                infoType: .warning,
                infoTitle: L("空间音频录制硬件防呆说明"),
                infoMessage: MGMsg.spatialAudioRecInfo,
                isOn: binding
            )
            .disabled(!canModify || !currentlyOn)
        } else {
            PlainToggle(
                L("空间音频录制（相机 / 语音备忘录录音室）"),
                subtitle: canModify ? L("解锁相机视频 3D 空间音频拾音与语音备忘录“录音室”模式（需四麦克风硬件）") : L("当前系统版本未包含或无法解析此二进制槽位"),
                infoType: .info,
                infoTitle: L("空间音频录制说明"),
                infoMessage: MGMsg.spatialAudioRecInfo,
                isOn: binding
            )
            .disabled(!canModify)
        }
    }

    @ViewBuilder
    private func featureSlotRow(
        title: String,
        subtitle: String,
        infoTitle: String,
        infoMessage: String,
        keys: [String]
    ) -> some View {
        let canModify = store.canModifyFeatureSlot(keys)
        let isNativeOn = store.isFeatureSlotNativeEnabled(keys)
        if isNativeOn && !mgOverrideGates {
            PlainToggle(
                title,
                subtitle: L("✅ 本机硬件已原生开启（无需额外修改，已锁定防误关）"),
                infoType: .info,
                infoTitle: infoTitle,
                infoMessage: infoMessage,
                isOn: .constant(true)
            )
            .disabled(true)
        } else {
            PlainToggle(
                title,
                subtitle: canModify ? subtitle : L("当前系统版本未包含或无法解析此二进制槽位"),
                infoType: .info,
                infoTitle: infoTitle,
                infoMessage: infoMessage,
                isOn: store.mgFeatureSlotBinding(keys)
            )
            .disabled(!canModify)
        }
    }

    @ViewBuilder
    private func experimentalSlotRuleRow(
        title: String,
        subtitle: String,
        infoTitle: String,
        infoMessage: String,
        rules: [MGSlotRule]
    ) -> some View {
        let canModify = store.canModifySlotRules(rules)
        let isNativeSatisfied = store.isSlotRulesNativeSatisfied(rules)
        if isNativeSatisfied && !mgOverrideGates {
            PlainToggle(
                title,
                subtitle: L("✅ 本机原厂默认已满足目标状态（无需额外修改，已锁定防误改）"),
                infoType: .info,
                infoTitle: infoTitle,
                infoMessage: infoMessage,
                isOn: .constant(true)
            )
            .disabled(true)
        } else {
            PlainToggle(
                title,
                subtitle: canModify ? subtitle : L("当前系统版本未包含或无法解析此实验性二进制槽位"),
                infoType: .info,
                infoTitle: infoTitle,
                infoMessage: infoMessage,
                isOn: store.mgSlotRulesBinding(rules)
            )
            .disabled(!canModify)
        }
    }

    private func isCurrentGestaltUnmodifiedComparedToOriginal(currentDict: NSDictionary, ogDict: NSDictionary) -> Bool {
        let curExtra = currentDict["CacheExtra"] as? NSDictionary ?? [:]
        let ogExtra = ogDict["CacheExtra"] as? NSDictionary ?? [:]
        let curProd = curExtra[MGKey.prodType] as? String ?? ""
        let ogProd = ogExtra[MGKey.prodType] as? String ?? currentOriginalMachineName()
        if !curProd.isEmpty && curProd != ogProd && curProd != currentOriginalMachineName() {
            return false
        }
        let knownTweakKeys: [String] = [
            MGKey.regionCode,
            MGKey.regionInfo,
            MGKey.regionSysconfig,
            MGKey.regModelNumber,
            MGKey.liquidGlassLowPower,
            MGKey.island,
            MGKey.AOTime,
            MGKey.AOD,
            MGKey.AODVibrancy,
            MGKey.chargeLim,
            MGKey.bootChime,
            MGKey.intInstall,
            MGKey.intBuild,
            MGKey.srd,
            MGKey.crashDet,
            MGKey.pwm,
            MGKey.appPencil,
            MGKey.camButton,
            MGKey.grapPefr,
            MGKey.actButton,
            MGKey.tapToWake,
            MGKey.stageMgr,
            MGKey.modelNameOuter1,
            MGKey.modelNameOuter2
        ] + MGKey.appIntellAllKeys + MGKey.advAppIntellKeys + MGKey.mediaHealthAllKeys + MGKey.experimentalCacheSlotKeys + MGKey.ipadosCacheEx
        for key in knownTweakKeys {
            if !mgPlistValuesEqual(curExtra[key], ogExtra[key]) {
                return false
            }
        }
        if let curArt = curExtra[MGKey.artwork] as? NSDictionary,
           let ogArt = ogExtra[MGKey.artwork] as? NSDictionary {
            if !mgPlistValuesEqual(curArt["ArtworkDeviceSubType"], ogArt["ArtworkDeviceSubType"]) ||
               !mgPlistValuesEqual(curArt["ArtworkDeviceProductDescription"], ogArt["ArtworkDeviceProductDescription"]) {
                return false
            }
        }
        if case .success((let layout, let curData)) = MGCacheDataCoordinator.shared.resolveValidated(for: currentDict),
           let origFlags = MGCacheDataCoordinator.shared.originalFlags(for: layout, savedOriginalDict: ogDict) {
            let curGT = curData[layout.greenTeaOffset] == 1
            let curNGT = curData[layout.notGreenTeaOffset] == 1
            if curGT != origFlags.greenTea || curNGT != origFlags.notGreenTea {
                return false
            }
            if let wOff = layout.wapiOffset, let origWapi = origFlags.wapi {
                if (curData[wOff] == 1) != origWapi {
                    return false
                }
            }
            for (fKey, fSlot) in layout.featureSlotIndices where layout.validateSingleBooleanSlot(fSlot, in: curData) {
                if let origVal = origFlags.extraSlots?[fKey], (curData[fSlot * 8] == 1) != origVal {
                    return false
                }
            }
        }
        return true
    }
    
    private func mgLoadData() -> NSMutableDictionary {
        do {
            let mgData = try Data(contentsOf: MGURL.fsGestaltURL)
            let preCheck = mgValidatePlistData(mgData)
            guard preCheck.0 else {
                throw preCheck.1
            }
            let vaultOutcome = try mgEnsureOriginalBackupWithVault(liveData: mgData)
            dualVaultReady = mgHasSyncedSystemVault()
            if vaultOutcome.recoveredFromVault {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    Alertinator.shared.alert(
                        title: L("已自动找回原厂初始备份！"),
                        body: L("检测到应用曾卸载重装，已从系统安全金库无损恢复你最初未修改的原厂 MobileGestalt 备份（SHA-256 校验通过）。")
                    )
                }
            } else if let dirtyWarn = vaultOutcome.suspectedDirtyWarning {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                    Alertinator.shared.alert(
                        title: L("首次备份异常状态提示"),
                        body: L("\(dirtyWarn)\n\n当前系统状态已被保存为初始备份。若希望获取 100% 纯净原厂基线，可在右上角菜单选择「清除并重建缓存」并重启，或在「高级设置」导入你之前保存的原厂备份。")
                    )
                }
            }
            
            guard let ogDict = NSDictionary(contentsOf: MGURL.savedGestaltURL),
                  let ogCacheExtra = ogDict["CacheExtra"] as? NSDictionary,
                  let ogArtwork = ogCacheExtra[MGKey.artwork] as? NSDictionary else {
                throw L("无法从 MobileGestalt 读取原始硬件配置")
            }
            
            mgOgSubtype = ogArtwork["ArtworkDeviceSubType"] as? Int ?? 0
            mgOgDeviceName = ogArtwork["ArtworkDeviceProductDescription"] as? String ?? ""
            
            let ogRegionCode = ogCacheExtra[MGKey.regionCode] as? String ?? ""
            let ogRegionSysconfig = ogCacheExtra[MGKey.regionSysconfig] as? String ?? ""
            let localeRegion = Locale.current.region?.identifier ?? ""
            if ogRegionCode != "LL" || ogRegionSysconfig != "LL/A" || localeRegion != "US" {
                showRegionTweak = true
            }
            
            guard let parsedBaseline = try PropertyListSerialization.propertyList(from: mgData, options: [], format: nil) as? NSDictionary,
                  let currentDict = try PropertyListSerialization.propertyList(from: mgData, options: [.mutableContainersAndLeaves], format: nil) as? NSMutableDictionary else {
                throw L("无法解析 MobileGestalt 字典数据")
            }
            mgBaselineDict = parsedBaseline
            MGCacheDataCoordinator.shared.recordBaselineIfNeeded(liveDict: currentDict, savedOriginalDict: ogDict)
            if !showRegionTweak,
               case .success((let layout, let curData)) = MGCacheDataCoordinator.shared.resolveValidated(for: currentDict, checkWapiSlot: true) {
                let origFlags = MGCacheDataCoordinator.shared.originalFlags(for: layout, savedOriginalDict: ogDict)
                if origFlags?.greenTea == true || origFlags?.wapi == true || (layout.wapiOffset.map { curData[$0] == 1 } ?? false) {
                    showRegionTweak = true
                }
            }
            switch MGCacheDataCoordinator.shared.resolveValidated(for: currentDict) {
            case .success((let layout, _)):
                let wapiDesc = layout.wapiOffset.map { String(format: "0x%X", $0) } ?? "N/A"
                print(String(format: "[*] (mg-cache) 本机动态解析成功：UUID=%@, 槽位=%d (%d字节), green-tea=0x%X, not-green-tea=0x%X, wapi=%@".loc,
                             layout.uuid, layout.slotCount, layout.byteCount, layout.greenTeaOffset, layout.notGreenTeaOffset, wapiDesc))
            case .failure(let err):
                print(L("[!] (mg-cache) 本机动态解析未通过，已锁定二进制缓存修改：\(err.localizedDescription)"))
            }
            
            if let cacheExtra = currentDict["CacheExtra"] as? NSDictionary,
               let artwork = cacheExtra[MGKey.artwork] as? NSDictionary {
                mgSubtype = artwork["ArtworkDeviceSubType"] as? Int ?? 0
                mgDeviceName = artwork["ArtworkDeviceProductDescription"] as? String ?? ""
                mgEnableDeviceName = (!mgDeviceName.isEmpty && mgDeviceName != mgOgDeviceName)
                mgProductType = cacheExtra[MGKey.prodType] as? String ?? currentOriginalMachineName()
                
                // Detect OS upgrade build mismatch between OriginalGestalt.plist and live MobileGestalt
                let ogBuild = ogDict["CacheVersion"] as? String ?? ""
                let curBuild = currentDict["CacheVersion"] as? String ?? ""
                if !hasPromptedBuildMismatch && !ogBuild.isEmpty && !curBuild.isEmpty && ogBuild != curBuild {
                    hasPromptedBuildMismatch = true
                    if isCurrentGestaltUnmodifiedComparedToOriginal(currentDict: currentDict, ogDict: ogDict) {
                        Alertinator.shared.alert(
                            title: L("检测到系统版本已更新"),
                            body: L("原始备份文件来自旧版系统 (\(ogBuild))，而当前系统已更新至 \(curBuild)（当前缓存处于原厂未修改状态）。\n\n建议立即将原始备份同步更新为 \(curBuild) 的原厂文件，以免后续误用旧版备份覆盖。"),
                            actionLabel: L("更新原始备份"),
                            action: {
                                try? mgSaveOriginalBackupWithDigest(mgData)
                                store.mgCurrentDict = mgLoadData()
                            }
                        )
                    } else {
                        print("(mg) notice: savedGestalt CacheVersion (\(ogBuild)) differs from current (\(curBuild))")
                    }
                }
            }
            
            return currentDict
        } catch {
            print("(mg) failed to get mobilegestalt: \(error.localizedDescription)")
            Haptic.shared.play(.heavy)
            Alertinator.shared.alert(title: L("读取 MobileGestalt 失败！"), body: L("当前无法正常加载配置文件，请返回上一页并检查日志。"), showCancel: false, actionLabel: L("返回"), action: { dismiss() })
        }
        
        return [:]
    }
    
    private func buildCandidateDict() throws -> NSMutableDictionary {
        let snapshotData = try PropertyListSerialization.data(fromPropertyList: store.mgCurrentDict, format: .binary, options: 0)
        guard let candidate = try PropertyListSerialization.propertyList(from: snapshotData, options: [.mutableContainersAndLeaves], format: nil) as? NSMutableDictionary,
              let cacheExtra = candidate["CacheExtra"] as? NSMutableDictionary else {
            throw L("无法构建待写入的 CacheExtra 字典！")
        }
        guard let artwork = cacheExtra[MGKey.artwork] as? NSMutableDictionary else {
            throw L("检测到 ArtworkTraits (\(MGKey.artwork)) 字段缺失或非有效字典结构，为防止丢失屏幕特征已拦截写入！")
        }
        
        let targetSubtype = mgOverrideGates ? mgSubtype : mgOgSubtype
        if targetSubtype > 0 {
            artwork["ArtworkDeviceSubType"] = targetSubtype
        }
        let trimmedName = mgDeviceName.trimmingCharacters(in: .whitespacesAndNewlines)
        if mgEnableDeviceName {
            guard !trimmedName.isEmpty else {
                throw L("开启“自定义机型名称”时名称不能为空！")
            }
            artwork["ArtworkDeviceProductDescription"] = trimmedName
            cacheExtra[MGKey.modelNameOuter1] = trimmedName
            cacheExtra[MGKey.modelNameOuter2] = trimmedName
        } else {
            if !mgOgDeviceName.isEmpty {
                artwork["ArtworkDeviceProductDescription"] = mgOgDeviceName
            }
            for outerKey in [MGKey.modelNameOuter1, MGKey.modelNameOuter2] {
                if let ogVal = store.originalCacheExtraValue(forKey: outerKey) {
                    cacheExtra[outerKey] = ogVal
                } else {
                    cacheExtra.removeObject(forKey: outerKey)
                }
            }
        }
        
        let safeProdType = (!isAppleIntellHD() || mgOverrideGates) ? mgProductType : currentOriginalMachineName()
        if !safeProdType.isEmpty {
            cacheExtra[MGKey.prodType] = safeProdType
        }
        for item in customKeys {
            if let blockedReason = mgIsDangerousCacheExtraKey(item.key) {
                if item.isOn {
                    throw L("自定义键 \(item.key) 已被防白苹果护栏拦截：\(blockedReason)")
                }
                continue
            }
            if item.isOn {
                cacheExtra[item.key] = item.plistValue
            } else if let ogVal = store.originalCacheExtraValue(forKey: item.key) {
                cacheExtra[item.key] = ogVal
            } else {
                cacheExtra.removeObject(forKey: item.key)
            }
        }

        // Self-healing sanitizer: strip non-cached iOS 27 keys and binary CacheData slot keys from CacheExtra
        // in case the device was previously polluted by an older third-party tool before installing Erosion-CN.
        if raveSupported() {
            cacheExtra.removeObject(forKey: MGKey.regionInfo)
            cacheExtra.removeObject(forKey: "0L5PkT61qoH1b/B1USWqjQ")
        }
        for conflictKey in ["iyfxmLogGVIaH7aEgqwcIA", "4snMZS8LJkSctKypt2m+xA", "hiHut/WR+B9Lx/vd0WyeNg", "green-tea", "not-green-tea", "wapi"] + MGKey.advAppIntellKeys + MGKey.mediaHealthAllKeys + MGKey.experimentalCacheSlotKeys {
            cacheExtra.removeObject(forKey: conflictKey)
        }
        return candidate
    }
    
    private func prepareApplyPreview(isFromSheet: Bool = false) {
        do {
            let candidate = try buildCandidateDict()
            if case .failure(let cacheErr) = MGCacheDataCoordinator.shared.validateTransition(from: mgBaselineDict, to: candidate) {
                throw cacheErr.localizedDescription
            }
            let diffs = mgComputeDiff(from: mgBaselineDict, to: candidate)
            if diffs.isEmpty {
                Alertinator.shared.alert(title: L("没有待应用的更改"), body: L("当前各项配置与系统缓存文件中的内容完全一致，无需重复写入。"), showCancel: true)
                return
            }
            let payload = MGDiffPreviewPayload(diffs: diffs, candidate: candidate)
            if diffPreviewPayload != nil {
                diffPreviewPayload = nil
            }
            Alertinator.shared.runWhenPresentationIdle {
                diffPreviewPayload = payload
            }
        } catch {
            Alertinator.shared.alert(title: L("无法生成变更预览"), body: "\(error.localizedDescription)")
        }
    }

    private func mgCommit(_ mgDictToApply: NSMutableDictionary) {
        do {
            let cacheDataChanged = (mgBaselineDict["CacheData"] as? Data) != (mgDictToApply["CacheData"] as? Data)
            let data = try PropertyListSerialization.data(fromPropertyList: mgDictToApply, format: .binary, options: 0)
            let res = mgWriteDetailed(data)
            
            if res.0 {
                print("[*] successfully overwrote and verified mobilegestalt!")
                Haptic.shared.play(.soft)
                store.mgCurrentDict = mgLoadData()
                if autoRespring && !cacheDataChanged {
                    mgr.shouldRespring = true
                } else {
                    let needsRebootHint = store.isEnabled([MGKey.appIntell]) || store.mgRegionRestrictionsBinding().wrappedValue
                    var extraHint = ""
                    if cacheDataChanged {
                        extraHint = L("\n\n⚠️ 本次修改了底层二进制缓存（国行底层限制 / Wi-Fi 显示 / 影像与健康硬件槽位），仅注销无法完全刷新系统守护进程，请务必【手动重启一次手机】使其生效！")
                    } else if needsRebootHint {
                        extraHint = L("\n\n若修改了地区限制或 Apple 智能，注销后建议手动重启一次设备以使 eligibilityd 完全刷新。")
                    }
                    Alertinator.shared.alert(
                        title: L("写入并读回校验成功！"),
                        body: AppMsg.applied + extraHint,
                        actionLabel: L("立即注销"),
                        action: { mgr.shouldRespring = true }
                    )
                }
            } else {
                throw res.1
            }
        } catch {
            print("(mg) failed to apply mobilegestalt: \(error.localizedDescription)")
            Alertinator.shared.alert(title: L("应用 MobileGestalt 失败！"), body: "\(error.localizedDescription)")
        }
    }
    
    // These sections are kept separate to preserve SwiftUI compile performance.
    private var coreSystemSection: some View {
        Section {
            HStack(spacing: 9) {
                Image(systemName: "lock.shield.fill")
                    .foregroundStyle(NoxStyle.cyan)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Locked Supervised Mode")
                        .font(.subheadline.weight(.semibold))
                    Text("Actual device supervision is controlled by iOS/MDM, not a MobileGestalt boolean.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Text("iOS-managed").font(.caption2.weight(.bold)).foregroundStyle(.orange)
            }
            NavigationLink {
                NoxSupervisedTweaksView()
            } label: {
                Label("Supervised Profile Tools", systemImage: "list.bullet.rectangle")
            }
            if machineName().contains("iPad") {
                Toggle(isOn: store.mgKeyBinding([MGKey.stageMgr])) {
                    Label("iPadOS Multitasking / Stage Manager", systemImage: "rectangle.split.2x1")
                }
                .tint(NoxStyle.accent)
            } else {
                Toggle("Enable iPadOS UI / Split View", isOn: .constant(false))
                    .disabled(true)
                Text("Unavailable on iPhone: the original project's unverified iPadOS patch can cause bootloops. Native iPad multitasking is configurable on iPad.")
                    .font(.caption2).foregroundStyle(.orange)
            }
            let advNative = isAdvAppleIntellHD()
            let advConflict = store.isAdvAppleIntellConflictActive()
            Toggle(isOn: advNative ? .constant(true) : store.mgSafeAdvAppleIntellGuardrailBinding()) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("iOS 27 Intelligence Capabilities")
                    Text(advNative ? "Native hardware capability" : (advConflict ? "Restore a conflicting experimental slot" : "Unavailable on this device / cache layout"))
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .tint(NoxStyle.accent)
            .disabled(advNative || !advConflict)
        } header: {
            HeaderLabel("CORE SYSTEM CAPABILITIES", symbol: "shield.lefthalf.filled")
        } footer: {
            Text("A toggle stages a MobileGestalt change only when its underlying key is verified. It cannot create supervision, iPadOS hardware features, or Apple Intelligence support on an incompatible device.")
        }
    }

    // Imported from WorkTweaks 6.1 / Regitela 1.0.7, after checking existing
    // MGKey controls to avoid duplicating AOD, camera, Stage Manager, etc.
    private var importedUniqueTweaksSection: some View {
        Section {
            Toggle("Disable Wallpaper Parallax", isOn: store.mgKeyBinding(["UIParallaxCapability"], defaultValue: 1, enableValue: 0))
                .tint(NoxStyle.accent)
            Toggle("Allow iPad Apps", isOn: Binding(
                get: { (store.cacheExtra["9MZ5AdH43csAUajl/dU+IQ"] as? [Int]) == [1, 2] },
                set: { enabled in
                    store.objectWillChange.send()
                    if enabled { store.cacheExtra["9MZ5AdH43csAUajl/dU+IQ"] = [1, 2] }
                    else { store.cacheExtra.removeObject(forKey: "9MZ5AdH43csAUajl/dU+IQ") }
                }
            ))
            .tint(NoxStyle.accent)
            Toggle("Security Research Device Flag", isOn: store.mgKeyBinding(["XYlJKKkj2hztRP1NWWnhlw"]))
                .tint(NoxStyle.accent)
            Toggle("Internal Storage View", isOn: store.mgKeyBinding(["LBJfwOEzExRxzlAnSuI7eg"]))
                .tint(NoxStyle.accent)
        } header: {
            HeaderLabel("IMPORTED · UNIQUE MOBILEGESTALT KEYS", symbol: "square.stack.3d.up")
        } footer: {
            Text("WorkTweaks/Regitela key mappings. These stage MobileGestalt cache values using NOXERRA's existing backup and Apply workflow. A visible switch does not guarantee the underlying iOS feature works on this device.")
        }
    }

    private var customizationSection: some View {
        Section {
            NavigationLink {
                NoxSystemMediaLibraryView(mode: .launchImages)
            } label: {
                Label("App Launch Images", systemImage: "photo.on.rectangle.angled")
            }
            NavigationLink {
                NoxSystemMediaLibraryView(mode: .audioLibrary)
            } label: {
                Label("App Audio Library", systemImage: "waveform")
            }
        } header: {
            HeaderLabel("APP CUSTOMIZATION", symbol: "square.stack.3d.up")
        } footer: {
            Text("Import and preview images or audio in NOXERRA. Applying these files to other apps requires separate verified access and is not enabled here.")
        }
    }

    private var systemUtilitiesSection: some View {
        Section {
            Button {
                store.mgCurrentDict = mgLoadData()
                Haptic.shared.play(.soft)
            } label: {
                Label("Discard Unsaved Changes", systemImage: "arrow.counterclockwise")
            }
            Button {
                promptFactoryRestore()
            } label: {
                Label("Restore Factory Backup", systemImage: "arrow.uturn.backward.circle")
            }
            .disabled(!hasWriteAccess && !weOnADebugBuild)
            Button(role: .destructive) { confirmCacheRebuild() } label: {
                Label("Clear & Rebuild Cache", systemImage: "trash")
            }
            .disabled(!hasWriteAccess && !weOnADebugBuild)
            Button {
                if let url = makeTemp(MGURL.fsGestaltURL) { presentShareSheet(with: url) }
            } label: {
                Label("Export Current MobileGestalt", systemImage: "square.and.arrow.up")
            }
            Button {
                presentShareSheet(with: MGURL.savedGestaltURL)
            } label: {
                Label("Export Factory Backup", systemImage: "square.and.arrow.up")
            }
            Button { showBackupImporter = true } label: {
                Label("Import Factory Backup (.plist)", systemImage: "square.and.arrow.down")
            }
            if fm.fileExists(atPath: MGURL.preApplyGestaltURL.path) {
                Button { presentShareSheet(with: MGURL.preApplyGestaltURL) } label: {
                    Label("Export Pre-Apply Snapshot", systemImage: "clock.arrow.circlepath")
                }
            }
            Button(role: .destructive) { confirmRegenerateBackup() } label: {
                Label("Regenerate Factory Backup", systemImage: "arrow.triangle.2.circlepath")
            }
            Toggle("Show Advanced MobileGestalt Tweaks", isOn: $mgOverrideGates)
                .tint(NoxStyle.accent)
            HStack {
                Label("Safe in-place write · F_FULLFSYNC", systemImage: "checkmark.shield")
                Spacer()
                Text("Core locked").font(.caption2).foregroundStyle(.green)
            }
            HStack {
                Label("System Vault Backup", systemImage: "externaldrive.badge.checkmark")
                Spacer()
                Text(dualVaultReady ? "Verified" : "Check status")
                    .font(.caption2).foregroundStyle(dualVaultReady ? .green : .orange)
            }
        } header: {
            HeaderLabel("SYSTEM UTILITIES & SETTINGS", symbol: "wrench.and.screwdriver")
        } footer: {
            Text("Backups, rollback and write verification remain enforced. Advanced tweak visibility does not bypass compatibility checks.")
        }
    }

    private func confirmCacheRebuild() {
        Alertinator.shared.alert(title: L("确定要彻底重建原厂 MobileGestalt 缓存吗？"), body: MGMsg.mgReset,
                                 actionLabel: L("确认重建"), action: {
            switch mgExecuteCleanCacheRebuild() {
            case .success:
                Alertinator.shared.alert(title: L("已准备原厂缓存重建！"), body: MGMsg.mgResetComp,
                                         showCancel: false, actionLabel: L("退出并手动重启"), action: { exitinator() })
            case .failure(let err):
                Alertinator.shared.alert(title: L("重建缓存失败！"), body: err.localizedDescription)
            }
        })
    }

    private func confirmRegenerateBackup() {
        Alertinator.shared.alert(title: L("警告！"), body: MGMsg.mgResetSavWarn,
                                 actionLabel: L("确认覆盖"), action: {
            try? fm.removeItem(at: MGURL.savedGestaltURL)
            try? fm.removeItem(at: MGURL.savedGestaltSHA256URL)
            try? fm.removeItem(at: MGURL.systemVaultGestaltURL)
            try? fm.removeItem(at: MGURL.systemVaultSHA256URL)
            MGCacheDataCoordinator.shared.clearRecordedBaselines()
            store.mgCurrentDict = mgLoadData()
            dualVaultReady = mgHasSyncedSystemVault()
        })
    }

    private func promptFactoryRestore() {
        Alertinator.shared.alert(
            title: L("确认一键恢复本机原厂参数？"),
            body: MGMsg.revertConfirm,
            actionLabel: L("确认恢复原厂"),
            action: {
                mgRevert()
            }
        )
    }

    private func mgRevert() {
        switch mgExecuteFactoryRestore(alsoResetConfigAndKeypad: false) {
        case .restoredSuccessfully(let details):
            print("[*] successfully reverted and verified mobilegestalt!")
            Haptic.shared.play(.soft)
            mgEnableDeviceName = false
            store.mgCurrentDict = mgLoadData()
            Alertinator.shared.alert(
                title: L("已恢复并校验原厂参数！"),
                body: details,
                actionLabel: L("立即注销"),
                action: { mgr.shouldRespring = true }
            )
        case .blockedNeedsCleanRebuild(let title, let reason):
            Alertinator.shared.alert(
                title: title,
                body: reason,
                actionLabel: L("重建系统纯净原厂缓存"),
                action: {
                    switch mgExecuteCleanCacheRebuild(alsoResetConfigAndKeypad: false) {
                    case .success:
                        Alertinator.shared.alert(
                            title: L("已准备原厂缓存重建！"),
                            body: MGMsg.mgResetComp,
                            showCancel: false,
                            actionLabel: L("退出并手动重启"),
                            action: { exitinator() }
                        )
                    case .failure(let err):
                        Alertinator.shared.alert(title: L("重建缓存失败！"), body: err.localizedDescription)
                    }
                }
            )
        case .failed(let reason):
            print("(mg) failed to revert mobilegestalt: \(reason)")
            Alertinator.shared.alert(title: L("还原 MobileGestalt 失败！"), body: reason)
        }
    }
}


// A separate view keeps the already-large MobileGestalt list compiler-friendly.
// All mutations remain staged in GestaltStore and use the parent's Apply flow.
private struct NoxMGIdentitySection: View {
    @ObservedObject var store: GestaltStore
    @Binding var noxSpoofVersionText: String
    @Binding var noxSpoofBuildText: String
    @Binding var noxDemoConfirmation: Bool

    var body: some View {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("Spoof iOS Version", systemImage: "iphone.gen3")
                            .font(.subheadline.weight(.semibold))
                        Text("Edits MobileGestalt's ProductVersion, BuildVersion and HumanVersion cache entries. It does not install a different iOS release.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        TextField("Version, e.g. 26.2", text: $noxSpoofVersionText)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .keyboardType(.numbersAndPunctuation)
                        TextField("Build, e.g. 23C55", text: $noxSpoofBuildText)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                        VStack(alignment: .leading, spacing: 8) {
                            Button("Stage Version Spoof") {
                                if let message = store.noxStageVersionSpoof(version: noxSpoofVersionText,
                                                                            build: noxSpoofBuildText) {
                                    Alertinator.shared.alert(title: "Invalid version", body: message)
                                } else {
                                    Haptic.shared.play(.soft)
                                }
                            }
                            .buttonStyle(.borderedProminent)
                            Button("Restore Original") {
                                store.noxRestoreOriginalVersionValues()
                                noxSpoofVersionText = store.noxSpoofedVersion
                                noxSpoofBuildText = store.noxSpoofedBuild
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .padding(.vertical, 4)
                    Toggle(isOn: Binding(get: { store.noxStoreDemoEnabled }, set: { enabled in
                        if enabled {
                            noxDemoConfirmation = true
                        } else {
                            store.noxStageStoreDemo(enabled: false)
                        }
                    })) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Store Demo Mode")
                            Text("Stages Gester's StoreDemoMode key. Can change device setup and retail-demo behavior.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .alert("Enable Store Demo Mode?", isPresented: $noxDemoConfirmation) {
                        Button("Enable", role: .destructive) {
                            store.noxStageStoreDemo(enabled: true)
                        }
                        Button("Cancel", role: .cancel) {}
                    } message: {
                        Text("Store Demo Mode may affect system setup and device behavior. Keep an original MobileGestalt backup so you can restore it.")
                    }
                } header: {
                    HeaderLabel("Device Identity · Gester", symbol: "iphone.gen3")
                } footer: {
                    Text("These settings are staged only. Use Apply at the top to inspect the changes before writing. An original backup is required; a reboot may be needed. Version spoofing is not a system update.")
                }
    }
}

#Preview {
    ContentView()
}
