import SwiftUI
import PhotosUI
import UIKit
import UniformTypeIdentifiers
import AVKit

// NOXERRA native wallpaper composition studio. Preview is local; installation remains
// with the existing PosterBoard .tendies importer and video packager.
struct NoxWallpaperStudioView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var lockItem: PhotosPickerItem?
    @State private var homeItem: PhotosPickerItem?
    @State private var lockImage: UIImage?
    @State private var homeImage: UIImage?
    @State private var activePreview = 0
    @State private var scale: Double = 1
    @State private var vertical: Double = 0
    @State private var dim: Double = 0.22
    @State private var blur: Double = 0
    @State private var clockDepth = true
    @State private var showDate = true
    @State private var morph: Double = 0
    @State private var unlockedImage: UIImage?
    @State private var unlockItem: PhotosPickerItem?
    @State private var nightItem: PhotosPickerItem?
    @State private var nightImage: UIImage?
    @State private var nightPreview = false
    @State private var particleStyle = 0
    @State private var transitionStyle = 0
    @State private var parallax = false
    @State private var transitionDuration: Double = 0.75
    @State private var showAnimation = false
    @State private var exportImage: UIImage?
    @State private var showShare = false
    @State private var error: String?
    @State private var showVideoImporter = false
    @State private var previewVideoURL: URL?
    @State private var videoPlayer: AVPlayer?
    @State private var previewVideo = false

    private let violet = Color(red: 0.68, green: 0.34, blue: 1)
    private let cyan = Color(red: 0.26, green: 0.87, blue: 1)

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 6) {
                    Label("NOXERRA WALLPAPER STUDIO", systemImage: "sparkles.rectangle.stack")
                        .font(.caption.weight(.black)).tracking(1.3).foregroundStyle(cyan)
                    Text("Create your perfect screen")
                        .font(.title2.bold())
                    Text("Import images, tune the look, and preview your Lock Screen, Sleep display, and Home Screen before exporting.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(violet.opacity(0.13), in: RoundedRectangle(cornerRadius: 20))

                HStack(spacing: 10) {
                    PhotosPicker(selection: $lockItem, matching: .images) {
                        Label("Lock image", systemImage: "lock.display")
                            .frame(maxWidth: .infinity)
                    }
                    PhotosPicker(selection: $homeItem, matching: .images) {
                        Label("Home image", systemImage: "house")
                            .frame(maxWidth: .infinity)
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(violet)

                HStack(spacing: 10) {
                    PhotosPicker(selection: $unlockItem, matching: .images) {
                        Label("Unlocked image", systemImage: "lock.open.fill")
                    }
                    PhotosPicker(selection: $nightItem, matching: .images) {
                        Label("Night image", systemImage: "moon.stars.fill")
                    }
                }
                .buttonStyle(.bordered)
                .tint(cyan)
                Toggle("Preview night wallpaper", isOn: $nightPreview)
                    .disabled(nightImage == nil)
                Button { showVideoImporter = true } label: {
                    Label("Import video for live preview", systemImage: "video.badge.plus")
                }
                .buttonStyle(.bordered)
                if let videoPlayer {
                    VStack(alignment: .leading, spacing: 8) {
                        Toggle("Show video preview", isOn: $previewVideo)
                        if previewVideo {
                            VideoPlayer(player: videoPlayer)
                                .frame(height: 270)
                                .clipShape(RoundedRectangle(cornerRadius: 18))
                                .onAppear { videoPlayer.play() }
                                .onDisappear { videoPlayer.pause() }
                        }
                        Text("Video playback is local. Use Video → .tendies to package an animated wallpaper.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }
                Picker("Preview", selection: $activePreview) {
                    Text("Locked").tag(0)
                    Text("Sleep").tag(1)
                    Text("Home").tag(2)
                    Text("Unlocked").tag(3)
                }
                .pickerStyle(.segmented)

                GeometryReader { geometry in
                    let width = min(geometry.size.width, 295.0)
                    ZStack {
                        RoundedRectangle(cornerRadius: 37)
                            .fill(.black)
                            .shadow(color: violet.opacity(0.45), radius: 18)
                        wallpaperImage
                            .overlay {
                                if particleStyle != 0 {
                                    NoxStudioParticles(style: particleStyle)
                                        .allowsHitTesting(false)
                                }
                            }
                            .frame(width: width - 12, height: width * 2.05 - 12)
                            .clipped()
                            .overlay(.black.opacity(activePreview == 1 ? min(0.88, dim + 0.43) : dim))
                            .clipShape(RoundedRectangle(cornerRadius: 32))
                        if activePreview != 2 {
                            VStack(spacing: 2) {
                                if showDate {
                                    Text(Date.now.formatted(.dateTime.weekday(.wide).month(.wide).day()))
                                        .font(.system(size: 13, weight: .medium))
                                }
                                Text(Date.now.formatted(.dateTime.hour().minute()))
                                    .font(.system(size: 62, weight: .thin, design: .rounded))
                                    .minimumScaleFactor(0.7)
                                    .shadow(color: clockDepth ? .black.opacity(0.45) : .clear, radius: 7, y: 2)
                                Spacer()
                                if activePreview == 0 {
                                    HStack {
                                        Image(systemName: "flashlight.off.fill")
                                        Spacer()
                                        Image(systemName: "camera.fill")
                                    }
                                    .font(.title3)
                                    .padding(.horizontal, 38)
                                    .padding(.bottom, 34)
                                }
                            }
                            .foregroundStyle(.white)
                            .padding(.top, 86)
                            .padding(.horizontal, 15)
                        } else {
                            VStack {
                                Spacer().frame(height: 75)
                                HStack(spacing: 20) {
                                    ForEach(["message.fill", "calendar", "photo.fill", "camera.fill"], id: \.self) { icon in
                                        Image(systemName: icon)
                                            .font(.title2)
                                            .frame(width: 42, height: 42)
                                            .background(.white.opacity(0.18), in: RoundedRectangle(cornerRadius: 12))
                                    }
                                }
                                Spacer()
                                HStack(spacing: 20) {
                                    ForEach(["phone.fill", "safari.fill", "music.note", "gearshape.fill"], id: \.self) { icon in
                                        Image(systemName: icon)
                                            .font(.title2)
                                            .frame(width: 42, height: 42)
                                            .background(.white.opacity(0.2), in: RoundedRectangle(cornerRadius: 12))
                                    }
                                }
                                .padding(.bottom, 35)
                            }
                            .foregroundStyle(.white)
                        }
                        VStack {
                            Capsule().fill(.black).frame(width: 88, height: 23).padding(.top, 14)
                            Spacer()
                        }
                    }
                    .frame(width: width, height: width * 2.05)
                    .frame(maxWidth: .infinity)
                }
                .frame(height: 610)
                Text("Simulated preview · Actual system appearance may differ")
                    .font(.caption2).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)

                VStack(alignment: .leading, spacing: 13) {
                    Label("IMAGE ADJUSTMENTS", systemImage: "slider.horizontal.3")
                        .font(.caption.bold()).foregroundStyle(cyan)
                    sliderRow("Zoom", value: $scale, range: 1...2)
                    sliderRow("Vertical position", value: $vertical, range: -130...130)
                    sliderRow("Dim", value: $dim, range: 0...0.7)
                    sliderRow("Blur", value: $blur, range: 0...12)
                    Text("MORPH & ANIMATION").font(.caption.bold()).foregroundStyle(cyan)
                    Picker("Transition", selection: $transitionStyle) {
                        Text("Crossfade").tag(0)
                        Text("Slide Up").tag(1)
                        Text("Zoom Reveal").tag(2)
                        Text("Curtain").tag(3)
                    }
                    .pickerStyle(.menu)
                    sliderRow("Morph progress", value: $morph, range: 0...1)
                    sliderRow("Transition duration", value: $transitionDuration, range: 0.25...2.5)
                    Picker("Particle overlay", selection: $particleStyle) {
                        Text("None").tag(0)
                        Text("Starlight").tag(1)
                        Text("Snowfall").tag(2)
                        Text("Embers").tag(3)
                    }
                    .pickerStyle(.menu)
                    Toggle("Motion parallax preview", isOn: $parallax)
                    Button {
                        morph = 0
                        withAnimation(.easeInOut(duration: transitionDuration)) { morph = 1 }
                    } label: { Label("Play morph preview", systemImage: "play.fill") }
                        .disabled(unlockedImage == nil)
                    Text("Morph, particles and parallax are previews only; still-image export does not preserve animation.")
                        .font(.caption2).foregroundStyle(.secondary)
                    Toggle("Clock shadow / depth preview", isOn: $clockDepth)
                    Toggle("Show Lock Screen date", isOn: $showDate)
                    Button("Reset adjustments", systemImage: "arrow.counterclockwise") {
                        scale = 1; vertical = 0; dim = 0.22; blur = 0; morph = 0
                    }
                    .font(.subheadline)
                }
                .padding(16)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20))

                Button {
                    exportImage = renderWallpaper()
                    showShare = exportImage != nil
                } label: {
                    Label("Export wallpaper image", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(violet)
                .disabled(lockImage == nil && homeImage == nil)

                Text("For animated .tendies packages, use the existing Video → .tendies maker. Exporting a still image does not install a system wallpaper.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(16)
        }
        .navigationTitle("Wallpaper Studio")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: lockItem) { _, item in Task { await load(item, home: false) } }
        .onChange(of: homeItem) { _, item in Task { await load(item, home: true) } }
        .onChange(of: unlockItem) { _, item in Task { await loadExtra(item, night: false) } }
        .onChange(of: nightItem) { _, item in Task { await loadExtra(item, night: true) } }
        .fileImporter(isPresented: $showVideoImporter, allowedContentTypes: [.movie, .video, .mpeg4Movie]) { result in
            switch result {
            case .success(let url):
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                do {
                    let folder = FileManager.default.temporaryDirectory.appendingPathComponent("NoxWallpaperVideoPreviews", isDirectory: true)
                    try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                    let target = folder.appendingPathComponent(UUID().uuidString + "." + (url.pathExtension.isEmpty ? "mov" : url.pathExtension))
                    try FileManager.default.copyItem(at: url, to: target)
                    videoPlayer?.pause()
                    previewVideoURL = target
                    videoPlayer = AVPlayer(url: target)
                    previewVideo = true
                } catch { self.error = error.localizedDescription }
            case .failure(let error): self.error = error.localizedDescription
            }
        }
        .onDisappear { videoPlayer?.pause() }
        .sheet(isPresented: $showShare) {
            if let exportImage {
                NoxWallpaperShareSheet(items: [exportImage])
            }
        }
        .alert("Import error", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
            Button("OK", role: .cancel) { error = nil }
        } message: { Text(error ?? "Unknown error") }
    }

    @ViewBuilder private var wallpaperImage: some View {
        let base = nightPreview ? (nightImage ?? lockImage ?? homeImage) : (activePreview == 2 ? (homeImage ?? lockImage) : (lockImage ?? homeImage))
        ZStack {
            if let base {
                Image(uiImage: base)
                    .resizable().scaledToFill()
                    .scaleEffect(CGFloat(scale) * (parallax ? 1.035 : 1))
                    .offset(y: vertical)
                    .blur(radius: blur)
            } else {
                LinearGradient(colors: [Color(red: 0.12, green: 0.06, blue: 0.27), violet, cyan.opacity(0.65)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    .overlay(Text("Import a wallpaper").font(.caption).foregroundStyle(.white))
            }
            if let unlockedImage, activePreview != 2 {
                GeometryReader { geo in
                    Image(uiImage: unlockedImage)
                        .resizable().scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height)
                        .scaleEffect(transitionStyle == 2 ? 1.12 - 0.12 * morph : 1)
                        .offset(y: transitionStyle == 1 ? (1 - morph) * geo.size.height : 0)
                        .mask(alignment: .leading) {
                            Rectangle()
                                .frame(width: transitionStyle == 3 ? max(0.1, geo.size.width * morph) : geo.size.width)
                        }
                        .opacity(transitionStyle == 0 ? (activePreview == 3 ? 1 : morph) : (activePreview == 3 ? 1 : min(1, morph * 2)))
                }
            }
        }
    }

    @MainActor private func loadExtra(_ item: PhotosPickerItem?, night: Bool) async {
        guard let item else { return }
        do {
            guard let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data) else {
                error = "This image could not be decoded."; return
            }
            if night { nightImage = image } else { unlockedImage = image }
        } catch { self.error = error.localizedDescription }
    }

    private func sliderRow(_ name: String, value: Binding<Double>, range: ClosedRange<Double>) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(name).font(.subheadline)
            Slider(value: value, in: range).tint(violet)
        }
    }

    @MainActor private func load(_ item: PhotosPickerItem?, home: Bool) async {
        guard let item else { return }
        do {
            guard let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data) else {
                error = "This image could not be decoded."; return
            }
            if home { homeImage = image } else { lockImage = image }
        } catch { self.error = error.localizedDescription }
    }

    private func renderWallpaper() -> UIImage? {
        guard let source = (activePreview == 2 ? (homeImage ?? lockImage) : (lockImage ?? homeImage)) else { return nil }
        let canvas = CGSize(width: 1170, height: 2532)
        let renderer = UIGraphicsImageRenderer(size: canvas)
        return renderer.image { context in
            UIColor.black.setFill()
            context.cgContext.fill(CGRect(origin: .zero, size: canvas))
            let factor = max(canvas.width / source.size.width, canvas.height / source.size.height) * CGFloat(scale)
            let target = CGSize(width: source.size.width * factor, height: source.size.height * factor)
            let rect = CGRect(x: (canvas.width - target.width) / 2, y: (canvas.height - target.height) / 2 + vertical * 4, width: target.width, height: target.height)
            source.draw(in: rect)
            UIColor.black.withAlphaComponent(dim).setFill()
            context.cgContext.fill(CGRect(origin: .zero, size: canvas))
        }
    }
}

private struct NoxWallpaperShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}

// Deterministic, low-allocation Canvas overlay; no timers or particle objects retained.
private struct NoxStudioParticles: View {
    let style: Int
    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 24.0)) { timeline in
            Canvas { context, size in
                let t = timeline.date.timeIntervalSinceReferenceDate
                for index in 0..<32 {
                    let seed = Double(index)
                    let x = (seed * 0.61803398875).truncatingRemainder(dividingBy: 1)
                    let y = (seed * 0.41421356237).truncatingRemainder(dividingBy: 1)
                    let speed = style == 2 ? 0.035 : 0.014
                    let progress = (y + t * speed * (1 + seed.truncatingRemainder(dividingBy: 3) * 0.2)).truncatingRemainder(dividingBy: 1)
                    let px = size.width * x
                    let py = size.height * (style == 3 ? 1 - progress : progress)
                    let radius: CGFloat = style == 2 ? 2.3 : 1.6
                    let rect = CGRect(x: px, y: py, width: radius * 2, height: radius * 2)
                    let color: Color = style == 3 ? .orange : (style == 2 ? .white : .cyan)
                    context.fill(Path(ellipseIn: rect), with: .color(color.opacity(0.65)))
                }
            }
        }
    }
}
