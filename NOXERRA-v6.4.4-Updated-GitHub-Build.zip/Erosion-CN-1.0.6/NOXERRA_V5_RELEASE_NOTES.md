# NOXERRA v5.0 — Mond-inspired Dual Query Launcher

## New
- Home: **Run Selected Exploit** button for the selected Worse Query (default) or Bad Query engine.
- Launch sequence requests three separate target paths using the already-integrated selected backend: MobileGestalt cache directory, PosterBoard app container, and one discovered app data container.
- Each target displays the real path (when discovered), whether access succeeded, and a failure reason. A nonnegative sandbox handle does not count as success unless directory enumeration also works.
- Reports show read access separately from the *indicated* writability flag. The launcher never writes test files or edits system data during its checks.
- Progress is asynchronous, so the Home screen remains responsive during app container lookup.
- Home: release only launcher-owned access grants. Switching engines does not silently release grants held by other screens.
- Files, Tweaks, Settings: shared current-engine access status strip.
- NoxShell: `access run`, `access report`, `wq run/report`, `bq run/report` in addition to existing per-path commands.
- The v3 Files dashboard, NoxTrash, Log, profile tools, Tendie Maker, MobileGestalt features, and existing safety gates are preserved.
- Version updated to 5.0.0, build 32. Existing bundle identifier is unchanged so existing side-loaded app identity is preserved when signing permits.

## Reference
The supplied mond-3_1(2).zip contains `mond/exploit/unsbx.swift`, where `grant_all(state:)` obtains separate MobileGestalt, PosterBoard and app-container grants, and `mond/views/app/SettingsView.swift` exposes a `Run Exploit` button. NOXERRA uses its own preexisting v4 access manager instead of copying Mond's exploit implementation or assuming a handle confirms access.

## Limitations
- Actual Bad Query / Worse Query success requires a compatible iOS build, valid signing configuration, and accessible targets. Both are experimental and may be patched.
- PosterBoard and installed app paths may not be discoverable. In those cases that target is marked unavailable; success is never invented.
- Directory enumerations prove the app can list the tested directory at that moment. `isWritableFile` is indicative only; no actual write test is performed by the launcher.
- Full iOS build and runtime testing must be done via GitHub Actions / iPhone; Linux Swift syntax checking is not an iOS compile test.
- Do not uninstall with pending APFS staging vault backups; existing warnings remain.
