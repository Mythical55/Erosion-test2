import SwiftUI

private struct NoxTweak: Identifiable {
    let id: String
    let title: String
    let detail: String
    let symbol: String
}

struct TweaksView: View {
    @State private var search = ""
    private let appearance: [NoxTweak] = [
        .init(id: "wallpaper", title: "Custom Wallpapers (PosterBoard)", detail: "Import and manage PosterBoard wallpaper collections", symbol: "photo.on.rectangle.angled"),
        .init(id: "wallpapercreator", title: "Make Custom Animated Wallpapers (PosterBoard)", detail: "Design and preview animated wallpaper projects", symbol: "film.stack.fill"),
        .init(id: "dialer", title: "Phone App Dialer Keypad Themes", detail: "Import, preview, apply and restore Phone keypad themes", symbol: "phone.arrow.up.right")
    ]
    private let storage: [NoxTweak] = [
        .init(id: "saves", title: "App & Game Save Manager", detail: "Protect and recover supported app and game saves", symbol: "externaldrive.badge.checkmark"),
        .init(id: "cache", title: "Cache Cleaner", detail: "Examine storage and remove selected cached data", symbol: "trash"),
        .init(id: "ads", title: "Splash Ad Cache Blocker", detail: "Review and control cached launch advertisements", symbol: "hand.raised")
    ]
    private let system: [NoxTweak] = [
        .init(id: "noxshell", title: "NoxShell · Terminal", detail: "File commands and NoxTrash", symbol: "terminal.fill"),
        .init(id: "profiles", title: "Configuration Profiles", detail: "Inspect and manage .stub files, metadata and backups", symbol: "doc.text.magnifyingglass"),
        .init(id: "restrictions", title: "User Restrictions", detail: "Inspect all UserSettings.plist restrictions; edit booleans, values and lists", symbol: "checklist"),
        .init(id: "supervised", title: "Supervised Tweaks", detail: "Create iOS configuration profiles · no sandbox exploit", symbol: "checkmark.shield.fill"),
        .init(id: "mg", title: "MobileGestalt (System Values)", detail: "Stage system keys, custom values, verified backups and safety controls", symbol: "cpu"),
        .init(id: "systemapps", title: "System App Opener", detail: "Launch hidden & internal iOS apps", symbol: "square.grid.3x3.fill"),
        .init(id: "config", title: "System Configuration", detail: "Explore advanced iOS configuration controls", symbol: "gearshape.2"),
        .init(id: "replace", title: "File Replacement", detail: "Inspect and replace accessible resources with care", symbol: "doc.on.doc")
    ]
    private let research: [NoxTweak] = [
        .init(id: "power", title: "Power & Thermal Diagnostics", detail: "Inspect power and temperature signals", symbol: "battery.100percent"),
        .init(id: "crash", title: "Crash & Jetsam Diagnostics", detail: "Review crashes, jetsam events and diagnostic reports", symbol: "waveform.path.ecg"),
        .init(id: "groups", title: "App Group Tools", detail: "Browse shared app groups and container information", symbol: "square.stack.3d.up"),
        .init(id: "voice", title: "Voice Memos & AI Diagnostics", detail: "Inspect voice data and AI-related diagnostics", symbol: "waveform")
    ]
    private var allTweaksContainSearch: Bool {
        (appearance + storage + system + research).contains {
            $0.title.localizedCaseInsensitiveContains(search) || $0.detail.localizedCaseInsensitiveContains(search)
        }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    NoxCard {
                        HStack(spacing: 14) {
                            Image(systemName: "slider.horizontal.3")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(NoxStyle.accent)
                                .frame(width: 54, height: 54)
                                .background(NoxStyle.accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 16))
                            VStack(alignment: .leading, spacing: 4) {
                                Text("EXPLORE TWEAKS").font(.caption.weight(.heavy)).tracking(2).foregroundStyle(NoxStyle.accent)
                                Text("Make iOS yours.").font(.title3.weight(.bold))
                                Text("Personalization, system tools and device diagnostics in one place.")
                                    .font(.caption).foregroundStyle(NoxStyle.pale)
                            }
                        }
                    }
                    .padding(.top, 10)
                    section("APPEARANCE", items: appearance)
                    section("APPS & STORAGE", items: storage)
                    section("SYSTEM TOOLS", items: system)
                    section("NOXERRA LAB", items: research)
                    if !search.isEmpty && !allTweaksContainSearch {
                        ContentUnavailableView.search(text: search)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 34)
            }
            .searchable(text: $search, prompt: "Search features and descriptions")
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("Tweaks")
            .background(NoxAmbientBackground())
            .tint(NoxStyle.accent)
        }
    }

    @ViewBuilder
    private func section(_ title: String, items: [NoxTweak]) -> some View {
        let matching = items.filter {
            search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) ||
            $0.detail.localizedCaseInsensitiveContains(search)
        }
        if !matching.isEmpty {
            VStack(alignment: .leading, spacing: 9) {
                HStack {
                    Text(title)
                        .font(.caption.weight(.heavy)).tracking(1.6).foregroundStyle(NoxStyle.accent)
                    Spacer()
                    Text("\(matching.count)")
                        .font(.caption2.monospacedDigit()).foregroundStyle(NoxStyle.pale)
                }
                ForEach(matching) { item in
                    NavigationLink {
                        route(item.id)
                    } label: {
                        HStack(spacing: 13) {
                            Image(systemName: item.symbol)
                                .font(.system(size: 19, weight: .semibold))
                                .foregroundStyle(NoxStyle.cyan)
                                .frame(width: 46, height: 46)
                                .background(NoxStyle.accent.opacity(0.17), in: RoundedRectangle(cornerRadius: 14))
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.title).font(.subheadline.weight(.bold)).foregroundStyle(.white)
                                Text(item.detail).font(.caption).foregroundStyle(NoxStyle.pale)
                                    .multilineTextAlignment(.leading).fixedSize(horizontal: false, vertical: true)
                            }
                            Spacer(minLength: 1)
                            Image(systemName: "chevron.right")
                                .font(.caption.weight(.bold)).foregroundStyle(NoxStyle.accent)
                        }
                        .padding(13)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(NoxStyle.accent.opacity(0.29), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    @ViewBuilder
    private func route(_ name: String) -> some View {
        switch name {
        case "wallpaper": PosterBoardView()
        case "wallpapercreator": NoxCamloStudioHub()
        case "dialer": KeypadView()
        case "saves": AppDataBackupView()
        case "cache": CacheCleanerView()
        case "ads": AdCacheBlockerView()
        case "noxshell": NoxShellView()
        case "mg": GestaltView()
        case "systemapps": NoxSystemAppOpenerView()
        case "supervised": NoxSupervisedTweaksView()
        case "profiles": NoxConfigurationProfilesView()
        case "restrictions": NoxUserRestrictionsView()
        case "config": ConfigView()
        case "replace": OperationsView()
        case "power": PowerTelemetryView()
        case "crash": CrashDiagnosticsView()
        case "groups": AppGroupHubView()
        case "voice": VoiceMemosAIView()
        default: Text("Unavailable")
        }
    }

}
