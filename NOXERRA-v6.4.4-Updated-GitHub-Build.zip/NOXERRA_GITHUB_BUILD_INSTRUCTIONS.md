# NOXERRA v6.4.4 — Updated GitHub build

This archive contains the previously repaired NOXERRA Swift sources plus a GitHub
Actions workflow at `.github/workflows/build.yml` (also copied under the nested
`Erosion-CN-1.0.6/` project directory).

## If your GitHub repository contains only a NOXERRA source ZIP plus .github/workflows

1. Remove the old NOXERRA ZIP from the repository.
2. Upload this ZIP instead. Leave it compressed in this setup.
3. The *repository's* `.github/workflows/build.yml` must be updated with the
   workflow in this archive. GitHub does NOT read a workflow that is inside a ZIP.
   A standalone `NOXERRA-build.yml` file is also provided alongside the download.
4. Open GitHub > Actions > Build NOXERRA IPA > Run workflow.
5. On success, download artifact `NOXERRA-v6.4.4-IPA`.

## If you are uploading extracted files instead

Extract the ZIP and upload its CONTENTS into the repository root, including the
hidden `.github/workflows` folder. This workflow also supports extracted source.

The output IPA is unsigned; additional signing is needed to install it on iOS.
No complete Xcode build was run when this archive was prepared.
A workflow that is QUEUED for a macOS runner has not compiled anything yet;
changing this ZIP cannot fix runner availability issues.
