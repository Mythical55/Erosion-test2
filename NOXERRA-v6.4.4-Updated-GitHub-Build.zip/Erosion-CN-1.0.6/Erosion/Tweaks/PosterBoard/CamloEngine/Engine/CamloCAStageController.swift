import Foundation
import QuartzCore

/// Loads a Core Animation layer archive when the OS exposes a decodable layer graph.
/// Unsupported .ca package formats fail explicitly instead of showing a fake preview.
final class CamloCAStageController {
    let rootLayer: CALayer
    let documentSize: CGSize
    let isGeometryFlipped: Bool

    init(packageURL: URL) throws {
        let data = try Data(contentsOf: packageURL)
        let decoded = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data)
        guard let layer = decoded as? CALayer else {
            throw NSError(domain: "CamloCAStageController", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "Unsupported Core Animation archive format on this iOS version"])
        }
        rootLayer = layer
        let size = layer.bounds.size
        documentSize = size.width > 0 && size.height > 0 ? size : CGSize(width: 390, height: 844)
        isGeometryFlipped = layer.isGeometryFlipped
    }
}
