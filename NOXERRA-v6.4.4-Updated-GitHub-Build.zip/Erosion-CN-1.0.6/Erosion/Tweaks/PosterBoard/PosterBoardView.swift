//
//  PosterBoardView.swift
//  Erosion
//
//  Created by lunginspector on 8/19/26.
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers
import ZIPFoundation

let pbHandler = PBHandler()

enum PBMsg {
    static var noTendies: String { L("点击此处或底部按钮导入 .tendies 壁纸包，即可开始应用自定义锁屏壁纸。") }
    static var tooManyTendies: String { L("单次最多只能同时启用 15 张壁纸，请先取消勾选其他壁纸包后再试！") }
    static var limitWarning: String { L("你当前勾选了超过 5 张壁纸，可能导致部分壁纸无法正常显示。确定仍要继续应用吗？") }
    static var corruption: String { L("请确认所选壁纸包未损坏后重试。") }
    static var finishApply: String { L("点击继续后将自动打开 PosterBoard，请在后台多任务切换器中将其上滑关闭以完成加载。如果壁纸未显示，请在右上角“壁纸设置”中尝试重置“壁纸合集”、“水星壁纸”或“视频壁纸”。") }
    static var applyInfo: String { L("如果打开锁屏编辑后未看到导入的壁纸，请前往右上角菜单的“壁纸设置”中点击“重置壁纸合集 (Collections)”后再试。") }
    static var imprtFailed: String { L("请确认所选文件为有效的 .tendies 壁纸包后重试。") }
}

struct PosterBoardView: View {
    @Environment(\.dismiss) private var noxDismiss
    @AppStorage("noxDismissAfterImport") private var noxDismissAfterImport = false
    @ObservedObject private var langMgr = LocalizationManager.shared
    @AppStorage("pbContainerPath") private var pbContainerPath = ""
    @State private var isResolvingContainer = false
    @State private var hasContainerAccess = false
    @State private var containerLookupAttempted = false
    @AppStorage("tendiesArray") private var tendiesArray: [TendiesObject] = []
    @AppStorage("hasShownFirstRunMsg") private var hasShownFirstRunMsg = false
    
    @State private var showImporter = false
    @State private var importKind: ImportKind = .tendies
    @AppStorage("noxWallpaperListMode") private var listMode = false
    @State private var search = ""
    @State private var sortOrder: LibrarySort = .newest
    @State private var metadata: [UUID: LibraryMetadata] = [:]
    @State private var deleteMode: DeleteMode? = nil
    @State private var confirmDelete = false
    @State private var renameTarget: UUID? = nil
    @State private var renameText = ""
    @State private var showRename = false
    @State private var exportItem: WallpaperLibraryExport? = nil
    @State private var exporting = false
    private enum ImportKind { case tendies, zip }
    private enum DeleteMode { case selected, all }
    private enum LibrarySort: String, CaseIterable, Identifiable {
        case newest = "Newest first", oldest = "Oldest first", name = "Name A–Z", size = "Largest first"
        var id: String { rawValue }
    }
    private struct LibraryMetadata {
        let bytes: Int64?
        let date: Date?
        let estimatedDate: Bool
    }
    private var selectedPacks: [TendiesObject] { tendiesArray.filter(\.isOn) }
    private var selectedWallpaperCount: Int { selectedPacks.reduce(0) { $0 + $1.descrNames.count } }
    private var totalWallpaperCount: Int { tendiesArray.reduce(0) { $0 + $1.descrNames.count } }
    private var filteredPacks: [TendiesObject] {
        let query = search.trimmingCharacters(in: .whitespacesAndNewlines)
        let packs = tendiesArray.filter { query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) }
        switch sortOrder {
        case .newest: return packs.sorted { (metadata[$0.id]?.date ?? .distantPast) > (metadata[$1.id]?.date ?? .distantPast) }
        case .oldest: return packs.sorted { (metadata[$0.id]?.date ?? .distantFuture) < (metadata[$1.id]?.date ?? .distantFuture) }
        case .name: return packs.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
        case .size: return packs.sorted { (metadata[$0.id]?.bytes ?? -1) > (metadata[$1.id]?.bytes ?? -1) }
        }
    }
    let columns = Array(repeating: GridItem(.flexible()), count: device.userInterfaceIdiom == .pad ? 4 : 2)

    private var isEn: Bool { langMgr.isEnglish }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                wallpaperActions
                containerStatusBanner
                    .padding(.horizontal, 15)
                libraryControls
                if tendiesArray.isEmpty {
                    Button { beginImport(.tendies) } label: {
                        ContentUnavailableView("No Imported Wallpapers", systemImage: "photo.on.rectangle", description: Text("Import a .tendies or a compatible .zip wallpaper pack to get started."))
                    }
                    .buttonStyle(.plain)
                } else if filteredPacks.isEmpty {
                    ContentUnavailableView.search(text: search)
                } else if listMode {
                    LazyVStack(spacing: 10) {
                        ForEach(filteredPacks) { pack in wallpaperCard(pack, list: true) }
                    }
                    .padding(.horizontal, 15)
                } else {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(filteredPacks) { pack in wallpaperCard(pack, list: false) }
                    }
                    .padding(.horizontal, 15)
                }
            }
            .padding(.bottom, 24)
        }
        .navigationTitle("Custom Wallpapers")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search imported wallpapers")
        .scrollDismissesKeyboard(.interactively)
        .onAppear {
            ensureLocalPBDirs()
            refreshLibraryMetadata()
            if !hasContainerAccess || pbContainerPath.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                resolvePosterBoardContainer(forceRefresh: false)
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: importKind == .zip ? [.zip] : [.item]) { result in
            ensureLocalPBDirs()
            let res = handleImport(result)
            if !res {
                Alertinator.shared.alert(title: "Wallpaper import failed", body: "Choose a valid PosterBoard wallpaper archive with the correct .tendies or .zip extension. An ordinary ZIP without wallpaper descriptors is not supported.")
            } else {
                refreshLibraryMetadata()
                if noxDismissAfterImport { noxDismiss() }
            }
        }
        .alert(deleteMode == .all ? "Remove all imported wallpapers?" : "Remove selected wallpapers?", isPresented: $confirmDelete) {
            Button("Cancel", role: .cancel) { deleteMode = nil }
            Button("Remove", role: .destructive) {
                removeLocalPacks(deleteMode == .all ? tendiesArray : selectedPacks)
                deleteMode = nil
            }
        } message: {
            Text("This removes copies from the NOXERRA library only. It does not remove previously applied Lock Screen wallpapers.")
        }
        .alert("Rename wallpaper pack", isPresented: $showRename) {
            TextField("Name", text: $renameText)
            Button("Cancel", role: .cancel) { renameTarget = nil }
            Button("Save") { finishRename() }
        } message: {
            Text("Changes the library display name without modifying wallpaper files.")
        }
        .sheet(item: $exportItem) { item in
            WallpaperLibraryShareSheet(url: item.url)
        }
    }

    private var wallpaperActions: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("CUSTOM WALLPAPERS · POSTERBOARD")
                .font(.caption.weight(.heavy)).tracking(1.3).foregroundStyle(Color.accentColor)
            HStack(spacing: 10) {
                Button { beginImport(.tendies) } label: {
                    Label("Import .tendies", systemImage: "square.and.arrow.down")
                        .frame(maxWidth: .infinity)
                }
                Button { beginImport(.zip) } label: {
                    Label("Import .zip", systemImage: "doc.zipper")
                        .frame(maxWidth: .infinity)
                }
            }
            .buttonStyle(.bordered)
            .disabled(exporting)
            applyButton
            if selectedWallpaperCount > 15 {
                Text("Select no more than 15 wallpapers to apply at once. You can still manage or export all selected packs.")
                    .font(.caption).foregroundStyle(.orange)
            }
            Button {
                openApp(withBID: SysBID.poster)
            } label: {
                Label("Open PosterBoard", systemImage: "arrow.up.right.square")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            if let website = URL(string: "https://cowabun.ga/wallpapers") {
                Link(destination: website) {
                    Label("Get Custom Wallpapers on Cowabunga", systemImage: "globe")
                        .font(.subheadline.weight(.semibold))
                }
            }
            Text("Wallpaper Settings").font(.headline).padding(.top, 4)
            Text("PosterBoard Path:").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            TextField("PosterBoard container path", text: $pbContainerPath, axis: .vertical)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .onChange(of: pbContainerPath) { _, newPath in
                    let path = newPath.trimmingCharacters(in: .whitespacesAndNewlines)
                    hasContainerAccess = !path.isEmpty && wq.grantAccess(path: path).0 && fm.fileExists(atPath: path)
                    containerLookupAttempted = true
                }
            Button { resolvePosterBoardContainer(forceRefresh: true) } label: {
                Label("Refresh PosterBoard Path", systemImage: "arrow.clockwise")
            }
            .disabled(isResolvingContainer)
            HStack(spacing: 10) {
                Button("Reset Collections") { _ = resetWallpapers(for: PBPath.wpKit) }
                Button("Reset Mercury") { _ = resetWallpapers(for: PBPath.mercury) }
            }
            .disabled(!hasContainerAccess || isResolvingContainer)
            Button("Reset Video Wallpapers") { _ = resetWallpapers(for: PBPath.photos) }
                .disabled(!hasContainerAccess || isResolvingContainer)
        }
        .font(.subheadline)
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 19))
        .padding(.horizontal, 15)
    }

    private var applyButton: some View {
        Button {
            ensureLocalPBDirs()
            if isResolvingContainer {
                Alertinator.shared.alert(
                    title: isEn ? "Locating PosterBoard Container" : "正在定位系统容器",
                    body: isEn
                        ? "PosterBoard container lookup is still running in the background. Please try again once locating finishes."
                        : "系统正在后台定位 PosterBoard 容器路径，请稍候待定位完成后再点击「应用」。",
                    showCancel: false
                )
                return
            }
            let trimmedPath = pbContainerPath.trimmingCharacters(in: .whitespacesAndNewlines)
            guard hasContainerAccess, !trimmedPath.isEmpty else {
                Alertinator.shared.alert(
                    title: L("无法访问 PosterBoard 容器！"),
                    body: isEn
                        ? "Could not locate or authorize com.apple.PosterBoard yet. Tap Retry Lookup or check Wallpaper Settings."
                        : "未能定位或授权 com.apple.PosterBoard 容器。请点击“重新定位”，或前往右上角“壁纸设置”检查路径与权限。",
                    actionLabel: isEn ? "Retry Lookup" : "重新定位",
                    action: {
                        resolvePosterBoardContainer(forceRefresh: true)
                    }
                )
                return
            }

            if !hasShownFirstRunMsg {
                Alertinator.shared.alert(title: L("操作提示"), body: PBMsg.applyInfo, actionLabel: L("继续"), action: {
                    hasShownFirstRunMsg = true
                    proceed()
                })
            } else if tendiesArray.filter({ $0.isOn }).flatMap({ $0.descrNames }).count > 5 {
                Alertinator.shared.alert(title: L("操作提示"), body: PBMsg.limitWarning, actionLabel: L("确认"), action: {
                    proceed()
                })
            } else {
                proceed()
            }
            
            @MainActor
            func proceed() {
                let res = applyObjects(tendiesArray.filter { $0.isOn })
                if !res.0 {
                    if res.1.contains("an item with the same name already exists") || res.1.contains("已经存在") {
                        Alertinator.shared.alert(title: L("应用壁纸失败！"), body: L("所选的部分壁纸此前已添加过，请勿重复添加。"))
                    } else {
                        Alertinator.shared.alert(title: L("应用壁纸失败！"), body: res.1.isEmpty ? PBMsg.corruption : res.1)
                    }
                } else {
                    Haptic.shared.play(.soft)
                    Alertinator.shared.alert(title: L("请重启 PosterBoard 以完成应用！"), body: PBMsg.finishApply, showCancel: false, actionLabel: L("继续"), action: { openApp(withBID: SysBID.poster) })
                }
            }
        } label: {
            Label("Apply \(selectedWallpaperCount) Custom Wallpapers", systemImage: "checkmark.circle.fill")
                .font(.headline.weight(.bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
        }
        .buttonStyle(.borderedProminent)
        .tint(NoxStyle.accent)
        .disabled(selectedWallpaperCount == 0 || selectedWallpaperCount > 15 || exporting)
    }

    private var libraryControls: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("IMPORTED WALLPAPERS").font(.caption.weight(.heavy)).tracking(1.3).foregroundStyle(Color.accentColor)
                    Text("\(tendiesArray.count) packs · \(totalWallpaperCount) wallpapers").font(.headline)
                    Text("\(selectedPacks.count) selected packs · \(selectedWallpaperCount) wallpapers").font(.caption).foregroundStyle(.secondary)
                    if !search.isEmpty {
                        Text("Showing \(filteredPacks.count) of \(tendiesArray.count) packs").font(.caption2).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 4)
                Menu {
                    Picker("Sort by", selection: $sortOrder) {
                        ForEach(LibrarySort.allCases) { order in Text(order.rawValue).tag(order) }
                    }
                } label: {
                    Image(systemName: "line.3.horizontal.decrease.circle").font(.title2)
                }
                .accessibilityLabel("Sort wallpapers")
            }
            Picker("Layout", selection: $listMode) {
                Label("Grid", systemImage: "square.grid.2x2").tag(false)
                Label("List", systemImage: "list.bullet").tag(true)
            }
            .pickerStyle(.segmented)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                libraryButton("Select All", "checkmark.circle") { setSelection(true) }
                    .disabled(tendiesArray.isEmpty || selectedPacks.count == tendiesArray.count || exporting)
                libraryButton("Deselect All", "circle") { setSelection(false) }
                    .disabled(selectedPacks.isEmpty || exporting)
                libraryButton("Export All", "square.and.arrow.up") { exportLibrary(tendiesArray) }
                    .disabled(tendiesArray.isEmpty || exporting)
                libraryButton("Export Selected", "square.and.arrow.up.on.square") { exportLibrary(selectedPacks) }
                    .disabled(selectedPacks.isEmpty || exporting)
                libraryButton("Rename", "pencil") { beginRename() }
                    .disabled(selectedPacks.count != 1 || exporting)
                libraryButton("Show Directory in Files", "folder") { showLocalDirectory() }
                    .disabled(tendiesArray.isEmpty || exporting)
                libraryButton("Remove", "trash", destructive: true) { deleteMode = .selected; confirmDelete = true }
                    .disabled(selectedPacks.isEmpty || exporting)
                libraryButton("Remove All", "trash.slash", destructive: true) { deleteMode = .all; confirmDelete = true }
                    .disabled(tendiesArray.isEmpty || exporting)
            }
            if exporting {
                HStack { ProgressView(); Text("Preparing library export…").font(.caption) }
            }
        }
        .padding(14)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 19))
        .padding(.horizontal, 15)
    }

    private func libraryButton(_ title: String, _ symbol: String, destructive: Bool = false, action: @escaping () -> Void) -> some View {
        Button(role: destructive ? .destructive : nil, action: action) {
            Label(title, systemImage: symbol)
                .font(.caption.weight(.semibold))
                .frame(maxWidth: .infinity, minHeight: 34, alignment: .leading)
        }
        .buttonStyle(.bordered)
        .tint(destructive ? .red : Color.accentColor)
    }

    private func wallpaperCard(_ pack: TendiesObject, list: Bool) -> some View {
        Button {
            guard let index = tendiesArray.firstIndex(where: { $0.id == pack.id }) else { return }
            withAnimation(.easeInOut(duration: 0.15)) { tendiesArray[index].isOn.toggle() }
        } label: {
            let layout = list ? AnyLayout(HStackLayout(alignment: .center, spacing: 12)) : AnyLayout(VStackLayout(alignment: .leading, spacing: 8))
            layout {
                Image(systemName: pack.targetDescr == .photos ? "play.rectangle.fill" : "photo.on.rectangle.angled")
                    .font(.title2).foregroundStyle(Color.accentColor)
                    .frame(width: 38, height: 38)
                    .background(Color.accentColor.opacity(0.12), in: RoundedRectangle(cornerRadius: 10))
                VStack(alignment: .leading, spacing: 4) {
                    Text(pack.name).font(.subheadline.weight(.semibold)).lineLimit(2)
                    Text("\(pack.descrNames.count) wallpapers · \(kindName(pack.targetDescr))")
                        .font(.caption2).foregroundStyle(.secondary)
                    Text("Size: \(sizeLabel(pack))").font(.caption2).foregroundStyle(.secondary)
                    Text(importDateLabel(pack)).font(.caption2).foregroundStyle(.secondary)
                }
                if list { Spacer(minLength: 0) }
                Image(systemName: pack.isOn ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(pack.isOn ? Color.accentColor : Color.secondary)
                    .font(.title3)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(pack.isOn ? Color.accentColor : Color.clear, lineWidth: 2))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(pack.isOn ? .isSelected : [])
        .disabled(exporting)
    }

    private func beginImport(_ kind: ImportKind) {
        ensureLocalPBDirs()
        importKind = kind
        showImporter = true
    }

    private func kindName(_ kind: PBPath) -> String {
        switch kind {
        case .wpKit: return "Collections"
        case .mercury: return "Mercury"
        case .photos: return "Video"
        }
    }

    private func sizeLabel(_ pack: TendiesObject) -> String {
        guard let bytes = metadata[pack.id]?.bytes else { return "Unknown" }
        return ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)
    }

    private func importDateLabel(_ pack: TendiesObject) -> String {
        guard let info = metadata[pack.id], let date = info.date else { return "Imported: Unknown" }
        let label = info.estimatedDate ? "Folder created: " : "Imported: "
        return label + date.formatted(date: .abbreviated, time: .shortened)
    }

    private func refreshLibraryMetadata() {
        var result: [UUID: LibraryMetadata] = [:]
        for pack in tendiesArray {
            let folder = WallpaperLibraryLocal.folder(for: pack)
            let creation = folder.flatMap { try? $0.resourceValues(forKeys: [.creationDateKey]).creationDate }
            let bytes = folder.flatMap { WallpaperLibraryLocal.folderSize($0) }
            result[pack.id] = LibraryMetadata(bytes: bytes, date: pack.importedAt ?? creation, estimatedDate: pack.importedAt == nil)
        }
        metadata = result
    }

    private func setSelection(_ selected: Bool) {
        var updated = tendiesArray
        for index in updated.indices { updated[index].isOn = selected }
        tendiesArray = updated
    }

    private func beginRename() {
        guard selectedPacks.count == 1, let pack = selectedPacks.first else { return }
        renameTarget = pack.id
        renameText = pack.name
        showRename = true
    }

    private func finishRename() {
        defer { renameTarget = nil }
        let name = renameText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let id = renameTarget, let index = tendiesArray.firstIndex(where: { $0.id == id }), !name.isEmpty else { return }
        tendiesArray[index].name = String(name.prefix(120))
    }

    private func showLocalDirectory() {
        let folder = selectedPacks.count == 1 ? selectedPacks.first.flatMap { WallpaperLibraryLocal.folder(for: $0) } : AppURL.pbFolders
        if let folder { fsHandlers.openInFilesApp(folder) }
    }

    private func removeLocalPacks(_ packs: [TendiesObject]) {
        var removed: Set<UUID> = []
        var failures: [String] = []
        for pack in packs {
            do {
                guard let folder = WallpaperLibraryLocal.folder(for: pack) else { throw "Invalid local library path." }
                let original = WallpaperLibraryLocal.original(for: pack)
                let originalParent = original.deletingLastPathComponent()
                guard originalParent.resolvingSymlinksInPath().path == originalParent.path else { throw "Invalid local archive path." }
                if fm.fileExists(atPath: original.path) { try fm.removeItem(at: original) }
                if fm.fileExists(atPath: folder.path) { try fm.removeItem(at: folder) }
                removed.insert(pack.id)
            } catch { failures.append("\(pack.name): \(error.localizedDescription)") }
        }
        withAnimation { tendiesArray.removeAll { removed.contains($0.id) } }
        refreshLibraryMetadata()
        if !failures.isEmpty { Alertinator.shared.alert(title: "Some items could not be removed", body: failures.joined(separator: "\n")) }
    }

    private func exportLibrary(_ packs: [TendiesObject]) {
        guard !packs.isEmpty, !exporting else { return }
        let entries: [WallpaperExportEntry]
        let manifest: Data
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            manifest = try encoder.encode(packs)
            entries = try packs.map { pack in
                guard let folder = WallpaperLibraryLocal.folder(for: pack), fm.fileExists(atPath: folder.path) else {
                    throw NSError(domain: "WallpaperLibrary", code: 1, userInfo: [NSLocalizedDescriptionKey: "Missing local files for \(pack.name)."])
                }
                return WallpaperExportEntry(id: pack.id, name: pack.name, folder: folder, original: WallpaperLibraryLocal.original(for: pack))
            }
        } catch {
            Alertinator.shared.alert(title: "Export failed", body: error.localizedDescription)
            return
        }
        exporting = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result = Result { try WallpaperLibraryLocal.export(entries, manifest: manifest) }
            DispatchQueue.main.async {
                exporting = false
                switch result {
                case .success(let url): exportItem = WallpaperLibraryExport(url: url)
                case .failure(let error): Alertinator.shared.alert(title: "Export failed", body: error.localizedDescription)
                }
            }
        }
    }

    private var containerStatusBanner: some View {
        Group {
        if isResolvingContainer {
            HStack(spacing: 10) {
                ProgressView()
                    .controlSize(.small)
                Text(isEn
                     ? "Locating PosterBoard container in background (you can import .tendies packages right away)…"
                     : "正在后台定位 PosterBoard 系统容器（可先直接导入壁纸包）…")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color(.secondarySystemBackground))
            )
        } else if containerLookupAttempted && !hasContainerAccess {
            HStack(alignment: .center, spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(.orange)
                Text(isEn
                     ? "PosterBoard container not located yet. You can still import .tendies packages; tap Retry before applying to Lock Screen."
                     : "暂未定位到 PosterBoard 容器，仍可先导入管理壁纸包；应用到锁屏前请点击重试，或在「壁纸设置」中配置路径。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
                Button(isEn ? "Retry" : "重试") {
                    resolvePosterBoardContainer(forceRefresh: true)
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .tint(.orange)
                .layoutPriority(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(Color.orange.opacity(0.12))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .strokeBorder(Color.orange.opacity(0.35), lineWidth: 1)
            )
        }
        }
    }
    
    private func ensureLocalPBDirs() {
        if !fm.fileExists(atPath: AppURL.pb.path) || !fm.fileExists(atPath: AppURL.pbFolders.path) {
            do {
                try fm.createDirIfNeeded(at: AppURL.pb)
                try fm.createDirIfNeeded(at: AppURL.pbFolders)
            } catch {
                Alertinator.shared.alert(title: L("初始化壁纸目录失败！"), body: AppMsg.opFailed)
            }
        }
    }

    private func resolvePosterBoardContainer(forceRefresh: Bool = false) {
        guard !isResolvingContainer else { return }
        let initialCachedPath = forceRefresh ? "" : pbContainerPath.trimmingCharacters(in: .whitespacesAndNewlines)
        isResolvingContainer = true

        DispatchQueue.global(qos: .userInitiated).async {
            if forceRefresh {
                CSStoreEngine.shared.invalidate()
                fsHandlers.invalidateCache()
            }

            var resolvedPath = initialCachedPath
            var accessOK = false
            if !resolvedPath.isEmpty {
                let grant = wq.grantAccess(path: resolvedPath)
                if grant.0 && fm.fileExists(atPath: resolvedPath) {
                    accessOK = true
                } else {
                    resolvedPath = ""
                }
            }
            if resolvedPath.isEmpty {
                let fetched = fsHandlers.getContainerPath(forMatch: "com.apple.PosterBoard")
                if !fetched.isEmpty {
                    resolvedPath = fetched
                    let grant = wq.grantAccess(path: resolvedPath)
                    accessOK = grant.0 && fm.fileExists(atPath: resolvedPath)
                }
            }

            DispatchQueue.main.async {
                if !resolvedPath.isEmpty {
                    pbContainerPath = resolvedPath
                } else if forceRefresh {
                    pbContainerPath = ""
                }
                hasContainerAccess = accessOK
                containerLookupAttempted = true
                isResolvingContainer = false
            }
        }
    }
    
    private func applyObjects(_ objects: [TendiesObject]) -> (Bool, String) {
        let containerPath = pbContainerPath.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !containerPath.isEmpty else {
            return (false, L("未找到 PosterBoard 容器路径。"))
        }
        let rootGrant = wq.grantAccess(path: containerPath)
        if !rootGrant.0 {
            print("(pb) failed to grant access to container root \(containerPath): \(rootGrant.2)")
            return (false, rootGrant.2)
        }
        
        let descrTargets = Set(objects.map(\.targetDescr))
        var resolvedTargetDirs: [PBPath: URL] = [:]
        for descrTarget in descrTargets {
            let relPath = descrTarget.resolvedPath(in: containerPath)
            let targetURL = URL(fileURLWithPath: containerPath).appendingPathComponent(relPath)
            do {
                try fm.createDirectory(at: targetURL, withIntermediateDirectories: true)
            } catch {
                print("(pb) failed to create target directory \(targetURL.path): \(error.localizedDescription)")
                return (false, error.localizedDescription)
            }
            if fm.fileExists(atPath: targetURL.path) {
                let res = wq.grantAccess(path: targetURL.path)
                if !res.0 {
                    print("(pb) failed to grant access at \(targetURL.path): \(res.2)")
                    return (false, res.2)
                }
            }
            resolvedTargetDirs[descrTarget] = targetURL
        }
        
        for object in objects {
            guard let containerURL = resolvedTargetDirs[object.targetDescr] else { continue }
            for descr in object.descrNames {
                let descrURL = AppURL.pbFolders.appendingPathComponent(object.folderName).appendingPathComponent(descr)
                let target = object.targetDescr == .mercury ? containerURL.appendingPathComponent(descrURL.lastPathComponent) : containerURL.appendingPathComponent(UUID().uuidString)
                do {
                    try fm.copyItem(at: descrURL, to: target)
                } catch {
                    print("(pb) failed to copy descriptor (folder: \(object.folderName)): \(error.localizedDescription)")
                    return (false, error.localizedDescription)
                }
            }
        }
        return (true, "")
    }
    
    private func resetWallpapers(for item: PBPath) -> Bool {
        let containerPath = pbContainerPath.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !containerPath.isEmpty else {
            Alertinator.shared.alert(title: L("重置壁纸失败！"), body: L("未找到 PosterBoard 容器路径。"))
            return false
        }
        let rootGrant = wq.grantAccess(path: containerPath)
        if !rootGrant.0 {
            Alertinator.shared.alert(title: L("重置壁纸失败！"), body: L("无法获取 PosterBoard 容器权限：\(rootGrant.2)"))
            return false
        }
        let relPath = item.resolvedPath(in: containerPath)
        let target = URL(fileURLWithPath: containerPath).appendingPathComponent(relPath)
        if !fm.fileExists(atPath: target.path) {
            return true
        }
        let targetGrant = wq.grantAccess(path: target.path)
        if !targetGrant.0 {
            Alertinator.shared.alert(title: L("重置壁纸失败！"), body: L("无法获取目标壁纸目录权限：\(targetGrant.2)"))
            return false
        }
        do {
            let contents = try fm.contentsOfDirectory(at: target, includingPropertiesForKeys: nil)
            
            for url in contents {
                try fm.removeItem(at: url)
            }
            return true
        } catch {
            print("(pb) failed to reset \(item.rawValue): \(error.localizedDescription)")
            Alertinator.shared.alert(title: L("重置壁纸失败！"), body: error.localizedDescription)
            return false
        }
    }
    
    private func handleImport(_ result: Result<URL, Error>) -> Bool {
        switch result {
        case .success(let fileURL):
            let expectedExtension = importKind == .zip ? "zip" : "tendies"
            guard fileURL.pathExtension.lowercased() == expectedExtension else { return false }
            let stopAccess = fileURL.startAccessingSecurityScopedResource()
            defer {
                if stopAccess {
                    fileURL.stopAccessingSecurityScopedResource()
                }
            }
            if let tendies = pbHandler.makeObjectFromTendies(at: fileURL) {
                withAnimation {
                    tendiesArray.append(tendies)
                }
                return true
            }
            return false
        case .failure(let error):
            print("(pb) failed to import file: \(error.localizedDescription)")
            return false
        }
    }
}


// These operations are limited to NOXERRA's own wallpaper library, not the system container.
private enum WallpaperLibraryLocal {
    static func folder(for pack: TendiesObject) -> URL? {
        guard !pack.folderName.isEmpty, pack.folderName != ".", pack.folderName != "..",
              !pack.folderName.contains("/"), !pack.folderName.contains("\\") else { return nil }
        let documents = URL.documentsDirectory.standardizedFileURL.resolvingSymlinksInPath()
        let base = documents.appendingPathComponent("PosterBoard/Wallpapers", isDirectory: true).standardizedFileURL
        guard base.resolvingSymlinksInPath().path == base.path else { return nil }
        let folder = base.appendingPathComponent(pack.folderName, isDirectory: true).standardizedFileURL
        guard folder.deletingLastPathComponent().path == base.path,
              folder.resolvingSymlinksInPath().path == folder.path else { return nil }
        return folder
    }

    static func original(for pack: TendiesObject) -> URL {
        URL.documentsDirectory.standardizedFileURL.resolvingSymlinksInPath()
            .appendingPathComponent("PosterBoard/Original Archives", isDirectory: true)
            .appendingPathComponent(pack.id.uuidString + ".tendies")
    }

    static func folderSize(_ folder: URL) -> Int64? {
        let manager = FileManager.default
        guard manager.fileExists(atPath: folder.path),
              let enumerator = manager.enumerator(at: folder, includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]) else { return nil }
        var bytes: Int64 = 0
        for case let file as URL in enumerator {
            guard let values = try? file.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey]) else { continue }
            if values.isSymbolicLink == true { enumerator.skipDescendants(); continue }
            if values.isRegularFile == true { bytes += Int64(values.fileSize ?? 0) }
        }
        return bytes
    }

    nonisolated static func export(_ packs: [WallpaperExportEntry], manifest: Data) throws -> URL {
        let manager = FileManager.default
        let work = manager.temporaryDirectory.appendingPathComponent("NOXERRA-Library-" + UUID().uuidString, isDirectory: true)
        let content = work.appendingPathComponent("Library", isDirectory: true)
        try manager.createDirectory(at: content, withIntermediateDirectories: true)
        do {
            try manifest.write(to: content.appendingPathComponent("manifest.json"))
            for pack in packs {
                let safeName = pack.name.components(separatedBy: CharacterSet(charactersIn: "/\\:\n\r")).joined(separator: "_")
                let entry = content.appendingPathComponent(String(safeName.prefix(80)) + "-" + pack.id.uuidString, isDirectory: true)
                try manager.createDirectory(at: entry, withIntermediateDirectories: true)
                let archive = pack.original
                if manager.fileExists(atPath: archive.path) {
                    guard archive.resolvingSymlinksInPath().path == archive.path else { throw CocoaError(.fileReadNoPermission) }
                    let filename = safeName.isEmpty ? "Wallpaper" : String(safeName.prefix(80))
                    try manager.copyItem(at: archive, to: entry.appendingPathComponent(filename + ".tendies"))
                }
                guard manager.fileExists(atPath: pack.folder.path), pack.folder.resolvingSymlinksInPath().path == pack.folder.path else { throw CocoaError(.fileReadNoPermission) }
                if let enumerator = manager.enumerator(at: pack.folder, includingPropertiesForKeys: [.isSymbolicLinkKey]) {
                    for case let file as URL in enumerator {
                        if try file.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink == true { throw CocoaError(.fileReadNoPermission) }
                    }
                }
                try manager.copyItem(at: pack.folder, to: entry.appendingPathComponent("Local Files", isDirectory: true))
            }
            let readme = "NOXERRA wallpaper library backup. Individual .tendies files can be imported again. Legacy packs without an original archive contain extracted local files only. The outer library backup ZIP is not a single PosterBoard wallpaper pack."
            try Data(readme.utf8).write(to: content.appendingPathComponent("README.txt"))
            let output = work.appendingPathComponent("NOXERRA-Wallpaper-Library.zip")
            try manager.zipItem(at: content, to: output, shouldKeepParent: false)
            try manager.removeItem(at: content)
            return output
        } catch {
            try? manager.removeItem(at: work)
            throw error
        }
    }
}

private nonisolated struct WallpaperExportEntry: Sendable {
    let id: UUID
    let name: String
    let folder: URL
    let original: URL
}

private struct WallpaperLibraryExport: Identifiable {
    let id = UUID()
    let url: URL
}

private struct WallpaperLibraryShareSheet: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        controller.completionWithItemsHandler = { _, _, _, _ in
            try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
        }
        return controller
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
