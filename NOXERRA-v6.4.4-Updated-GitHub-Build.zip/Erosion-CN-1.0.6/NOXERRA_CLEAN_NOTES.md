# NOXERRA clean rebuild — from Erosion-CN 1.0.6

This release is rebuilt from the original Erosion-CN-1.0.6.zip, not the previously failing NOXERRA V2 source. Includes a new purple dashboard, native Tweaks search, original functional file manager, dedicated console, and settings including an original audible tap sound generated for NOXERRA. The original Erosion home and advanced settings are reachable from the new interface.

**Removed/omitted:** bad_query selector, EXTREME deletion tools, simulated exploit methods, unsupported exit alert. Existing C files in the upstream project are retained for compatibility, but the NOXERRA UI exposes only worse_query.

**Validation:** Swift parser and ZIP integrity only. Xcode compilation and iOS testing must happen with GitHub Actions. This version deliberately does not claim to integrate every WorkTweaks feature.
