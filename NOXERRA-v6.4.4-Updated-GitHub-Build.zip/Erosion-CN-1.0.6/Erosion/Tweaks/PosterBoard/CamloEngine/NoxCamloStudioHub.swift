import SwiftUI

// Native Camlo engine integrated in NOXERRA. Editors share the Camlo vault and
// compile their actual CAML / .tendies packages through the imported engine.
struct NoxCamloStudioHub: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 8) {
                    Label("NOXERRA WALLPAPER ENGINE", systemImage: "sparkles.rectangle.stack")
                        .font(.caption.bold()).foregroundStyle(.cyan)
                    Text("Wallpaper Studio").font(.largeTitle.bold())
                    Text("Create animated wallpapers with Camlo's native rendering and packaging engine.")
                        .foregroundStyle(.secondary)
                }
                .padding(18)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.purple.opacity(0.15), in: RoundedRectangle(cornerRadius: 20))

                NavigationLink { MorphEditorView() } label: {
                    studioCard("Morph & Animate", "Locked, sleep, unlock, particles, depth and CAML export", "wand.and.stars")
                }
                NavigationLink { VideoEditorView() } label: {
                    studioCard("Video Wallpaper", "Edit video frames and package animated .tendies", "film.stack")
                }
                NavigationLink { VaultView() } label: {
                    studioCard("Wallpaper Vault", "Manage and export saved .tendies packages", "archivebox.fill")
                }
                NavigationLink { NoxWallpaperStudioView() } label: {
                    studioCard("Quick Image Editor", "Still images, Home Screen and Lock Screen previews", "photo.on.rectangle")
                }
                NavigationLink { SystemStatusView() } label: {
                    studioCard("Wallpaper System Status", "Check PosterBoard access and compatibility", "checkmark.shield")
                }
            }
            .padding()
        }
        .background(Color.black)
        .foregroundStyle(.white)
        .tint(.purple)
        .navigationTitle("Wallpaper Studio")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func studioCard(_ title: String, _ subtitle: String, _ icon: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.title2).foregroundStyle(.cyan).frame(width: 42)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 2)
            Image(systemName: "chevron.right").foregroundStyle(.purple)
        }
        .padding(16)
        .background(Color.purple.opacity(0.11), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.purple.opacity(0.45)))
    }
}
