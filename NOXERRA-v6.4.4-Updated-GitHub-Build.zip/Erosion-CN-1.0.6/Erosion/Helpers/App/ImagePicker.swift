//
//  ImagePicker.swift
//  "adapted" (skidded) from "exerhythm" or sourcelocation in DebToIPA
//

import SwiftUI
import PhotosUI

struct ImagePickerView: UIViewControllerRepresentable {
    var completion: ((Data) -> Void)? = nil

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ImagePickerView

        init(_ parent: ImagePickerView) {
            self.parent = parent
        }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)

            guard let provider = results.first?.itemProvider else { return }

            if provider.canLoadObject(ofClass: UIImage.self) {
                provider.loadObject(ofClass: UIImage.self) { image, _ in
                    let uiImage = image as? UIImage
                    let resultData = uiImage?.pngData() ?? Data()

                    DispatchQueue.main.async {
                        self.parent.completion?(resultData)
                    }
                }
            }
        }
    }
}
