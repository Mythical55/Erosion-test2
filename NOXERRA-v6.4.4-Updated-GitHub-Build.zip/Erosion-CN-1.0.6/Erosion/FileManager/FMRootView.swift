//
//  FMRootView.swift
//  Erosion
//
//  Created by lunginspector on 8/26/26.
//

import SwiftUI
import Darwin
import UIKit

enum FSPaths {
    static let appContainers = "/var/mobile/Containers/Data/Application"
    static var appBundles = "/var/containers/Bundle/Application"
}

enum FSURL {
    static let appContainers = URL(fileURLWithPath: FSPaths.appContainers)
    static var sysGroup = URL(fileURLWithPath: "/var/containers/Shared/SystemGroup")
    static var configProfiles = FSURL.sysGroup.appendingPathComponent("systemgroup.com.apple.configurationprofiles/Library/ConfigurationProfiles")
    static var internalDaemons = URL(fileURLWithPath: "/var/mobile/Containers/Data/InternalDaemon")
    static var appPlugins = URL(fileURLWithPath: "/var/mobile/Containers/Data/PluginKitPlugin")
    static var appGroup = URL(fileURLWithPath: "/var/mobile/Containers/Shared/AppGroup")
    static var systemData = URL(fileURLWithPath: "/var/containers/Data/System")
}

private struct GoToPathTarget: Identifiable, Hashable {
    let id = UUID()
    let url: URL
    let isContainer: Bool
    let shouldGrant: Bool
}

struct FMRootView: View {
    @StateObject private var navStore = FMNavigationStore.shared
    @ObservedObject private var trash = NoxTrash.shared
    @State private var showTrashWarning = false
    @State private var showGoToPath = false
    @State private var goToTarget: GoToPathTarget?
    private let columns = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    NoxCard {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(spacing: 12) {
                                Image(systemName: "folder.fill")
                                    .font(.system(size: 29, weight: .bold))
                                    .foregroundStyle(NoxStyle.cyan)
                                    .frame(width: 54, height: 54)
                                    .background(NoxStyle.accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 15))
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("NOXFILES")
                                        .font(.title2.weight(.black)).tracking(1.5)
                                    Text("FILES · CONTAINERS · RECOVERY")
                                        .font(.caption2.weight(.bold)).tracking(1.1)
                                        .foregroundStyle(NoxStyle.accent)
                                }
                            }
                            Text("Browse, inspect and manage files where iOS permissions allow. Deleted files go to your private NoxTrash first.")
                                .font(.footnote).foregroundStyle(NoxStyle.pale)
                            Button { showGoToPath = true } label: {
                                Label("Go to Path", systemImage: "arrow.right.circle.fill")
                                    .frame(maxWidth: .infinity)
                            }.buttonStyle(.borderedProminent).tint(NoxStyle.violet)
                        }
                    }
                    NoxLauncherStatusStrip()
                    title("QUICK ACCESS")
                    LazyVGrid(columns: columns, spacing: 11) {
                        shortcut("Documents", subtitle: "App files", icon: "doc.fill", destination: FileBrowserView(path: URL.documentsDirectory))
                        shortcut("NoxTrash", subtitle: "\(trash.entries.count) deleted items", icon: "trash.fill", destination: NoxTrashView())
                        shortcut("MobileGestalt", subtitle: "Cache explorer", icon: "cpu", destination: FileBrowserView(path: MGURL.fsGestaltURL.deletingLastPathComponent(), shouldGrant: true))
                        shortcut("Profiles", subtitle: "Configuration", icon: "checkmark.shield", destination: FileBrowserView(path: FSURL.configProfiles, shouldGrant: true))
                    }
                    Button {
                        showTrashWarning = true
                    } label: {
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                                .font(.title3)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("NoxTrash is NOT an iOS system trash")
                                    .font(.subheadline.weight(.bold))
                                    .foregroundStyle(.orange)
                                Text("Stored only in NOXERRA data. Deleting the app deletes its trash, too.")
                                    .font(.caption)
                                    .foregroundStyle(NoxStyle.pale)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "info.circle.fill")
                                .foregroundStyle(.orange)
                        }
                        .padding(13)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 15))
                        .overlay(RoundedRectangle(cornerRadius: 15).strokeBorder(.orange.opacity(0.42)))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Important NoxTrash storage warning. Tap for details.")
                    title("FILE TOOLS")
                    NoxCard {
                        VStack(alignment: .leading, spacing: 12) {
                            NavigationLink(destination: AdCacheBlockerView()) {
                                Label("Splash Ad Cache Blocker", systemImage: "lock.shield.fill")
                            }
                            Divider().overlay(NoxStyle.accent.opacity(0.22))
                            NavigationLink(destination: NoxShellView()) {
                                Label("Open NoxShell Terminal", systemImage: "terminal.fill")
                            }
                            Text("Explore the same filesystem using commands such as ls, cd, touch and trash.")
                                .font(.caption2).foregroundStyle(NoxStyle.pale)
                        }.font(.subheadline.weight(.semibold))
                    }
                    if !navStore.recentFolders.isEmpty {
                        HStack {
                            title("RECENT LOCATIONS")
                            Spacer()
                            Button("Clear", role: .destructive) { navStore.clear() }
                                .font(.caption)
                        }
                        NoxCard {
                            VStack(alignment: .leading, spacing: 11) {
                                ForEach(navStore.recentFolders.prefix(6)) { entry in
                                    NavigationLink(destination: FileBrowserView(path: URL(fileURLWithPath: entry.path), shouldGrant: true)) {
                                        HStack(spacing: 10) {
                                            Image(systemName: "clock.arrow.circlepath")
                                                .foregroundStyle(NoxStyle.cyan)
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(entry.title).font(.subheadline.weight(.semibold))
                                                Text(entry.path).font(.caption2.monospaced())
                                                    .foregroundStyle(NoxStyle.pale)
                                                    .lineLimit(1).truncationMode(.middle)
                                            }
                                            Spacer(minLength: 0)
                                            Image(systemName: "chevron.right").foregroundStyle(NoxStyle.accent)
                                        }
                                    }
                                    if entry.path != navStore.recentFolders.prefix(6).last?.path {
                                        Divider().overlay(NoxStyle.accent.opacity(0.2))
                                    }
                                }
                            }
                        }
                    }
                    title("APP CONTAINERS")
                    NoxCard {
                        VStack(alignment: .leading, spacing: 13) {
                            folderLink("Application Data", icon: "square.grid.2x2", path: FSURL.appContainers)
                            folderLink("Plugin Containers", icon: "puzzlepiece.extension", path: FSURL.appPlugins)
                            folderLink("Shared App Groups", icon: "square.stack.3d.up", path: FSURL.appGroup)
                        }
                    }
                    title("SYSTEM LOCATIONS")
                    NoxCard {
                        VStack(alignment: .leading, spacing: 13) {
                            folderLink("Daemon Containers", icon: "gearshape.2", path: FSURL.internalDaemons)
                            folderLink("System Data", icon: "internaldrive", path: FSURL.systemData)
                            folderLink("System Groups", icon: "server.rack", path: FSURL.sysGroup)
                        }
                    }
                    Text("Sandbox permissions are enforced by iOS. NoxFiles uses the engine selected on Home and checks whether each requested path is actually accessible.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 16)
            }
            .navigationTitle("Files")
            .scrollContentBackground(.hidden)
            .background(NoxAmbientBackground())
            .tint(NoxStyle.accent)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showGoToPath = true } label: {
                        Label("Go to Path", systemImage: "arrow.forward.circle")
                    }
                }
            }
            .alert("Important: NoxTrash is app-local", isPresented: $showTrashWarning) {
                Button("Understood", role: .cancel) {}
            } message: {
                Text(NoxTrash.storageWarning)
            }
            .sheet(isPresented: $showGoToPath) {
                GoToPathSheet { target in goToTarget = target }
            }
            .navigationDestination(item: $goToTarget) { target in
                FileBrowserView(path: target.url, isContainer: target.isContainer, shouldGrant: target.shouldGrant)
            }
        }
    }

    private func title(_ text: String) -> some View {
        Text(text).font(.caption.weight(.heavy)).tracking(1.8).foregroundStyle(NoxStyle.accent)
    }

    private func shortcut<Destination: View>(_ text: String, subtitle: String, icon: String, destination: Destination) -> some View {
        NavigationLink(destination: destination) {
            NoxCard {
                VStack(alignment: .leading, spacing: 7) {
                    Image(systemName: icon).font(.title2).foregroundStyle(NoxStyle.cyan)
                    Text(text).font(.subheadline.weight(.bold)).foregroundStyle(.white)
                    Text(subtitle).font(.caption2).foregroundStyle(NoxStyle.pale)
                }.frame(height: 73, alignment: .leading)
            }
        }.buttonStyle(.plain)
    }

    private func folderLink(_ name: String, icon: String, path: URL) -> some View {
        NavigationLink(destination: FileBrowserView(path: path, isContainer: true)) {
            HStack(spacing: 12) {
                Image(systemName: icon).foregroundStyle(NoxStyle.cyan).frame(width: 24)
                Text(name).font(.subheadline.weight(.semibold))
                Spacer()
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(NoxStyle.accent)
            }
        }
    }
}

private struct GoToPathSheet: View {
    var onNavigate: (GoToPathTarget) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var pathText = ""
    @State private var clipboardSuggestion: String?
    @State private var errorMessage: String?

    private static let containerRoots: Set<String> = [
        FMNavigationStore.canonicalPath(FSURL.appContainers.path),
        FMNavigationStore.canonicalPath(FSURL.appPlugins.path),
        FMNavigationStore.canonicalPath(FSURL.appGroup.path),
        FMNavigationStore.canonicalPath(FSURL.internalDaemons.path),
        FMNavigationStore.canonicalPath(FSURL.systemData.path),
        FMNavigationStore.canonicalPath(FSURL.sysGroup.path)
    ]

    var body: some View {
        NavigationStack {
            List {
                if let suggestion = clipboardSuggestion {
                    Section {
                        Button {
                            pathText = suggestion
                            navigate(to: suggestion)
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Label(
                                    LocalizationManager.isEnglish ? "Open Clipboard Path" : "使用剪贴板路径直达",
                                    systemImage: "doc.on.clipboard"
                                )
                                .font(.subheadline.weight(.semibold))
                                Text(suggestion)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(2)
                                    .truncationMode(.middle)
                            }
                        }
                    } header: {
                        HeaderLabel(
                            LocalizationManager.isEnglish ? "Clipboard Suggestion" : "剪贴板路径建议",
                            symbol: "sparkles"
                        )
                    }
                }

                Section {
                    HStack(spacing: 8) {
                        TextField("/var/mobile/Containers/...", text: $pathText)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .submitLabel(.go)
                            .onSubmit {
                                navigate(to: pathText)
                            }

                        if !pathText.isEmpty {
                            Button {
                                pathText = ""
                                errorMessage = nil
                            } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .foregroundStyle(.secondary)
                            }
                            .buttonStyle(.borderless)
                        }
                    }

                    Button {
                        navigate(to: pathText)
                    } label: {
                        Label(
                            LocalizationManager.isEnglish ? "Open Directory" : "打开目录",
                            systemImage: "arrow.right.circle.fill"
                        )
                        .fontWeight(.semibold)
                    }
                    .disabled(pathText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                } header: {
                    HeaderLabel(
                        LocalizationManager.isEnglish ? "Target Path" : "输入目标路径",
                        symbol: "folder"
                    )
                } footer: {
                    Text(
                        LocalizationManager.isEnglish
                            ? "Enter an absolute folder path (or file path to jump to its parent folder). Requests sandbox access using the engine selected on Home."
                            : "输入绝对文件夹路径（若输入文件路径则自动定位到其父目录），使用主页所选引擎申请沙盒访问令牌。"
                    )
                }

                if let errorMessage {
                    CompactAlert(
                        title: LocalizationManager.isEnglish ? "Cannot Open Path" : "无法打开该路径",
                        symbol: "exclamationmark.triangle",
                        text: errorMessage,
                        color: .red
                    )
                    .listRowInsets(EdgeInsets())
                    .listRowBackground(Color.clear)
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(LocalizationManager.isEnglish ? "Go to Path" : "路径直达")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        ToolbarLabel("关闭", symbol: "xmark")
                    }
                }
            }
            .onAppear {
                detectClipboardPath()
            }
        }
    }

    private func detectClipboardPath() {
        guard let raw = UIPasteboard.general.string?.trimmingCharacters(in: .whitespacesAndNewlines),
              !raw.isEmpty else {
            clipboardSuggestion = nil
            return
        }
        let unquoted = raw.trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))
        if unquoted.hasPrefix("/var/") || unquoted.hasPrefix("/private/var/") {
            clipboardSuggestion = unquoted
            if pathText.isEmpty {
                pathText = unquoted
            }
        } else {
            clipboardSuggestion = nil
        }
    }

    private func navigate(to rawInput: String) {
        errorMessage = nil
        let cleaned = rawInput
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "\"'"))

        guard cleaned.hasPrefix("/") else {
            errorMessage = LocalizationManager.isEnglish
                ? "Please enter an absolute path starting with '/'."
                : "请输入以 / 开头的绝对路径。"
            return
        }

        let canonical = FMNavigationStore.canonicalPath(cleaned)
        if Self.containerRoots.contains(canonical) {
            dismiss()
            onNavigate(GoToPathTarget(
                url: URL(fileURLWithPath: canonical),
                isContainer: true,
                shouldGrant: false
            ))
            return
        }

        var targetPath = canonical
        var grantedByUs = false
        let wasActive = wq.hasActiveAccess(path: targetPath)
        if !fm.isReadableFile(atPath: targetPath) {
            let grant = wq.grantAccess(path: targetPath, requireWrite: false)
            if grant.0 && !wasActive {
                grantedByUs = true
            }
        }

        var st = stat()
        if stat(targetPath, &st) != 0 {
            if grantedByUs {
                wq.releaseAccess(path: targetPath)
            }
            errorMessage = LocalizationManager.isEnglish
                ? "Path does not exist or sandbox access was denied: \(targetPath)"
                : "目标路径不存在或无沙盒访问权限：\(targetPath)"
            return
        }

        if (st.st_mode & S_IFMT) != S_IFDIR {
            if grantedByUs {
                wq.releaseAccess(path: targetPath)
                grantedByUs = false
            }
            targetPath = URL(fileURLWithPath: targetPath).deletingLastPathComponent().path
            let parentWasActive = wq.hasActiveAccess(path: targetPath)
            if !fm.isReadableFile(atPath: targetPath) {
                let parentGrant = wq.grantAccess(path: targetPath, requireWrite: false)
                if !parentGrant.0 && !fm.isReadableFile(atPath: targetPath) {
                    errorMessage = parentGrant.2
                    return
                }
                if parentGrant.0 && !parentWasActive {
                    grantedByUs = true
                }
            }
        } else if !fm.isReadableFile(atPath: targetPath) {
            if grantedByUs {
                wq.releaseAccess(path: targetPath)
            }
            errorMessage = LocalizationManager.isEnglish
                ? "Directory cannot be read inside current sandbox."
                : "当前沙盒无权读取该目录。"
            return
        }

        let finalURL = URL(fileURLWithPath: targetPath)
        dismiss()
        onNavigate(GoToPathTarget(
            url: finalURL,
            isContainer: false,
            shouldGrant: true
        ))
    }
}
