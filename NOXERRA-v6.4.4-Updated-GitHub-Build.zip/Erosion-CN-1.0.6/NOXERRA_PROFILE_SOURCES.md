# NOXERRA Supervised Tweaks — implementation notes

The new native `.mobileconfig` builder is an independent Swift implementation informed by the public iOS configuration-profile structures illustrated in the user-provided Lithium 0.2 archive. It does not bundle Lithium's PartyUI package or reproduce Lithium's interface. Common payload types: com.apple.shareddeviceconfiguration, com.apple.webClip.managed, com.apple.applicationaccess and com.apple.notificationsettings.

Profile applicability depends on supervision, iOS version, and Apple management policy. Generated profiles are intended for the owner of the device. NOXERRA does not silently install them and provides an export action instead. Remove installed profiles from Settings > General > VPN & Device Management.
