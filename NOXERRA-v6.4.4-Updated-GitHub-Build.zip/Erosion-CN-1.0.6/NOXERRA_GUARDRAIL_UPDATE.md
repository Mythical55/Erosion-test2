# NOXERRA MobileGestalt settings update

- Settings now exposes separate switches for compatibility-gated experiments and warning icons.
- Warning icons can be hidden without modifying device cache data.
- Existing compatibility-gated tweaks remain controlled by `mgOverrideGates`.
- The original hard-disabled iPadOS UI/Medusa modification remains protected. The underlying source uses an unverified CacheData operation known to bootloop iPhones; hiding warnings does not change its protection.
- No Apple MobileGestalt write path was modified in this patch.
- iOS compilation and device testing are still required.
