# NOXERRA v5.6 — MobileGestalt, Home and Dialer update

Built on the complete NOXERRA v5.5.1 CompileFix source.

## Updated screens

- Home: live date, time, and context-sensitive Good morning/afternoon/evening/night greeting in a themed card.
- Tweaks list: MobileGestalt (System Values) entry.
- MobileGestalt: directly accessible safety settings, vault status, factory restoration, cache rebuild, original / current backup import-export, pre-apply snapshot, experimental visibility, and custom key settings.
- MobileGestalt: System Values / Key Editor segmented workspace. Key Editor is the previous real custom-key implementation (Bool, Int, String, validation, apply).
- MobileGestalt: labels for extra safety guidance, iOS-managed supervision, iPad native multitasking, and validated iOS 27 AI capability status.
- User Restrictions: expanded category selection with counts, staged edits indicator, and current staged field values in details.
- Phone App Dialer Keypad Themes: local interactive phone keypad preview that displays actual staged key images (where present), number test and delete; an official Cowabunga site link.

## Safety / honest feature limitations

The Anti-Bootloop Safety Protocol toggle controls OPTIONAL extra guidance and hidden-tweak gating. It does NOT disable mandatory backup checks, change diffs, original-cache validation, rollback, verified writes or F_FULLFSYNC. Both toggle positions keep the verified write implementation intact. In the off state, the app still requires the change diff confirmation.

'Locked Supervised Mode' is a device-policy status with a link to Supervised Profile Tools: MobileGestalt cannot grant OS-level supervision.

On iPhone, unverified iPadOS UI / Split View memory patches remain disabled. Native iPad Stage Manager controls remain available on compatible iPad hardware. iOS 27 Intelligence options remain guardrailed according to actual hardware/cache; unsupported capabilities are not force-enabled.

Previewing or tapping the simulated phone dialer cannot initiate a call. Cowabunga's main site does not guarantee specific compatible Phone keypad packs.

## Validation

- Swift frontend syntax parse of all 89 Swift sources: passed on Linux.
- Bundled plists: validated with Python plistlib.
- Complete ZIP CRC integrity: verified after packing.
- A full iOS app build, device test, and IPA validation require Xcode on macOS; not claimed here.
