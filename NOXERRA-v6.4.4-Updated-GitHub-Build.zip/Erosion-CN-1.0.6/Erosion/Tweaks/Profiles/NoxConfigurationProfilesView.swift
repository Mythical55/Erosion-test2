// NOXERRA Configuration Profiles · reader and carefully confirmed .stub manager
// Enumerates the same on-device ConfigurationProfiles directory as NoxFiles.
// A .stub is NOT automatically a readable .mobileconfig or evidence that a
// profile is active. In particular, zero-byte stubs have no embedded name.

import SwiftUI
import Foundation
import UIKit

private struct NoxProfileField: Identifiable {
    let key: String
    let value: String
    var id: String { key }
}

private struct NoxProfilePayload: Identifiable {
    let index: Int
    let name: String
    let type: String
    let identifier: String
    var id: Int { index }
}

private enum NoxProfileKind: String {
    case stub = "Profile stub"
    case mobileconfig = "Configuration profile"
    case plist = "Property list"
    case folder = "Directory"
    case other = "Other file"

    var symbol: String {
        switch self {
        case .stub: return "checkmark.shield"
        case .mobileconfig: return "checkmark.shield.fill"
        case .plist: return "doc.text"
        case .folder: return "folder.fill"
        case .other: return "doc"
        }
    }
    var isProfile: Bool { self == .stub || self == .mobileconfig }
}

private struct NoxProfileFile: Identifiable {
    let url: URL
    let kind: NoxProfileKind
    let size: Int64
    let created: Date?
    let modified: Date?
    let readable: Bool
    let writable: Bool
    let permissions: String?
    let embeddedName: String?
    let properties: [NoxProfileField]
    let payloads: [NoxProfilePayload]
    let plistWasParsed: Bool

    var id: String { url.path }
    var filename: String { url.lastPathComponent }
    var displayName: String { embeddedName ?? filename }
    var hasFriendlyName: Bool { embeddedName != nil }
    var fileSizeText: String {
        if kind == .folder { return "Folder" }
        if size == 0 { return "0 bytes" }
        return ByteCountFormatter.string(fromByteCount: size, countStyle: .file)
    }
}

private struct NoxProfileScan {
    let files: [NoxProfileFile]
    let error: String?
    let status: String
}

private enum NoxProfileScanner {
    static let directory = FSURL.configProfiles

    // Keep previews bounded: some Apple metadata databases are much larger
    // than profile stubs, and the inspector never needs an entire database.
    private static let maxParsedSize: Int64 = 2_000_000

    static func scan(using backend: NoxExploitBackend) -> NoxProfileScan {
        let manager = FileManager.default
        let directoryPath = directory.path
        let alreadyReadable = (try? manager.contentsOfDirectory(atPath: directoryPath)) != nil
        let alreadyGranted = wq.hasActiveAccess(path: directoryPath, backend: backend)
        var acquiredGrant = false
        var grantError = ""

        if !alreadyReadable {
            let result = wq.grantAccess(path: directoryPath, requireWrite: false, backend: backend)
            acquiredGrant = result.0 && !alreadyGranted
            if !result.0 { grantError = result.2 }
        }
        defer {
            // Never release a grant held by the Home launcher or NoxFiles.
            if acquiredGrant { wq.releaseAccess(path: directoryPath, backend: backend) }
        }

        do {
            let urls = try manager.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey, .creationDateKey, .contentModificationDateKey],
                options: []
            )
            let files = urls.map { inspect($0) }
                .sorted { $0.filename.localizedStandardCompare($1.filename) == .orderedAscending }
            let status: String
            if alreadyReadable { status = "Already readable before access request" }
            else if acquiredGrant { status = "Directory readable after \(backend.displayName) request" }
            else { status = "Directory readable" }
            return NoxProfileScan(files: files, error: nil, status: status)
        } catch {
            let detail = grantError.isEmpty ? error.localizedDescription : grantError
            return NoxProfileScan(files: [], error: "Could not list the profile store: \(detail)", status: "Read access unavailable")
        }
    }

    private static func string(_ object: Any?, max: Int = 180) -> String? {
        guard let value = object as? String else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return String(trimmed.prefix(max))
    }

    private static func field(_ dict: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let text = string(dict[key]) { return text }
        }
        return nil
    }

    private static func inspect(_ url: URL) -> NoxProfileFile {
        let manager = FileManager.default
        let attributes = (try? manager.attributesOfItem(atPath: url.path)) ?? [:]
        let isDirectory = (attributes[.type] as? FileAttributeType) == .typeDirectory
        let ext = url.pathExtension.lowercased()
        let kind: NoxProfileKind
        if isDirectory { kind = .folder }
        else if ext == "stub" { kind = .stub }
        else if ext == "mobileconfig" { kind = .mobileconfig }
        else if ext == "plist" { kind = .plist }
        else { kind = .other }

        let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0
        let mode = (attributes[.posixPermissions] as? NSNumber).map { String(format: "%04o", $0.intValue) }
        let canRead = manager.isReadableFile(atPath: url.path)
        var title: String?
        var fields: [NoxProfileField] = []
        var payloads: [NoxProfilePayload] = []
        var parsed = false

        if !isDirectory && canRead && size > 0 && size <= maxParsedSize &&
            (kind == .stub || kind == .plist || kind == .mobileconfig),
            let data = try? Data(contentsOf: url),
            let root = (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) as? [String: Any] {
            parsed = true
            // An embedded display name is evidence; do not infer one from an
            // opaque UUID or unrelated MCSettings/ClientTruth keys.
            title = field(root, keys: ["PayloadDisplayName", "ProfileDisplayName", "DisplayName"])
            let allowed = [
                "PayloadDisplayName", "PayloadDescription", "PayloadIdentifier", "PayloadUUID",
                "PayloadOrganization", "PayloadType", "PayloadVersion", "ProfileDisplayName",
                "ProfileIdentifier", "ProfileUUID", "PayloadRemovalDisallowed"
            ]
            for key in allowed {
                if let value = string(root[key]) {
                    fields.append(NoxProfileField(key: key, value: value))
                } else if let number = root[key] as? NSNumber {
                    fields.append(NoxProfileField(key: key, value: number.stringValue))
                }
            }
            if let embedded = root["PayloadContent"] as? [[String: Any]] {
                payloads = embedded.prefix(150).enumerated().map { index, item in
                    NoxProfilePayload(
                        index: index,
                        name: field(item, keys: ["PayloadDisplayName"]) ?? "Payload \(index + 1)",
                        type: field(item, keys: ["PayloadType"]) ?? "Unknown type",
                        identifier: field(item, keys: ["PayloadIdentifier"]) ?? "Not supplied"
                    )
                }
            }
        }
        return NoxProfileFile(
            url: url, kind: kind, size: size,
            created: attributes[.creationDate] as? Date,
            modified: attributes[.modificationDate] as? Date,
            readable: canRead,
            writable: manager.isWritableFile(atPath: url.path),
            permissions: mode,
            embeddedName: title,
            properties: fields,
            payloads: payloads,
            plistWasParsed: parsed
        )
    }
}

struct NoxConfigurationProfilesView: View {
    @State private var files: [NoxProfileFile] = []
    @State private var scanStatus = "Not scanned"
    @State private var scanError: String?
    @State private var loading = false
    @State private var hasScanned = false
    @State private var search = ""
    @State private var showingProfiles = true
    @State private var showingCreateStub = false

    private var visibleFiles: [NoxProfileFile] {
        let query = search.trimmingCharacters(in: .whitespacesAndNewlines)
        return files.filter { item in
            let included = showingProfiles ? item.kind.isProfile : !item.kind.isProfile
            guard included else { return false }
            return query.isEmpty || item.filename.localizedCaseInsensitiveContains(query) ||
                item.displayName.localizedCaseInsensitiveContains(query) ||
                item.properties.contains { $0.value.localizedCaseInsensitiveContains(query) }
        }
    }
    private var stubCount: Int { files.filter { $0.kind == .stub }.count }
    private var profileCount: Int { files.filter { $0.kind.isProfile }.count }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 15) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 11) {
                        HStack(spacing: 12) {
                            Image(systemName: "checkmark.shield.fill")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(NoxStyle.cyan)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("CONFIGURATION PROFILES")
                                    .font(.headline.weight(.black))
                                Text("On-device profile store · inspection + .stub tools")
                                    .font(.caption).foregroundStyle(NoxStyle.pale)
                            }
                            Spacer(minLength: 0)
                        }
                        Text(NoxProfileScanner.directory.path)
                            .font(.caption2.monospaced())
                            .foregroundStyle(NoxStyle.pale)
                            .textSelection(.enabled)
                        Text("View the profile-… .stub files shown in NoxFiles, plus their file details and any readable embedded profile information.")
                            .font(.footnote).foregroundStyle(NoxStyle.pale)
                        HStack(spacing: 11) {
                            Label("\(stubCount) stubs", systemImage: "doc.text")
                            Label("\(files.count) items", systemImage: "folder")
                        }
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(NoxStyle.cyan)
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("Live profile-store browser", systemImage: "info.circle.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(NoxStyle.cyan)
                        Text("Inspect profile stubs and metadata. File edits require actual write permission and an explicit confirmation; changing a .stub does NOT install, enable, disable or remove an iOS profile. iOS may repair or overwrite manual changes.")
                            .font(.caption).foregroundStyle(NoxStyle.pale)
                        Text(scanStatus)
                            .font(.caption2).foregroundStyle(.secondary)
                    }
                }

                Picker("Stored items", selection: $showingProfiles) {
                    Text("Profiles (\(profileCount))").tag(true)
                    Text("Other files (\(files.count - profileCount))").tag(false)
                }
                .pickerStyle(.segmented)

                if loading {
                    NoxCard {
                        HStack(spacing: 12) {
                            ProgressView()
                            Text("Reading configuration profile directory…")
                                .font(.subheadline).foregroundStyle(NoxStyle.pale)
                        }
                    }
                } else if let scanError {
                    NoxCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("Unable to read profile store", systemImage: "lock.fill")
                                .font(.headline).foregroundStyle(.orange)
                            Text(scanError).font(.footnote).foregroundStyle(NoxStyle.pale)
                            Button("Retry") { refresh() }
                                .buttonStyle(.borderedProminent).tint(NoxStyle.violet)
                        }
                    }
                } else if visibleFiles.isEmpty {
                    NoxCard {
                        Text(hasScanned ? "No matching entries found." : "Tap Refresh to inspect profiles.")
                            .foregroundStyle(NoxStyle.pale)
                    }
                } else {
                    ForEach(visibleFiles) { item in
                        NavigationLink {
                            if item.kind == .folder {
                                FileBrowserView(path: item.url, shouldGrant: true)
                            } else {
                                NoxProfileFileDetailsView(file: item, onChanged: refresh)
                            }
                        } label: {
                            HStack(alignment: .center, spacing: 12) {
                                Image(systemName: item.kind.symbol)
                                    .font(.title3.weight(.semibold))
                                    .foregroundStyle(NoxStyle.cyan)
                                    .frame(width: 31)
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(item.displayName)
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(.white)
                                        .lineLimit(2)
                                        .multilineTextAlignment(.leading)
                                    if item.hasFriendlyName {
                                        Text(item.filename)
                                            .font(.caption2.monospaced())
                                            .foregroundStyle(NoxStyle.pale)
                                            .lineLimit(1)
                                            .truncationMode(.middle)
                                    }
                                    HStack(spacing: 9) {
                                        Text(item.fileSizeText)
                                        if let modified = item.modified {
                                            Text(modified.formatted(date: .numeric, time: .shortened))
                                        }
                                    }
                                    .font(.caption2).foregroundStyle(NoxStyle.pale)
                                }
                                Spacer(minLength: 0)
                                Image(systemName: "info.circle")
                                    .font(.title3).foregroundStyle(NoxStyle.accent)
                            }
                            .padding(14)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 17))
                        }
                        .buttonStyle(.plain)
                    }
                }
                NavigationLink {
                    FileBrowserView(path: NoxProfileScanner.directory, shouldGrant: true)
                } label: {
                    Label("Open original folder in NoxFiles", systemImage: "folder.fill")
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity)
                        .padding(13)
                        .background(NoxStyle.accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 15))
                }
                .buttonStyle(.plain)
                Text("Use iOS Settings → General → VPN & Device Management to install or remove real profiles. Manual .stub operations are filesystem edits only. Backups live inside NOXERRA and must be exported to survive uninstalling the app.")
                    .font(.caption2).foregroundStyle(.secondary)
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("Configuration Profiles")
        .navigationBarTitleDisplayMode(.inline)
        .tint(NoxStyle.accent)
        .searchable(text: $search, prompt: "Search profile names or .stub filenames")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack {
                    Button { showingCreateStub = true } label: { Image(systemName: "plus") }
                        .accessibilityLabel("Create .stub file")
                    Button { refresh() } label: { Image(systemName: "arrow.clockwise") }
                        .disabled(loading)
                        .accessibilityLabel("Refresh configuration profiles")
                }
            }
        }
        .sheet(isPresented: $showingCreateStub) {
            NoxCreateStubSheet(onCreated: { refresh() })
        }
        .onAppear { if !hasScanned { refresh() } }
    }

    private func refresh() {
        guard !loading else { return }
        loading = true
        let backend = NoxExploitSelection.current
        DispatchQueue.global(qos: .userInitiated).async {
            let result = NoxProfileScanner.scan(using: backend)
            DispatchQueue.main.async {
                files = result.files
                scanError = result.error
                scanStatus = result.status
                hasScanned = true
                loading = false
            }
        }
    }
}

private struct NoxProfileFileDetailsView: View {
    let file: NoxProfileFile
    let onChanged: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Label(file.displayName, systemImage: file.kind.symbol)
                            .font(.headline.weight(.bold))
                            .foregroundStyle(NoxStyle.cyan)
                            .textSelection(.enabled)
                        if file.hasFriendlyName {
                            Text("Display name read from embedded plist data")
                                .font(.caption2).foregroundStyle(NoxStyle.pale)
                        }
                        Text(file.filename)
                            .font(.footnote.monospaced())
                            .textSelection(.enabled)
                            .foregroundStyle(NoxStyle.pale)
                        Button {
                            UIPasteboard.general.string = file.url.path
                        } label: {
                            Label("Copy full path", systemImage: "doc.on.doc")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered).tint(NoxStyle.accent)
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("FILE INFORMATION")
                            .font(.caption.weight(.heavy)).tracking(1.4)
                            .foregroundStyle(NoxStyle.accent)
                        info("Type", file.kind.rawValue)
                        info("Size", file.fileSizeText)
                        info("Created", file.created.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "Unavailable")
                        info("Modified", file.modified.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "Unavailable")
                        info("Readable", file.readable ? "Yes at scan time" : "No at scan time")
                        info("Writable", file.writable ? "Permission indicated" : "Not indicated")
                        if let permissions = file.permissions { info("POSIX mode", permissions) }
                        Divider().overlay(NoxStyle.accent.opacity(0.25))
                        Text(file.url.path)
                            .font(.caption2.monospaced())
                            .foregroundStyle(NoxStyle.pale)
                            .textSelection(.enabled)
                    }
                }

                if !file.properties.isEmpty {
                    NoxCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("EMBEDDED PROFILE METADATA")
                                .font(.caption.weight(.heavy)).tracking(1.3)
                                .foregroundStyle(NoxStyle.accent)
                            ForEach(file.properties) { property in
                                info(property.key, property.value)
                            }
                        }
                    }
                }

                if !file.payloads.isEmpty {
                    NoxCard {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("PROFILE PAYLOADS (\(file.payloads.count))")
                                .font(.caption.weight(.heavy)).tracking(1.3)
                                .foregroundStyle(NoxStyle.accent)
                            ForEach(file.payloads) { payload in
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(payload.name).font(.subheadline.weight(.semibold))
                                    Text(payload.type).font(.caption).foregroundStyle(NoxStyle.cyan)
                                    Text(payload.identifier)
                                        .font(.caption2.monospaced())
                                        .foregroundStyle(NoxStyle.pale)
                                        .textSelection(.enabled)
                                }
                                Divider().overlay(NoxStyle.accent.opacity(0.22))
                            }
                        }
                    }
                }

                if file.kind == .stub && file.size == 0 {
                    NoxCard {
                        VStack(alignment: .leading, spacing: 6) {
                            Label("Empty profile stub", systemImage: "info.circle")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.orange)
                            Text("This .stub is zero bytes. The filename and filesystem attributes are available, but there is no embedded configuration payload or friendly profile name to decode. Do not interpret this as a complete installed profile.")
                                .font(.footnote).foregroundStyle(NoxStyle.pale)
                        }
                    }
                } else if !file.plistWasParsed && file.kind != .folder {
                    Text("No readable profile plist payload was found in this file. The original bytes are unchanged.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                }

                if file.kind == .stub {
                    NoxProfileStubTools(file: file, onChanged: onChanged)
                    NavigationLink {
                        NoxProfileAllContentsView(url: file.url)
                    } label: {
                        Label("View all file data · XML / text / hex", systemImage: "doc.text.magnifyingglass")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered).tint(NoxStyle.accent)
                }

                NavigationLink {
                    FileBrowserView(
                        path: file.url.deletingLastPathComponent(),
                        shouldGrant: true,
                        highlightTargetURL: file.url
                    )
                } label: {
                    Label("Locate in NoxFiles", systemImage: "folder.fill")
                        .frame(maxWidth: .infinity)
                        .padding(12)
                }
                .buttonStyle(.bordered).tint(NoxStyle.accent)
            }
            .padding(16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle(file.filename)
        .navigationBarTitleDisplayMode(.inline)
    }

    private func info(_ title: String, _ detail: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.caption2.weight(.semibold)).foregroundStyle(NoxStyle.pale)
            Text(detail).font(.subheadline).textSelection(.enabled)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - Confirmed .stub file operations

private struct NoxCreateStubSheet: View {
    @Environment(\.dismiss) private var dismiss
    let onCreated: () -> Void
    @State private var name = "profile-\(UUID().uuidString.lowercased()).stub"
    @State private var error: String?
    @State private var confirmCreate = false
    @State private var created = false

    var body: some View {
        NavigationStack {
            Form {
                Section("New .stub filename") {
                    TextField("profile-….stub", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Text("Creates a zero-byte file, not an installed configuration profile.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section {
                    Text("The ConfigurationProfiles directory is controlled by iOS. Unrecognized stub files may be ignored, removed or cause unexpected behavior. Only use on your own test device. The selected sandbox engine must provide real write access.")
                        .foregroundStyle(.orange)
                    Button("Create stub file") { confirmCreate = true }
                        .disabled(created)
                }
                if let error {
                    Section { Text(error).foregroundStyle(.red).textSelection(.enabled) }
                }
            }
            .navigationTitle("New Profile Stub")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Close") { dismiss() } } }
            .confirmationDialog("Create this file in the system profile store?", isPresented: $confirmCreate) {
                Button("Create .stub") { create() }
            } message: { Text("This only creates a file; it does not install a profile.") }
        }
    }

    private func create() {
        do {
            let destination = try NoxProfileStoreIO.stubURL(named: name)
            _ = try NoxProfileStoreIO.write(Data(), to: destination, expectedOriginal: nil, createNew: true)
            created = true
            onCreated()
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}

private struct NoxProfileStubTools: View {
    let file: NoxProfileFile
    let onChanged: () -> Void
    @State private var rename = ""
    @State private var renamePrompt = false
    @State private var deletePrompt = false
    @State private var lastBackup: URL?
    @State private var deletedByTool = false
    @State private var feedback: String?

    var body: some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 12) {
                Label("MANAGE .STUB FILE", systemImage: "slider.horizontal.3")
                    .font(.subheadline.weight(.bold)).foregroundStyle(NoxStyle.cyan)
                Text("These actions change the underlying .stub file, NOT the installed profile recorded by iOS. Files can be zero bytes. A backup is made before any rename, edit or deletion.")
                    .font(.caption).foregroundStyle(NoxStyle.pale)
                NavigationLink {
                    NoxStubContentEditor(url: file.url, onChanged: onChanged)
                } label: {
                    Label("View / edit file contents", systemImage: "square.and.pencil")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.bordered).tint(NoxStyle.accent)
                Button {
                    rename = file.filename
                    renamePrompt = true
                } label: { Label("Rename .stub", systemImage: "pencil.line") }
                    .buttonStyle(.bordered).tint(NoxStyle.accent)
                Button {
                    do {
                        lastBackup = try NoxProfileStoreIO.withAccess(write: false) {
                            try NoxProfileStoreIO.backup(file.url)
                        }
                        feedback = "Backup created in Documents/NOXERRA/ProfileBackups. Export it before uninstalling NOXERRA."
                    } catch { feedback = error.localizedDescription }
                } label: { Label("Back up original", systemImage: "externaldrive.badge.plus") }
                    .buttonStyle(.bordered).tint(NoxStyle.accent)
                if let lastBackup {
                    ShareLink(item: lastBackup) { Label("Export last backup", systemImage: "square.and.arrow.up") }
                        .buttonStyle(.bordered)
                    if deletedByTool {
                        Button {
                            do {
                                let bytes = try Data(contentsOf: lastBackup)
                                _ = try NoxProfileStoreIO.write(bytes, to: file.url, expectedOriginal: nil, createNew: true)
                                deletedByTool = false
                                feedback = "Restored the original .stub bytes from the app backup."
                                onChanged()
                            } catch { feedback = error.localizedDescription }
                        } label: { Label("Restore deleted .stub", systemImage: "arrow.uturn.backward") }
                            .buttonStyle(.bordered).tint(.green)
                    }
                }
                Button(role: .destructive) { deletePrompt = true } label: {
                    Label("Delete .stub (backup first)", systemImage: "trash")
                }
                .buttonStyle(.bordered)
                if let feedback { Text(feedback).font(.caption).foregroundStyle(NoxStyle.pale).textSelection(.enabled) }
            }
        }
        .alert("Rename profile stub", isPresented: $renamePrompt) {
            TextField("Filename ending .stub", text: $rename)
                .textInputAutocapitalization(.never)
            Button("Rename") {
                do {
                    _ = try NoxProfileStoreIO.renameStub(file.url, to: rename)
                    feedback = "Renamed. Reopen the entry from the refreshed list."
                    onChanged()
                } catch { feedback = error.localizedDescription }
            }
            Button("Cancel", role: .cancel) {}
        } message: { Text("The original is backed up first. Renaming an iOS-managed stub may invalidate its references.") }
        .confirmationDialog("Delete this system profile stub?", isPresented: $deletePrompt, titleVisibility: .visible) {
            Button("Back up and delete file", role: .destructive) {
                do {
                    lastBackup = try NoxProfileStoreIO.deleteStub(file.url)
                    deletedByTool = true
                    feedback = "File deleted. Backup is in NOXERRA Documents; export it now. This does not uninstall the actual profile."
                    onChanged()
                } catch { feedback = error.localizedDescription }
            }
            Button("Cancel", role: .cancel) {}
        } message: { Text("This changes an internal iOS file. A backup will be created first, but deleting NOXERRA also deletes its unexported backups.") }
    }
}

private struct NoxStubContentEditor: View {
    let url: URL
    let onChanged: () -> Void
    @State private var original: Data?
    @State private var draft = ""
    @State private var error: String?
    @State private var lastBackup: URL?
    @State private var confirmSave = false
    @State private var binaryContent = false

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(url.lastPathComponent).font(.headline).textSelection(.enabled)
                        Text("Text editor for empty or UTF-8 .stub data only. Binary or non-text files are protected from accidental conversion.")
                            .font(.footnote).foregroundStyle(NoxStyle.pale)
                    }
                }
                if let original {
                    if binaryContent {
                        NoxCard {
                            Label("Binary data — editing disabled", systemImage: "lock.fill")
                                .foregroundStyle(.orange)
                            Text("\(original.count) bytes. Changing these as text would corrupt the binary file. Back up and inspect through NoxFiles instead.")
                                .font(.caption)
                        }
                    } else {
                        NoxCard {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("CONTENTS · \(original.count) ORIGINAL BYTES")
                                    .font(.caption.weight(.bold)).foregroundStyle(NoxStyle.cyan)
                                TextEditor(text: $draft)
                                    .frame(minHeight: 220)
                                    .font(.system(.caption, design: .monospaced))
                                    .scrollContentBackground(.hidden)
                                    .background(NoxStyle.surface)
                                    .autocorrectionDisabled()
                                Button("Save contents (create backup)") { confirmSave = true }
                                    .buttonStyle(.borderedProminent).tint(NoxStyle.violet)
                                    .disabled(Data(draft.utf8) == original || Data(draft.utf8).count > NoxProfileStoreIO.maxEditableStubBytes)
                            }
                        }
                    }
                }
                if let lastBackup {
                    ShareLink(item: lastBackup) { Label("Export backup", systemImage: "square.and.arrow.up") }
                        .buttonStyle(.bordered)
                }
                if let error { Text(error).foregroundStyle(.orange).textSelection(.enabled) }
            }.padding(16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("Stub Contents")
        .navigationBarTitleDisplayMode(.inline)
        .confirmationDialog("Save edited bytes to the system profile store?", isPresented: $confirmSave) {
            Button("Back up and save") { save() }
        } message: { Text("This may affect iOS configuration state. Backups are stored in NOXERRA until exported.") }
        .onAppear(perform: load)
    }

    private func load() {
        do {
            let bytes = try NoxProfileStoreIO.read(url, maxBytes: NoxProfileStoreIO.maxEditableStubBytes)
            original = bytes
            binaryContent = String(data: bytes, encoding: .utf8) == nil || bytes.contains(0)
            if !binaryContent { draft = String(data: bytes, encoding: .utf8) ?? "" }
        } catch { self.error = error.localizedDescription }
    }
    private func save() {
        guard let original else { return }
        do {
            let bytes = Data(draft.utf8)
            lastBackup = try NoxProfileStoreIO.write(bytes, to: url, expectedOriginal: original)
            self.original = bytes
            error = "Saved and re-read successfully. iOS profile state may not change."
            onChanged()
        } catch { self.error = error.localizedDescription }
    }
}

// Full, bounded representation of every byte in a stub: plist XML (including
// all nested keys), plain UTF-8, or hex for opaque binary data.
private struct NoxProfileAllContentsView: View {
    let url: URL
    @State private var contents = ""
    @State private var summary = "Loading…"
    @State private var isLoading = true

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(url.lastPathComponent).font(.headline).textSelection(.enabled)
                        Text(summary).font(.footnote).foregroundStyle(NoxStyle.pale)
                    }
                }
                NoxCard {
                    Text(contents)
                        .font(.system(.caption2, design: .monospaced))
                        .foregroundStyle(NoxStyle.pale)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }.padding(16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("All Stored Data")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: load)
    }

    private func load() {
        guard isLoading else { return }
        isLoading = false
        do {
            let data = try NoxProfileStoreIO.read(url, maxBytes: 1_000_000)
            if data.isEmpty {
                summary = "0 bytes · empty file"
                contents = "No embedded data, profile name or payload exists in this zero-byte stub."
            } else if let root = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
                      let xml = try? PropertyListSerialization.data(fromPropertyList: root, format: .xml, options: 0),
                      let str = String(data: xml, encoding: .utf8) {
                summary = "\(data.count) bytes · all plist keys shown as XML"
                contents = str
            } else if let str = String(data: data, encoding: .utf8), !data.contains(0) {
                summary = "\(data.count) bytes · complete UTF-8 contents"
                contents = str
            } else {
                summary = "\(data.count) bytes · full hex representation (non-editable)"
                contents = data.enumerated().map { index, byte in
                    (index % 16 == 0 ? String(format: "\n%08x: ", index) : "") + String(format: "%02x ", byte)
                }.joined()
            }
        } catch {
            summary = "Cannot read file"
            contents = error.localizedDescription
        }
    }
}
