import SwiftUI

struct NoxSettingsView: View {
    @ObservedObject private var languageManager = LocalizationManager.shared
    @AppStorage("noxSoundEffects") private var soundEffects = true
    @AppStorage("noxAnimations") private var animations = true
    @AppStorage("noxNeonGlow") private var neonGlow = true
    @AppStorage("autoRespring") private var autoRespring = false
    @AppStorage(CSStoreEngine.fastScanDefaultsKey) private var fastMap = true
    @AppStorage("noxDismissAfterImport") private var dismissAfterImport = false
    @AppStorage("noxKeepScreenAwake") private var keepScreenAwake = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("NOXERRA · CONTROL CENTER", systemImage: "gearshape.2.fill")
                            .font(.caption.weight(.heavy)).foregroundStyle(NoxStyle.accent)
                        Text("Personalize how NOXERRA looks, sounds, and applies supported tweaks.")
                            .font(.subheadline).foregroundStyle(NoxStyle.pale)
                    }.padding(.vertical, 8)
                }
                Section("APPEARANCE & FEEDBACK") {
                    Toggle("Sound Effects", isOn: $soundEffects)
                    Text("Play subtle feedback when tapping supported controls.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    Toggle("Neon Edge Lighting", isOn: $neonGlow)
                    Text("Apply soft violet and cyan lighting across NOXERRA cards and screens. Turn off for a calmer interface.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    Toggle("Interface Animations", isOn: $animations)
                    Text("Enable animated transitions in NOXERRA-supported screens.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    Picker("Language", selection: $languageManager.languageModeRaw) {
                        Text("System Default").tag("system")
                        Text("English").tag("en")
                        Text("Deutsch").tag("de")
                        Text("Русский").tag("ru")
                    }
                }
                Section("TWEAK BEHAVIOR") {
                    Toggle("Auto Respring after applying", isOn: $autoRespring)
                    Text("Automatically reload SpringBoard after supported tweaks are applied. Some changes need a full restart.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    Toggle("[Beta] CSStore2 Fast Container Mapping Engine", isOn: $fastMap)
                    Text("Experimental app-container discovery. Disable if mapping is incomplete or paths are incorrect.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    if fastMap {
                        Button("Refresh container mapping cache") {
                            CSStoreEngine.shared.invalidate()
                            Alertinator.shared.alert(title: "CSStore2", body: CSStoreEngine.shared.summaryText())
                        }
                    }
                }
                Section("IMPORT & SESSION") {
                    Toggle("Dismiss after importing wallpaper", isOn: $dismissAfterImport)
                    Toggle("Keep Screen Awake", isOn: $keepScreenAwake)
                        .onChange(of: keepScreenAwake) { _, enabled in
                            UIApplication.shared.isIdleTimerDisabled = enabled
                        }
                    LabeledContent("Persist after reboot", value: "Verified MobileGestalt writes")
                    Text("Like mond, the importer can close automatically. Screen Awake prevents idle screen lock while this app is active; it does not guarantee background execution. NOXERRA never hides exploit failures.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("ABOUT") {
                    LabeledContent("App", value: "NOXERRA")
                    LabeledContent("Personalized by", value: "java")
                    LabeledContent("Core", value: "Erosion-CN 1.0.6")
                    LabeledContent("Supervised profiles", value: "Lithium-inspired native builder")
                    Text("Original open-source licensing and author notices are retained in the source distribution.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden)
            .background(NoxAmbientBackground())
            .tint(NoxStyle.accent)
            .navigationTitle("Settings")
            .onAppear { UIApplication.shared.isIdleTimerDisabled = keepScreenAwake }
        }
    }
}
