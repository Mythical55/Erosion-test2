// NOXERRA Tendie Maker
// Native, on-device video -> .tendies pack creator for the PosterBoard importer.
// Package layout is based on the publicly distributed sample .tendies archives.
// On-device PosterBoard compatibility must be verified before relying on a generated pack.

import SwiftUI
import UIKit
import AVFoundation
import PhotosUI
import UniformTypeIdentifiers
import ZIPFoundation

private enum NoxTendieMode: String, CaseIterable, Identifiable {
    case cover = "Cover"
    case fit = "Fit"
    case native = "Native"

    var id: String { rawValue }
    var explanation: String {
        switch self {
        case .cover: return "Fill the screen, cropping edges if necessary"
        case .fit: return "Show the entire video with black letterboxing"
        case .native: return "Keep its proportions, centered without upscaling"
        }
    }
}

struct NoxTendieMakerView: View {
    let onImport: (URL) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var showFilesPicker = false
    @State private var showPhotosPicker = false
    @State private var inputURL: URL?
    @State private var videoName = ""
    @State private var packName = "My NOXERRA Wallpaper"
    @State private var mode: NoxTendieMode = .cover
    @State private var isBuilding = false
    @State private var progress: Double = 0
    @State private var currentStage = "Choose a video to begin"
    @State private var outputURL: URL?
    @State private var preview: UIImage?
    @State private var errorMessage: String?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("NOXERRA TENDIE MAKER", systemImage: "sparkles.tv")
                            .font(.caption.weight(.black))
                            .tracking(1.5)
                            .foregroundStyle(NoxStyle.accent)
                        Text("Turn your video into a wallpaper")
                            .font(.title2.weight(.bold))
                        Text("Create a .tendies package on your iPhone, then import it directly into Custom Wallpapers.")
                            .font(.subheadline)
                            .foregroundStyle(NoxStyle.pale)
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("ONLINE WALLPAPER EDITOR", systemImage: "globe")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(NoxStyle.cyan)
                        Link(destination: URL(string: "https://caplayground.vercel.app")!) {
                            Label("Online .tendies Editor", systemImage: "arrow.up.right.square")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(NoxStyle.accent)
                        Text("Opens the external website in your browser. The on-device maker below still works offline.")
                            .font(.caption)
                            .foregroundStyle(NoxStyle.pale)
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 13) {
                        Label("1 · SELECT VIDEO", systemImage: "film.stack")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(NoxStyle.cyan)
                        HStack(spacing: 12) {
                            Button { showPhotosPicker = true } label: {
                                Label("Photos", systemImage: "photo.on.rectangle")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(NoxStyle.accent)
                            Button { showFilesPicker = true } label: {
                                Label("Files", systemImage: "folder")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                            .tint(NoxStyle.cyan)
                        }
                        .disabled(isBuilding)
                        if let preview {
                            Image(uiImage: preview)
                                .resizable()
                                .scaledToFit()
                                .frame(maxHeight: 240)
                                .frame(maxWidth: .infinity)
                                .clipShape(RoundedRectangle(cornerRadius: 13))
                        }
                        if !videoName.isEmpty {
                            Label(videoName, systemImage: "checkmark.circle.fill")
                                .font(.footnote)
                                .foregroundStyle(.green)
                                .lineLimit(2)
                        }
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Label("2 · WALLPAPER OPTIONS", systemImage: "slider.horizontal.3")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(NoxStyle.cyan)
                        TextField("Wallpaper name", text: $packName)
                            .textFieldStyle(.roundedBorder)
                            .disabled(isBuilding)
                        Picker("Video layout", selection: $mode) {
                            ForEach(NoxTendieMode.allCases) { option in
                                Text(option.rawValue).tag(option)
                            }
                        }
                        .pickerStyle(.segmented)
                        .disabled(isBuilding)
                        Text(mode.explanation)
                            .font(.footnote)
                            .foregroundStyle(NoxStyle.pale)
                        Text("12 fps · up to 400 frames / approximately 33 seconds · no audio")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }

                NoxCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Label("3 · BUILD & EXPORT", systemImage: "shippingbox")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(NoxStyle.cyan)
                        Button(action: build) {
                            Label(isBuilding ? "Creating wallpaper…" : "Create .tendies", systemImage: "wand.and.stars")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(NoxStyle.accent)
                        .disabled(inputURL == nil || isBuilding)

                        if isBuilding {
                            ProgressView(value: progress)
                                .tint(NoxStyle.cyan)
                        }
                        Text(currentStage)
                            .font(.footnote)
                            .foregroundStyle(NoxStyle.pale)
                        if let outputURL {
                            Label("Created: \(outputURL.lastPathComponent)", systemImage: "checkmark.seal.fill")
                                .foregroundStyle(.green)
                                .font(.footnote)
                                .lineLimit(2)
                            HStack(spacing: 12) {
                                Button {
                                    onImport(outputURL)
                                    dismiss()
                                } label: {
                                    Label("Import", systemImage: "square.and.arrow.down")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(NoxStyle.accent)
                                ShareLink(item: outputURL) {
                                    Label("Share / Save", systemImage: "square.and.arrow.up")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.bordered)
                            }
                            .disabled(isBuilding)
                        }
                    }
                }

                Text("Compatibility note: Packages follow the structure of the sample Tendie Maker wallpapers. Generated wallpapers must still be tested on your iOS version and PosterBoard. Your original video is never modified.")
                    .font(.caption)
                    .foregroundStyle(NoxStyle.pale)
                    .padding(.horizontal, 8)
            }
            .padding(16)
        }
        .background(NoxStyle.background)
        .foregroundStyle(.white)
        .navigationTitle("Tendie Maker")
        .navigationBarTitleDisplayMode(.inline)
        .fileImporter(isPresented: $showFilesPicker, allowedContentTypes: [.movie, .video]) { result in
            switch result {
            case .success(let url): receiveFileURL(url)
            case .failure(let error): errorMessage = error.localizedDescription
            }
        }
        .sheet(isPresented: $showPhotosPicker) {
            NoxTendiePhotosPicker { result in
                switch result {
                case .success(let url): receivePreparedFile(url)
                case .failure(let error): errorMessage = error.localizedDescription
                }
            }
        }
        .alert("Tendie Maker", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "Unknown error")
        }
    }

    private func receiveFileURL(_ url: URL) {
        let authorized = url.startAccessingSecurityScopedResource()
        defer { if authorized { url.stopAccessingSecurityScopedResource() } }
        do {
            receivePreparedFile(try NoxTendieBuilder.copyInputVideo(from: url))
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func receivePreparedFile(_ url: URL) {
        inputURL = url
        videoName = url.lastPathComponent
        outputURL = nil
        currentStage = "Ready to build"
        preview = nil
        DispatchQueue.global(qos: .userInitiated).async {
            let asset = AVURLAsset(url: url)
            let generator = AVAssetImageGenerator(asset: asset)
            generator.appliesPreferredTrackTransform = true
            let image = try? generator.copyCGImage(at: .zero, actualTime: nil)
            DispatchQueue.main.async {
                if let image { preview = UIImage(cgImage: image) }
            }
        }
    }

    private func build() {
        guard let url = inputURL, !isBuilding else { return }
        isBuilding = true
        outputURL = nil
        progress = 0
        currentStage = "Preparing frames…"
        let desiredName = packName
        let chosenMode = mode
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let result = try NoxTendieBuilder.build(
                    videoURL: url,
                    packName: desiredName,
                    mode: chosenMode.rawValue
                ) { completed, total in
                    if completed % 6 == 0 || completed == total {
                        DispatchQueue.main.async {
                            progress = Double(completed) / Double(max(1, total))
                            currentStage = "Extracting frames: \(completed) / \(total)"
                        }
                    }
                }
                DispatchQueue.main.async {
                    isBuilding = false
                    progress = 1
                    outputURL = result
                    currentStage = "Ready to import or save!"
                }
            } catch {
                DispatchQueue.main.async {
                    isBuilding = false
                    currentStage = "Build failed"
                    errorMessage = error.localizedDescription
                }
            }
        }
    }
}

private struct NoxTendiePhotosPicker: UIViewControllerRepresentable {
    let completed: (Result<URL, Error>) -> Void

    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration(photoLibrary: .shared())
        configuration.filter = .videos
        configuration.selectionLimit = 1
        configuration.preferredAssetRepresentationMode = .current
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(completed: completed) }

    final class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let completed: (Result<URL, Error>) -> Void
        init(completed: @escaping (Result<URL, Error>) -> Void) { self.completed = completed }

        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            guard let provider = results.first?.itemProvider else { return }
            let identifier = provider.registeredTypeIdentifiers.first {
                UTType($0)?.conforms(to: .movie) == true
            } ?? UTType.movie.identifier
            provider.loadFileRepresentation(forTypeIdentifier: identifier) { url, error in
                do {
                    guard let url else {
                        throw error ?? NSError(domain: "NOXERRA.TendieMaker", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read selected video"])
                    }
                    // Apple's picker temporary URL expires after this completion closure.
                    let copy = try NoxTendieBuilder.copyInputVideo(from: url)
                    DispatchQueue.main.async { self.completed(.success(copy)) }
                } catch {
                    DispatchQueue.main.async { self.completed(.failure(error)) }
                }
            }
        }
    }
}

private enum NoxTendieBuilder {
    static func copyInputVideo(from original: URL) throws -> URL {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("NoxTendieVideos", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let ext = original.pathExtension.isEmpty ? "mov" : original.pathExtension
        let copy = root.appendingPathComponent("\(UUID().uuidString).\(ext)")
        try FileManager.default.copyItem(at: original, to: copy)
        return copy
    }

    static func build(videoURL: URL, packName: String, mode: String, progress: (Int, Int) -> Void) throws -> URL {
        let fileManager = FileManager.default
        let rawName = packName.trimmingCharacters(in: .whitespacesAndNewlines)
        let slug = String((rawName.isEmpty ? "NOXERRA-Wallpaper" : rawName).unicodeScalars.map {
            CharacterSet.alphanumerics.contains($0) ? Character($0) : Character("-")
        }).prefix(38)
        let safeName = slug.isEmpty ? "NOXERRA-Wallpaper" : slug
        let identifier = Int.random(in: 10000...99999)
        let screenClass = "1170w-2532h@3x~iphone"
        let wallpaperDirName = "\(safeName)-\(screenClass).wallpaper"
        let animationDirName = "\(safeName)_Background-\(screenClass).ca"
        let work = fileManager.temporaryDirectory.appendingPathComponent("NOXERRA-Tendie-\(UUID().uuidString)", isDirectory: true)
        defer { try? fileManager.removeItem(at: work) }
        let descriptor = work.appendingPathComponent("descriptors/\(safeName)", isDirectory: true)
        let versions = descriptor.appendingPathComponent("versions/1/contents", isDirectory: true)
        let wallpaper = versions.appendingPathComponent(wallpaperDirName, isDirectory: true)
        let animation = wallpaper.appendingPathComponent(animationDirName, isDirectory: true)
        let assets = animation.appendingPathComponent("assets", isDirectory: true)
        try fileManager.createDirectory(at: assets, withIntermediateDirectories: true)

        let asset = AVURLAsset(url: videoURL)
        let length = asset.duration.seconds
        guard length.isFinite && length > 0.05 else {
            throw NSError(domain: "NOXERRA.TendieMaker", code: 2, userInfo: [NSLocalizedDescriptionKey: "Invalid video duration"])
        }
        let fps = 12
        let availableSeconds = min(length, 400.0 / Double(fps))
        let count = max(1, min(400, Int(ceil(availableSeconds * Double(fps)))))
        let generator = AVAssetImageGenerator(asset: asset)
        generator.appliesPreferredTrackTransform = true
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = CMTime(seconds: 0.05, preferredTimescale: 600)

        let canvas = CGSize(width: 576, height: 1280)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: canvas, format: format)
        for index in 0..<count {
            try autoreleasepool {
                let time = min(Double(index) / Double(fps), max(0, length - 0.02))
                let frame = try generator.copyCGImage(at: CMTime(seconds: time, preferredTimescale: 600), actualTime: nil)
                let image = UIImage(cgImage: frame)
                let jpeg = renderer.jpegData(withCompressionQuality: 0.80) { renderContext in
                    UIColor.black.setFill()
                    renderContext.fill(CGRect(origin: .zero, size: canvas))
                    let originalSize = image.size
                    guard originalSize.width > 0 && originalSize.height > 0 else { return }
                    let scale: CGFloat
                    if mode == "Fit" { scale = min(canvas.width / originalSize.width, canvas.height / originalSize.height) }
                    else if mode == "Native" { scale = min(1, min(canvas.width / originalSize.width, canvas.height / originalSize.height)) }
                    else { scale = max(canvas.width / originalSize.width, canvas.height / originalSize.height) }
                    let targetSize = CGSize(width: originalSize.width * scale, height: originalSize.height * scale)
                    let rect = CGRect(
                        x: (canvas.width - targetSize.width) / 2,
                        y: (canvas.height - targetSize.height) / 2,
                        width: targetSize.width,
                        height: targetSize.height
                    )
                    image.draw(in: rect)
                }
                try jpeg.write(to: assets.appendingPathComponent("\(index).jpg"))
            }
            progress(index + 1, count)
        }

        let role = descriptor.appendingPathComponent("com.apple.posterkit.role.identifier")
        try Data("PRPosterRoleLockScreen".utf8).write(to: role)
        try Data("\(identifier)".utf8).write(to: descriptor.appendingPathComponent("com.apple.posterkit.provider.descriptor.identifier"))
        let providerInfo = try NSKeyedArchiver.archivedData(withRootObject: ["kConfigurationLastUseDateKey": Date()], requiringSecureCoding: false)
        try providerInfo.write(to: descriptor.appendingPathComponent("providerInfo.plist"))

        let userInfo: [String: Any] = [
            "posterEnvironmentOverrides": Data([0x7b, 0x30, 0x3d, 0x7d]),
            "wallpaperRepresentingFileName": wallpaperDirName,
            "wallpaperRepresentingIdentifier": String(identifier)
        ]
        let xmlUserInfo = try PropertyListSerialization.data(fromPropertyList: userInfo, format: .xml, options: 0)
        try xmlUserInfo.write(to: versions.appendingPathComponent("com.apple.posterkit.provider.contents.userInfo"))

        let attributes: [String: Any] = [
            "appearanceAware": true,
            "assets": ["lockAndHome": ["default": [
                "backgroundAnimationFileName": animationDirName,
                "floatingAnimationFileNameKey": animationDirName,
                "identifier": identifier,
                "name": safeName,
                "type": "LayeredAnimation"
            ]]],
            "contentVersion": 2.01,
            "family": safeName,
            "identifier": identifier,
            "logicalScreenClass": screenClass,
            "name": safeName,
            "preferredProminentColor": ["default": "#FFFFFF", "dark": "#000000"],
            "version": 1
        ]
        let plist = try PropertyListSerialization.data(fromPropertyList: attributes, format: .xml, options: 0)
        try plist.write(to: wallpaper.appendingPathComponent("Wallpaper.plist"))
        try Data(indexXML.utf8).write(to: animation.appendingPathComponent("index.xml"))
        try Data(makeCAML(frameCount: count, fps: fps).utf8).write(to: animation.appendingPathComponent("main.caml"))

        let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let outputFolder = documents.appendingPathComponent("NOXERRA Tendies", isDirectory: true)
        try fileManager.createDirectory(at: outputFolder, withIntermediateDirectories: true)
        let out = outputFolder.appendingPathComponent("\(safeName)-\(UUID().uuidString.prefix(6)).tendies")
        try fileManager.zipItem(at: work, to: out, shouldKeepParent: false)
        guard fileManager.fileExists(atPath: out.path) else {
            throw NSError(domain: "NOXERRA.TendieMaker", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not save the generated wallpaper package"])
        }
        return out
    }

    private static let indexXML = """
    <?xml version="1.0" encoding="UTF-8"?>
    <plist version="1.0"><dict>
        <key>assetManifest</key><string>assetManifest.caml</string>
        <key>documentHeight</key><real>1280</real>
        <key>documentResizesToView</key><true/>
        <key>documentWidth</key><real>576</real>
        <key>dynamicGuidesEnabled</key><true/>
        <key>geometryFlipped</key><false/>
        <key>guidesEnabled</key><true/>
        <key>interactiveMouseEventsEnabled</key><true/>
        <key>interactiveShowsCursor</key><true/>
        <key>interactiveTouchEventsEnabled</key><false/>
        <key>loopEnd</key><real>0.0</real>
        <key>loopStart</key><real>0.0</real>
        <key>loopingEnabled</key><false/>
        <key>multitouchDisablesMouse</key><false/>
        <key>multitouchEnabled</key><false/>
        <key>presentationMouseEventsEnabled</key><true/>
        <key>presentationShowsCursor</key><true/>
        <key>presentationTouchEventsEnabled</key><false/>
        <key>rootDocument</key><string>main.caml</string>
        <key>savesWindowFrame</key><false/>
        <key>scalesToFitInPlayer</key><true/>
        <key>showsTouches</key><true/>
        <key>snappingEnabled</key><true/>
        <key>timelineMarkers</key><string>[(null)]</string>
        <key>touchesColor</key><string>1 1 0 0.8</string>
        <key>unitsInPixelsInPlayer</key><true/>
    </dict></plist>
    """

    private static func makeCAML(frameCount: Int, fps: Int) -> String {
        let images = (0..<frameCount).map { "          <CGImage src=\"assets/\($0).jpg\"/>" }.joined(separator: "\n")
        let duration = Double(frameCount) / Double(fps)
        return """
        <?xml version="1.0" encoding="UTF-8"?>
        <caml xmlns="http://www.apple.com/CoreAnimation/1.0">
          <CALayer allowsEdgeAntialiasing="1" allowsGroupOpacity="1" bounds="0 0 576 1280" contentsFormat="RGBA8" cornerCurve="circular" hidden="0" name="_FLOATING" position="288 640">
            <sublayers>
              <CATransformLayer allowsEdgeAntialiasing="1" allowsGroupOpacity="1" allowsHitTesting="1" bounds="0 0 576 1280" contentsFormat="RGBA8" cornerCurve="circular" name="Chip" position="288 640">
                <sublayers>
                  <CALayer allowsEdgeAntialiasing="1" allowsGroupOpacity="1" bounds="0 0 576 1280" contentsFormat="RGBA8" cornerCurve="circular" name="CALayer1" position="288 640">
                    <contents type="CGImage" src="assets/0.jpg"/>
                    <animations>
                      <animation type="CAKeyframeAnimation" calculationMode="discrete" keyPath="contents" beginTime="1e-100" duration="\(duration)" removedOnCompletion="0" repeatCount="inf" repeatDuration="0" speed="1" timeOffset="0" autoreverses="0">
                        <values>
        \(images)
                        </values>
                      </animation>
                    </animations>
                  </CALayer>
                </sublayers>
              </CATransformLayer>
            </sublayers>
            <states>
              <LKState name="Locked"><elements/></LKState>
              <LKState name="Unlock"><elements/></LKState>
              <LKState name="Sleep"><elements/></LKState>
            </states>
            <stateTransitions>
              <LKStateTransition fromState="*" toState="Unlock"><elements/></LKStateTransition>
              <LKStateTransition fromState="Unlock" toState="*"><elements/></LKStateTransition>
              <LKStateTransition fromState="*" toState="Locked"><elements/></LKStateTransition>
              <LKStateTransition fromState="Locked" toState="*"><elements/></LKStateTransition>
              <LKStateTransition fromState="*" toState="Sleep"><elements/></LKStateTransition>
              <LKStateTransition fromState="Sleep" toState="*"><elements/></LKStateTransition>
            </stateTransitions>
          </CALayer>
        </caml>
        """
    }
}
