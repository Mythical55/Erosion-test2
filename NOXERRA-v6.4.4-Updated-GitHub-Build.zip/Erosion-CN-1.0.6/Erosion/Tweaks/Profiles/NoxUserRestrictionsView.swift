// NOXERRA User Restrictions · dynamic editor for the five actual UserSettings.plist sections.
// The bundled reference catalog contains only restriction keys/values from the user-supplied
// sample and has identifying signing-certificate data removed. No default is fabricated.
import SwiftUI
import Foundation
import CoreFoundation

private enum NoxRestrictionSection: String, CaseIterable, Identifiable {
    case restrictedBool, restrictedValue, intersection, union, assignedObject
    var id: String { rawValue }
    var title: String {
        switch self {
        case .restrictedBool: return "Boolean"
        case .restrictedValue: return "Numeric / Value"
        case .intersection: return "Intersection"
        case .union: return "Union"
        case .assignedObject: return "Assigned Object"
        }
    }
    var icon: String {
        switch self {
        case .restrictedBool: return "switch.2"
        case .restrictedValue: return "number"
        case .intersection: return "list.bullet.rectangle"
        case .union: return "square.stack.3d.up"
        case .assignedObject: return "doc.text"
        }
    }
}

private struct NoxRestrictionRecord: Identifiable {
    let section: NoxRestrictionSection
    let key: String
    let fields: [String: Any]
    var id: String { "\(section.rawValue).\(key)" }
}

private struct NoxRestrictionListTarget: Identifiable {
    let section: NoxRestrictionSection
    let key: String
    let values: [String]
    var id: String { "\(section.rawValue).\(key)" }
}

struct NoxUserRestrictionsView: View {
    @State private var document: [String: Any] = [:]
    @State private var original: Data?
    @State private var sourceIsLive = false
    @State private var sourceInfo = "Not loaded"
    @State private var format: PropertyListSerialization.PropertyListFormat = .xml
    @State private var section: NoxRestrictionSection = .restrictedBool
    @State private var search = ""
    @State private var changedKeys: Set<String> = []
    @State private var numericInputs: [String: String] = [:]
    @State private var listTarget: NoxRestrictionListTarget?
    @State private var message: String?
    @State private var lastBackup: URL?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var loaded = false
    @State private var showChangedOnly = false

    private var entries: [NoxRestrictionRecord] {
        let dict = document[section.rawValue] as? [String: Any] ?? [:]
        return dict.keys.sorted { $0.localizedStandardCompare($1) == .orderedAscending }.compactMap { key in
            guard let fields = dict[key] as? [String: Any] else { return nil }
            return NoxRestrictionRecord(section: section, key: key, fields: fields)
        }
    }
    private var visible: [NoxRestrictionRecord] {
        entries.filter { record in
            (!showChangedOnly || changedKeys.contains(record.id)) &&
            (search.isEmpty || record.key.localizedCaseInsensitiveContains(search))
        }
    }
    private var totalCount: Int {
        NoxRestrictionSection.allCases.reduce(0) { total, section in
            total + ((document[section.rawValue] as? [String: Any])?.count ?? 0)
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 13) {
                header
                if loaded {
                    summary
                    selection
                    if changedKeys.count > 0 {
                        NoxCard {
                            HStack(spacing: 10) {
                                Image(systemName: "pencil.and.list.clipboard")
                                    .foregroundStyle(.orange)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("\(changedKeys.count) unsaved change(s)")
                                        .font(.subheadline.weight(.bold))
                                    Text("Review below, then use Apply staged changes to write the verified plist.")
                                        .font(.caption2).foregroundStyle(NoxStyle.pale)
                                }
                                Spacer(minLength: 0)
                            }
                        }
                    }
                    if !visible.isEmpty {
                        ForEach(visible) { record in restrictionCard(record) }
                    } else {
                        NoxCard {
                            Text("No entries match this section or filter.")
                                .foregroundStyle(NoxStyle.pale)
                        }
                    }
                    actions
                } else {
                    NoxCard {
                        HStack(spacing: 9) {
                            ProgressView()
                            Text("Loading restrictions…").foregroundStyle(NoxStyle.pale)
                        }
                    }
                }
                if let message {
                    NoxCard { Text(message).font(.footnote).foregroundStyle(.orange).textSelection(.enabled) }
                }
            }
            .padding(16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("User Restrictions")
        .navigationBarTitleDisplayMode(.inline)
        .tint(NoxStyle.accent)
        .searchable(text: $search, prompt: "Search restriction keys")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Reload", systemImage: "arrow.clockwise") { reload() }
            }
        }
        .sheet(item: $listTarget) { target in
            NoxRestrictionListEditor(target: target) { values in
                setField(target.section, key: target.key, name: "values", value: values)
                listTarget = nil
            }
        }
        .confirmationDialog("Apply edited restrictions to UserSettings.plist?", isPresented: $showApplyConfirmation, titleVisibility: .visible) {
            Button("Back up and write changes") { apply() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This is an internal iOS configuration file. Changes may be overridden by the profile daemon or may affect device behavior. Never use this to circumvent an organization-managed device. Export your backup.")
        }
        .confirmationDialog("Restore last original backup?", isPresented: $showRestoreConfirmation) {
            Button("Restore with new backup", role: .destructive) { restoreLast() }
            Button("Cancel", role: .cancel) {}
        } message: { Text("The current UserSettings.plist will be backed up before restoration.") }
        .onAppear { if !loaded { reload() } }
    }

    private var header: some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("USER RESTRICTIONS", systemImage: "checkmark.shield.fill")
                    .font(.title3.weight(.black)).foregroundStyle(NoxStyle.cyan)
                Text("Browse every key in UserSettings.plist. Boolean settings use toggles, numeric settings keep their documented ranges, and list-based restrictions have a list editor.")
                    .font(.footnote).foregroundStyle(NoxStyle.pale)
                Text(NoxProfileStoreIO.userSettings.path)
                    .font(.caption2.monospaced()).foregroundStyle(NoxStyle.pale)
                    .textSelection(.enabled)
                Label(sourceInfo, systemImage: sourceIsLive ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(sourceIsLive ? .green : .orange)
                Text("An on-disk change is not the same as an effective iOS policy change. Device management services may recalculate these values.")
                    .font(.caption2).foregroundStyle(.orange)
            }
        }
    }

    private var summary: some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text("\(totalCount) entries").font(.headline).foregroundStyle(NoxStyle.cyan)
                    Spacer()
                    Text("\(changedKeys.count) staged").font(.caption).foregroundStyle(NoxStyle.pale)
                }
                ForEach(NoxRestrictionSection.allCases) { section in
                    HStack {
                        Image(systemName: section.icon).foregroundStyle(NoxStyle.accent)
                            .frame(width: 22)
                        Text(section.rawValue).font(.caption.monospaced())
                        Spacer()
                        Text("\((document[section.rawValue] as? [String: Any])?.count ?? 0)")
                            .font(.caption.monospacedDigit()).foregroundStyle(NoxStyle.pale)
                    }
                }
            }
        }
    }

    private var selection: some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 11) {
                Text("RESTRICTION CATEGORIES")
                    .font(.caption.weight(.heavy))
                    .tracking(1.1)
                    .foregroundStyle(NoxStyle.accent)
                ForEach(NoxRestrictionSection.allCases) { type in
                    Button {
                        section = type
                        showChangedOnly = false
                    } label: {
                        HStack(spacing: 11) {
                            Image(systemName: type.icon)
                                .foregroundStyle(section == type ? NoxStyle.cyan : NoxStyle.accent)
                                .frame(width: 24)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(type.title)
                                    .font(.subheadline.weight(section == type ? .bold : .medium))
                                Text(type.rawValue)
                                    .font(.caption2.monospaced())
                                    .foregroundStyle(NoxStyle.pale)
                            }
                            Spacer()
                            Text("\((document[type.rawValue] as? [String: Any])?.count ?? 0)")
                                .font(.caption.monospacedDigit().weight(.semibold))
                                .foregroundStyle(NoxStyle.pale)
                            Image(systemName: section == type ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(NoxStyle.accent)
                        }
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                }
                Divider().overlay(NoxStyle.accent.opacity(0.24))
                Toggle("Show changed only", isOn: $showChangedOnly)
                    .tint(NoxStyle.accent)
                Text("\(visible.count) shown · \(entries.count) in \(section.rawValue)")
                    .font(.caption2).foregroundStyle(NoxStyle.pale)
                if !sourceIsLive {
                    Label("Reference-only mode · editing is not applied to iOS", systemImage: "exclamationmark.triangle.fill")
                        .font(.caption2).foregroundStyle(.orange)
                }
            }
        }
    }

    private func restrictionCard(_ record: NoxRestrictionRecord) -> some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: changedKeys.contains(record.id) ? "pencil.circle.fill" : "slider.horizontal.3")
                        .foregroundStyle(changedKeys.contains(record.id) ? .orange : NoxStyle.cyan)
                    Text(record.key)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                        .textSelection(.enabled)
                    Spacer(minLength: 0)
                }
                restrictionValue(record)
                if changedKeys.contains(record.id) {
                    Label("Staged change", systemImage: "checkmark.circle.fill")
                        .font(.caption2.weight(.semibold)).foregroundStyle(.orange)
                }
                if !record.fields.isEmpty {
                    DisclosureGroup("All stored fields") {
                        VStack(alignment: .leading, spacing: 5) {
                            ForEach(currentFields(record).keys.sorted(), id: \.self) { key in
                                HStack(alignment: .top) {
                                    Text(key).font(.caption.monospaced())
                                    Spacer(minLength: 10)
                                    Text(showValue(currentFields(record)[key]))
                                        .font(.caption.monospaced()).foregroundStyle(NoxStyle.pale)
                                        .multilineTextAlignment(.trailing)
                                        .textSelection(.enabled)
                                }
                            }
                        }
                    }
                    .font(.caption).tint(NoxStyle.cyan)
                } else {
                    Text("Empty dictionary · no explicit stored value")
                        .font(.caption2).foregroundStyle(NoxStyle.pale)
                }
            }
        }
    }

    @ViewBuilder
    private func restrictionValue(_ record: NoxRestrictionRecord) -> some View {
        switch record.section {
        case .restrictedBool:
            Toggle("Value: \(booleanValue(record) == nil ? "Unset" : (booleanValue(record)! ? "True" : "False"))", isOn: Binding(
                get: { booleanValue(record) ?? false },
                set: { setField(record.section, key: record.key, name: "value", value: $0) }
            ))
            .tint(NoxStyle.accent)
            if record.fields["ask"] is Bool || record.fields["ask"] is NSNumber {
                Toggle("Ask", isOn: Binding(
                    get: { (currentFields(record)["ask"] as? NSNumber)?.boolValue ?? false },
                    set: { setField(record.section, key: record.key, name: "ask", value: $0) }
                ))
                .tint(NoxStyle.accent).font(.caption)
            }
        case .restrictedValue:
            HStack(spacing: 10) {
                TextField("Numeric value", text: Binding(
                    get: { numericInputs[record.id] ?? showValue(currentFields(record)["value"]) },
                    set: { numericInputs[record.id] = $0 }
                ))
                .keyboardType(.decimalPad)
                .font(.system(.body, design: .monospaced))
                .textFieldStyle(.roundedBorder)
                .foregroundStyle(.primary)
                Button("Set") { stageNumber(record) }
                    .buttonStyle(.bordered).tint(NoxStyle.accent)
            }
            if let min = (record.fields["rangeMinimum"] as? NSNumber)?.doubleValue {
                Text("Minimum: \(min.formatted())")
                    .font(.caption2).foregroundStyle(NoxStyle.pale)
            }
            if let max = (record.fields["rangeMaximum"] as? NSNumber)?.doubleValue {
                Text("Maximum: \(max.formatted())")
                    .font(.caption2).foregroundStyle(NoxStyle.pale)
            }
        case .intersection, .union, .assignedObject:
            let values = (currentFields(record)["values"] as? [String]) ?? []
            HStack {
                Text("\(values.count) stored values")
                    .font(.caption).foregroundStyle(NoxStyle.pale)
                Spacer()
                Button("Edit list") {
                    listTarget = NoxRestrictionListTarget(section: record.section, key: record.key, values: values)
                }
                .buttonStyle(.bordered).tint(NoxStyle.accent)
            }
            if !values.isEmpty {
                ForEach(Array(values.prefix(3)), id: \.self) { value in
                    Text(value).font(.caption2.monospaced()).foregroundStyle(NoxStyle.pale)
                        .textSelection(.enabled)
                }
            }
        }
    }

    private var actions: some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 10) {
                Label("REVIEW & APPLY", systemImage: "externaldrive.badge.checkmark")
                    .font(.subheadline.weight(.heavy)).foregroundStyle(NoxStyle.cyan)
                Text("\(changedKeys.count) keys staged. The original is backed up before writes. Backups are local to NOXERRA until exported.")
                    .font(.footnote).foregroundStyle(NoxStyle.pale)
                Button("Apply staged changes") { showApplyConfirmation = true }
                    .buttonStyle(.borderedProminent).tint(NoxStyle.violet)
                    .disabled(!sourceIsLive || changedKeys.isEmpty)
                Button("Discard staged changes") { reload() }
                    .buttonStyle(.bordered).disabled(changedKeys.isEmpty)
                if let lastBackup {
                    ShareLink(item: lastBackup) { Label("Export last backup", systemImage: "square.and.arrow.up") }
                        .buttonStyle(.bordered)
                    Button("Restore last backup") { showRestoreConfirmation = true }
                        .buttonStyle(.bordered).tint(.orange)
                }
                if !sourceIsLive {
                    Text("Reference mode: edits are preview-only because the live system file could not be read. Apply is disabled.")
                        .font(.caption).foregroundStyle(.orange)
                }
            }
        }
    }

    private func currentFields(_ record: NoxRestrictionRecord) -> [String: Any] {
        let members = document[record.section.rawValue] as? [String: Any]
        return members?[record.key] as? [String: Any] ?? record.fields
    }
    private func booleanValue(_ record: NoxRestrictionRecord) -> Bool? {
        (currentFields(record)["value"] as? NSNumber)?.boolValue
    }
    private func showValue(_ raw: Any?) -> String {
        guard let raw else { return "(unset)" }
        if let array = raw as? [Any] { return "[\(array.count) values]" }
        if let bool = raw as? NSNumber, CFGetTypeID(bool) == CFBooleanGetTypeID() { return bool.boolValue ? "true" : "false" }
        return String(describing: raw)
    }
    private func setField(_ section: NoxRestrictionSection, key: String, name: String, value: Any) {
        var target = document
        var group = target[section.rawValue] as? [String: Any] ?? [:]
        var fields = group[key] as? [String: Any] ?? [:]
        fields[name] = value
        group[key] = fields
        target[section.rawValue] = group
        document = target
        changedKeys.insert("\(section.rawValue).\(key)")
    }
    private func stageNumber(_ record: NoxRestrictionRecord) {
        let raw = (numericInputs[record.id] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        guard let number = Double(raw.replacingOccurrences(of: ",", with: ".")), number.isFinite else {
            message = "Invalid number for \(record.key)."
            return
        }
        if let min = (record.fields["rangeMinimum"] as? NSNumber)?.doubleValue, number < min {
            message = "\(record.key) must be at least \(min)."; return
        }
        if let max = (record.fields["rangeMaximum"] as? NSNumber)?.doubleValue, number > max {
            message = "\(record.key) must not exceed \(max)."; return
        }
        let original = currentFields(record)["value"] as? NSNumber
        let type = original.map { String(cString: $0.objCType) } ?? "d"
        if ["d", "f"].contains(type) {
            setField(record.section, key: record.key, name: "value", value: number)
        } else {
            guard number.rounded() == number, number >= Double(Int64.min), number < Double(Int64.max) else {
                message = "\(record.key) requires an integer."; return
            }
            setField(record.section, key: record.key, name: "value", value: Int64(number))
        }
        numericInputs[record.id] = raw
        message = "Staged value for \(record.key). Tap Apply staged changes when ready."
    }

    private func reload() {
        do {
            let data = try NoxProfileStoreIO.read(NoxProfileStoreIO.userSettings)
            try loadDocument(data, live: true, info: "Live UserSettings.plist loaded from device")
        } catch {
            let liveError = error.localizedDescription
            guard let sample = Bundle.main.url(forResource: "NoxUserSettingsReference", withExtension: "plist"),
                  let data = try? Data(contentsOf: sample) else {
                loaded = false
                message = "Cannot read live UserSettings.plist: \(liveError). The bundled reference catalog is also unavailable."
                return
            }
            do {
                try loadDocument(data, live: false, info: "Reference catalog only — NOT live device restrictions")
                message = "Live file unavailable: \(liveError). Showing the sanitized reference key catalog."
            } catch { message = error.localizedDescription }
        }
    }

    private func loadDocument(_ data: Data, live: Bool, info: String) throws {
        var parsedFormat: PropertyListSerialization.PropertyListFormat = .xml
        guard let root = try PropertyListSerialization.propertyList(from: data, options: [], format: &parsedFormat) as? [String: Any] else {
            throw NSError(domain: "NOXERRA.Restrictions", code: 1, userInfo: [NSLocalizedDescriptionKey: "UserSettings.plist is not a dictionary"])
        }
        document = root
        original = data
        sourceIsLive = live
        sourceInfo = info
        format = parsedFormat
        changedKeys = []
        numericInputs = [:]
        loaded = true
        message = nil
    }

    private func apply() {
        guard sourceIsLive, let original, !changedKeys.isEmpty else { return }
        do {
            // Preserve all unrelated keys and original XML/binary plist format.
            let data = try PropertyListSerialization.data(fromPropertyList: document, format: format, options: 0)
            lastBackup = try NoxProfileStoreIO.write(data, to: NoxProfileStoreIO.userSettings, expectedOriginal: original)
            try loadDocument(data, live: true, info: "Live UserSettings.plist · saved and re-read")
            message = "Saved \(data.count) bytes and verified the file. The iOS profile daemon may reassert restrictions independently of this file. Export your backup."
        } catch { message = "Save failed: \(error.localizedDescription)" }
    }

    private func restoreLast() {
        guard let lastBackup, let original else { return }
        do {
            let data = try Data(contentsOf: lastBackup)
            _ = try NoxProfileStoreIO.write(data, to: NoxProfileStoreIO.userSettings, expectedOriginal: original)
            try loadDocument(data, live: true, info: "Live UserSettings.plist · backup restored")
            message = "Backup restored and file verified."
        } catch { message = "Restore failed: \(error.localizedDescription)" }
    }
}

private struct NoxRestrictionListEditor: View {
    @Environment(\.dismiss) private var dismiss
    let target: NoxRestrictionListTarget
    let onSave: ([String]) -> Void
    @State private var listText = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Restriction key") { Text(target.key).font(.footnote.monospaced()).textSelection(.enabled) }
                Section("Values · one per line") {
                    TextEditor(text: $listText)
                        .frame(minHeight: 240)
                        .font(.system(.body, design: .monospaced))
                        .autocorrectionDisabled()
                }
                Section {
                    Text("Editing stages a change; it does not affect the system until Apply staged changes is confirmed.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Edit Restriction List")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Stage") {
                        let values = listText.split(separator: "\n", omittingEmptySubsequences: true)
                            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                            .filter { !$0.isEmpty }
                        onSave(values)
                        dismiss()
                    }
                }
            }
        }
        .onAppear { listText = target.values.joined(separator: "\n") }
    }
}
