import SwiftUI
import UIKit

struct NoxLogView: View {
    @EnvironmentObject private var mgr: ErosionManager
    @State private var autoScroll = true
    @State private var showClear = false
    @State private var filter = ""
    @State private var exportError: String?

    private var visibleLog: String {
        guard !filter.isEmpty else { return mgr.logOutput.isEmpty ? "NOXERRA logs ready." : mgr.logOutput }
        let matches = mgr.logOutput.split(separator: "\n", omittingEmptySubsequences: false)
            .filter { $0.localizedCaseInsensitiveContains(filter) }
        return matches.isEmpty ? "No matching log entries." : matches.joined(separator: "\n")
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 15) {
                HStack {
                    Label("Live output", systemImage: "circle.fill")
                        .font(.caption.weight(.bold)).foregroundStyle(.green)
                    Spacer()
                    Text("\(mgr.logOutput.isEmpty ? 0 : mgr.logOutput.filter { $0 == "\n" }.count + 1) lines")
                        .font(.caption.monospaced()).foregroundStyle(.secondary)
                }
                TextField("Filter console output", text: $filter)
                    .textFieldStyle(.roundedBorder)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .accessibilityLabel("Filter log lines")
                ScrollViewReader { reader in
                    ScrollView {
                        Text(visibleLog)
                            .font(.system(size: 12, design: .monospaced))
                            .foregroundStyle(Color(red: 0.43, green: 0.91, blue: 0.67))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(15)
                        Color.clear.frame(height: 1).id("bottom")
                    }
                    .background(Color(red: 0.025, green: 0.025, blue: 0.045), in: RoundedRectangle(cornerRadius: 18))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.green.opacity(0.24)))
                    .onChange(of: mgr.logOutput) { _, _ in
                        if autoScroll { reader.scrollTo("bottom", anchor: .bottom) }
                    }
                }
                HStack(spacing: 10) {
                    Button("Copy", systemImage: "doc.on.doc") {
                        NoxSound.shared.playTap()
                        UIPasteboard.general.string = mgr.logOutput
                    }
                    Button("Export", systemImage: "square.and.arrow.up") {
                        NoxSound.shared.playTap()
                        let url = FileManager.default.temporaryDirectory.appendingPathComponent("NOXERRA-log.txt")
                        do {
                            try mgr.logOutput.write(to: url, atomically: true, encoding: .utf8)
                            presentShareSheet(with: url)
                        } catch { exportError = error.localizedDescription }
                    }
                    Button("Clear", systemImage: "trash") { showClear = true }
                }
                .buttonStyle(.bordered)
                .tint(NoxStyle.accent)
                Toggle("Auto-scroll", isOn: $autoScroll)
                    .tint(NoxStyle.accent)
                    .font(.subheadline)
            }
            .padding(18)
            .background(NoxAmbientBackground())
            .navigationTitle("Log")
            .alert("Export failed", isPresented: Binding(get: { exportError != nil }, set: { if !$0 { exportError = nil } })) {
                Button("OK") { exportError = nil }
            } message: { Text(exportError ?? "Unknown error") }
            .alert("Clear log output?", isPresented: $showClear) {
                Button("Cancel", role: .cancel) {}
                Button("Clear", role: .destructive) { mgr.logOutput = "" }
            }
        }
    }
}
