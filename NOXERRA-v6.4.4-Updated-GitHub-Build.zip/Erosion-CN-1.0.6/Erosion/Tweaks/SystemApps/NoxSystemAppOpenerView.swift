// NOXERRA System App Opener — based on the open-source Bridge 1.2 catalog.
// Uses Erosion's existing LSApplicationWorkspace bridge for the direct method.
// iOS may refuse to launch internal apps even when they appear in the catalog.
import SwiftUI
import UIKit

struct NoxSystemAppOpenerView: View {
    @State private var search = ""
    @State private var selectedFilter = "All"
    @AppStorage("noxSystemAppFavorites") private var storedFavorites = ""
    @AppStorage("noxSystemOpenerShortcuts") private var preferShortcuts = false

    private var favorites: Set<String> {
        Set(storedFavorites.split(separator: "\n").map(String.init))
    }

    private var results: [NoxSystemAppEntry] {
        NoxSystemAppCatalog.entries.filter { entry in
            let matchesSection: Bool
            switch selectedFilter {
            case "Applications": matchesSection = entry.partition == "Applications"
            case "CoreServices": matchesSection = entry.partition == "CoreServices"
            case "Favorites": matchesSection = favorites.contains(entry.id)
            default: matchesSection = true
            }
            return matchesSection && (search.isEmpty ||
                entry.name.localizedCaseInsensitiveContains(search) ||
                entry.defaultBundleID.localizedCaseInsensitiveContains(search))
        }
    }

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 10) {
                    Label("INTERNAL APP LAUNCHER", systemImage: "square.grid.3x3.fill")
                        .font(.caption.weight(.heavy))
                        .tracking(1.2)
                        .foregroundStyle(NoxStyle.accent)
                    Text("System App Opener")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.white)
                    Text("Launch hidden & internal iOS apps. Search the catalog, save favorites, or open a known bundle ID.")
                        .font(.subheadline)
                        .foregroundStyle(NoxStyle.pale)
                    Text("Not every entry is installed or launchable. iOS may block private apps; a failed launch will not alter the system.")
                        .font(.caption)
                        .foregroundStyle(.orange)
                }
                .padding(.vertical, 7)
            }
            .listRowBackground(NoxStyle.surface)

            Section("OPENING METHOD") {
                Toggle("Prefer Bridge helper Shortcut", isOn: $preferShortcuts)
                    .tint(NoxStyle.accent)
                Text("Direct launch uses iOS's private application workspace. The alternative requires installing Bridge's helper Shortcut first.")
                    .font(.caption)
                    .foregroundStyle(NoxStyle.pale)
                Link(destination: URL(string: "https://jailbreak.party/bridge-helper")!) {
                    Label("Install Bridge Helper Shortcut", systemImage: "arrow.down.app")
                        .foregroundStyle(NoxStyle.accent)
                }
                NavigationLink {
                    NoxSystemAppDetailView(entry: NoxSystemAppEntry(name: "Custom Application", partition: "Custom"), preferShortcuts: false)
                } label: {
                    Label("Open by Custom Bundle ID", systemImage: "plus.app")
                        .foregroundStyle(.white)
                }
            }
            .listRowBackground(NoxStyle.surface)

            Section("APP CATALOG") {
                Picker("Category", selection: $selectedFilter) {
                    Text("All").tag("All")
                    Text("Apps").tag("Applications")
                    Text("Core").tag("CoreServices")
                    Text("Stars").tag("Favorites")
                }
                .pickerStyle(.segmented)
                .listRowBackground(NoxStyle.surface)
                Text("\(results.count) entries · iOS 26 reference list")
                    .font(.caption)
                    .foregroundStyle(NoxStyle.pale)
                    .listRowBackground(NoxStyle.surface)

                ForEach(results) { entry in
                    HStack(spacing: 12) {
                        NavigationLink {
                            NoxSystemAppDetailView(entry: entry, preferShortcuts: preferShortcuts)
                        } label: {
                            HStack(spacing: 11) {
                                Image(systemName: entry.partition == "CoreServices" ? "cpu.fill" : "app.fill")
                                    .font(.title3)
                                    .foregroundStyle(NoxStyle.accent)
                                    .frame(width: 38, height: 38)
                                    .background(NoxStyle.accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(entry.name)
                                        .font(.subheadline.weight(.semibold))
                                        .foregroundStyle(.white)
                                    Text(entry.partition == "CoreServices" ? "System CoreServices" : "Internal Application")
                                        .font(.caption2)
                                        .foregroundStyle(NoxStyle.pale)
                                }
                            }
                        }
                        Button {
                            toggleFavorite(entry.id)
                            NoxSound.shared.playTap()
                        } label: {
                            Image(systemName: favorites.contains(entry.id) ? "star.fill" : "star")
                                .foregroundStyle(NoxStyle.accent)
                                .frame(width: 33, height: 44)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(favorites.contains(entry.id) ? "Remove favorite" : "Add favorite")
                    }
                    .listRowBackground(NoxStyle.surface)
                }
            }
        }
        .searchable(text: $search, prompt: "Search system applications")
        .scrollContentBackground(.hidden)
        .background(NoxStyle.background)
        .tint(NoxStyle.accent)
        .navigationTitle("System App Opener")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func toggleFavorite(_ id: String) {
        var all = favorites
        if !all.insert(id).inserted { all.remove(id) }
        storedFavorites = all.sorted().joined(separator: "\n")
    }
}

private struct NoxSystemAppDetailView: View {
    let entry: NoxSystemAppEntry
    let preferShortcuts: Bool
    @Environment(\.openURL) private var openURL
    @State private var bundleID: String
    @State private var showAlert = false
    @State private var alertText = ""

    init(entry: NoxSystemAppEntry, preferShortcuts: Bool) {
        self.entry = entry
        self.preferShortcuts = preferShortcuts
        _bundleID = State(initialValue: entry.partition == "Custom" ? "" : entry.defaultBundleID)
    }

    var body: some View {
        List {
            Section("APPLICATION") {
                LabeledContent("Name", value: entry.name)
                if entry.partition != "Custom" {
                    LabeledContent("Location", value: entry.partition)
                }
                TextField("Bundle identifier", text: $bundleID)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .font(.system(.body, design: .monospaced))
            }
            .listRowBackground(NoxStyle.surface)
            Section("LAUNCH") {
                Button {
                    NoxSound.shared.playTap()
                    if preferShortcuts && entry.partition != "Custom" {
                        openViaShortcuts()
                    } else {
                        openDirectly()
                    }
                } label: {
                    Label(preferShortcuts && entry.partition != "Custom" ? "Open with Bridge Shortcut" : "Open System App", systemImage: "arrow.up.forward.app.fill")
                        .foregroundStyle(NoxStyle.accent)
                }
                .disabled(bundleID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                if entry.partition != "Custom" {
                    Button {
                        openViaShortcuts()
                    } label: {
                        Label("Try Bridge Shortcut", systemImage: "square.stack.3d.up")
                    }
                }
                Button {
                    UIPasteboard.general.string = bundleID
                    alertText = "Bundle identifier copied."
                    showAlert = true
                } label: {
                    Label("Copy Bundle ID", systemImage: "doc.on.doc")
                }
            }
            .listRowBackground(NoxStyle.surface)
            Section("COMPATIBILITY") {
                Text("The application name is from Bridge's static list. Some apps have different bundle identifiers or cannot be opened on your iOS version. You can correct the ID above or use the helper Shortcut.")
                    .font(.footnote)
                    .foregroundStyle(NoxStyle.pale)
            }
            .listRowBackground(NoxStyle.surface)
        }
        .scrollContentBackground(.hidden)
        .background(NoxStyle.background)
        .tint(NoxStyle.accent)
        .navigationTitle(entry.name)
        .navigationBarTitleDisplayMode(.inline)
        .alert("System App Opener", isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertText)
        }
    }

    private func openDirectly() {
        let id = bundleID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !id.isEmpty else { return }
        let result = LSApplicationWorkspace.default().openApplication(withBundleID: id)
        alertText = result
            ? "iOS accepted the launch request for \(id). The app may not present a visible screen."
            : "iOS rejected the launch for \(id). Check the bundle ID or try the Bridge Shortcut."
        showAlert = true
    }

    private func openViaShortcuts() {
        var components = URLComponents()
        components.scheme = "shortcuts"
        components.host = "run-shortcut"
        components.queryItems = [
            URLQueryItem(name: "name", value: "Bridge"),
            URLQueryItem(name: "input", value: "Open*\(entry.bridgeToken)")
        ]
        guard let url = components.url else { return }
        openURL(url) { accepted in
            if !accepted {
                alertText = "The Bridge helper Shortcut was not opened. Install it using the link in the System App Opener page."
                showAlert = true
            }
        }
    }
}
