# NOXERRA — System App Opener (Bridge-inspired)

New entry in **Tweaks → System Tools → System App Opener**.

- Searchable catalog of iOS internal applications, from Bridge 1.2's iOS 26 static list.
- Switch between `/Applications`, `/System/Library/CoreServices`, Favorites, and all results.
- Direct open uses the private `LSApplicationWorkspace` API already declared in Erosion's bridging header.
- Optional Shortcuts launch uses the official Bridge Helper shortcut (`https://jailbreak.party/bridge-helper`). Users must install this Shortcut separately.
- Custom bundle identifier entry and copy-to-clipboard.
- No extra SwiftPM packages or changes to `ipabuild.sh` required.

## Caveats

This reference catalog **does not scan** the current device. Many entries may be absent or unavailable on newer iOS versions. Some static names do not map to their actual bundle identifiers; the detail page allows manual correction. iOS may reject launches or not display a visible interface. Exports of app bundles are not included. No `worse_query` capability is used by the opener.

## Credit and license

Based on the app names and opening workflows described in **Bridge 1.2**, published by jailbreakdotparty (`https://github.com/jailbreakdotparty/Bridge`), licensed under GPL-3.0. The static iOS 26 catalog was adapted; see `BRIDGE_GPL_3_0_LICENSE.txt` and the existing NOXERRA GPL license. This modified distribution should preserve appropriate GPL notices and corresponding source availability.

## Test checklist (iPhone)

1. Launch NOXERRA and open Tweaks → System App Opener.
2. Filter Apps/Core/Favorites and search for an entry.
3. Open a known internal app by default ID and, if needed, correct it manually.
4. Optionally install Bridge Helper and test Shortcut fallback.
5. Test custom bundle identifier and copy action.
6. Verify original MobileGestalt and File browser still open normally.
