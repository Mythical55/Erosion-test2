# NOXERRA Supervised Tweaks — Lithium 1.0 compatibility review

Baseline: source ZIP `Lithium-0.2(1).zip` supplied by user, 23 toggles + OTA delay + app visibility.
Reference: `Lithium.1.0.shortcut` supplied by user is a signed AEA1 Shortcuts archive. Its cryptographic envelope was inspected but the Shortcuts action graph could not be extracted in this Linux environment. Therefore **no exact one-to-one claim about its internals** is made.
Comparison source: public [Lithium-Shortcut 1.0 README](https://github.com/lunginspector/Lithium-Shortcut) and [Apple Restrictions reference](https://github.com/apple/device-management/blob/release/mdm/profiles/com.apple.applicationaccess.yaml).

Added Apple profile restrictions: App Clips, wallpaper changes, automatic app downloads, Classroom remote observation, explicit iTunes content, explicit Bookstore content, nearby password requests, password sharing, USB Restricted Mode, account changes, Erase All Content & Settings, manual profile installation, passcode modification, device name modification.

New profile pages: custom TTF/OTF font profile (`com.apple.font`); a custom locked Home Screen layout (`com.apple.homescreenlayout`); read-only import and inspection of `.mobileconfig` files.

**Limitations**: Some public Lithium 1.0 README labels — notably 'Multitasking', 'Photo location metadata', and broad global 'Apple Intelligence' — are not mapped to unverified restriction keys. Instead we keep existing individual Apple Intelligence controls. The uploaded signed `.shortcut` actions were not directly decoded. Mobileconfig installs are manual and supervision/iOS version/MDM restrictions may differ. The locked Home Screen layout can reorder icons permanently. The `allowUSBRestrictedMode=false` setting weakens USB lockout protection.
