import SwiftUI
import Foundation
import UniformTypeIdentifiers

/// Builds standard configuration profiles without running a sandbox exploit.
struct NoxSupervisedTweaksView: View {
    enum ProfileKind: String, CaseIterable, Identifiable {
        case footnote = "Lock Screen Footnote"
        case webClip = "Home Screen Web Clip"
        case restrictions = "System Restrictions"
        case notifications = "App Notifications"
        case font = "Font Installer"
        case homeLayout = "Locked Home Screen Layout"
        case importProfile = "Profile Inspector"
        var id: String { rawValue }
        var symbol: String {
            switch self {
            case .footnote: "text.bubble"
            case .webClip: "app.badge"
            case .restrictions: "checkmark.shield"
            case .notifications: "bell.badge"
            case .font: "textformat"
            case .homeLayout: "square.grid.3x3"
            case .importProfile: "doc.text.magnifyingglass"
            }
        }
        var detail: String {
            switch self {
            case .footnote: "Add identification text to supported supervised Lock Screens."
            case .webClip: "Add a website shortcut to your Home Screen."
            case .restrictions: "Control system features with iOS configuration profiles."
            case .notifications: "Set notification permissions for an app bundle identifier."
            case .font: "Package a TrueType or OpenType font in a .mobileconfig profile."
            case .homeLayout: "Define a locked, supervised Home Screen arrangement."
            case .importProfile: "Import and inspect a profile before installing it yourself."
            }
        }
    }

    @State private var kind: ProfileKind = .footnote
    @State private var leadingText = ""
    @State private var trailingText = ""
    @State private var webTitle = "My Shortcut"
    @State private var webURL = "https://"
    @State private var fullScreen = false
    // All Lithium 0.2 restriction categories, plus OTA and app visibility.
    // A selected switch writes explicit "allow... = false" keys into the profile.
    @State private var disabledRestrictionIDs: Set<String> = []
    @State private var delayOTAUpdates = false
    @State private var otaDelayDays = 30
    @State private var visibilityApps: [NoxVisibilityApp] = []
    @State private var newAppName = ""
    @State private var newAppBundleID = ""
    @State private var appVisibilityMessage = ""
    @State private var bundleID = ""
    @State private var notificationsEnabled = false
    @State private var exportedURL: URL?
    @State private var status = ""
    @State private var layoutPageIDs = ""
    @State private var layoutDockIDs = ""
    @State private var fontFileName = ""
    @State private var fontFileData: Data?
    @State private var showFontPicker = false
    @State private var showProfilePicker = false
    @State private var importedProfileURL: URL?
    @State private var importedProfileSummary = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                NoxCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Label("NO EXPLOIT REQUIRED", systemImage: "checkmark.shield")
                            .font(.caption.weight(.heavy)).foregroundStyle(NoxStyle.cyan)
                        Text("Supervised Tweaks").font(.title2.bold())
                        Text("Generate Apple configuration profiles directly in NOXERRA. Many restrictions require a personally supervised iPhone or iPad. iOS decides which settings apply.")
                            .font(.caption).foregroundStyle(NoxStyle.pale)
                    }
                }
                ForEach(ProfileKind.allCases) { option in
                    Button {
                        kind = option
                        exportedURL = nil
                        status = ""
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: option.symbol)
                                .font(.title3).foregroundStyle(NoxStyle.cyan).frame(width: 35)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(option.rawValue).font(.subheadline.bold()).foregroundStyle(.white)
                                Text(option.detail).font(.caption).foregroundStyle(NoxStyle.pale)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: kind == option ? "checkmark.circle.fill" : "circle")
                                .foregroundStyle(NoxStyle.accent)
                        }
                        .padding(14)
                        .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(NoxStyle.accent.opacity(kind == option ? 0.9 : 0.2)))
                    }.buttonStyle(.plain)
                }
                NoxCard {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("CONFIGURE · \(kind.rawValue.uppercased())")
                            .font(.caption.weight(.heavy)).tracking(1).foregroundStyle(NoxStyle.accent)
                        editor
                        if kind != .importProfile {
                            Button { generate() } label: {
                                Label("Create .mobileconfig", systemImage: "doc.badge.gearshape")
                                    .font(.headline).frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(NoxStyle.violet)
                            .disabled(!canGenerate)
                        }
                        if let file = exportedURL {
                            ShareLink(item: file) {
                                Label("Export Profile to Files", systemImage: "square.and.arrow.up")
                                    .frame(maxWidth: .infinity)
                            }.buttonStyle(.bordered).tint(NoxStyle.cyan)
                        }
                        if !status.isEmpty { Text(status).font(.caption).foregroundStyle(NoxStyle.pale) }
                    }
                }
                NoxCard {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("INSTALL & REMOVE").font(.caption.weight(.heavy)).foregroundStyle(NoxStyle.accent)
                        Text("1. Export the profile to Files and open it.\n2. In Settings, find Profile Downloaded or General → VPN & Device Management.\n3. Review and install it yourself. Remove the profile there to revert its restrictions.")
                            .font(.caption).foregroundStyle(NoxStyle.pale)
                        Text("Profiles cannot install silently. Device supervision and Apple management policy may prevent some changes.")
                            .font(.caption).foregroundStyle(NoxStyle.cyan)
                        Text("Profile installation, account, USB, and locked-layout changes can have surprising effects. Export one profile at a time, verify it, and retain a known-good backup.")
                            .font(.caption).foregroundStyle(.orange)
                    }
                }
            }
            .padding(16)
        }
        .background(NoxStyle.background.ignoresSafeArea())
        .navigationTitle("Supervised Tweaks")
        .navigationBarTitleDisplayMode(.inline)
        .tint(NoxStyle.accent)
        .fileImporter(isPresented: $showFontPicker, allowedContentTypes: [.item]) { result in
            importFont(result)
        }
        .fileImporter(isPresented: $showProfilePicker, allowedContentTypes: [.item]) { result in
            importProfile(result)
        }
    }

    @ViewBuilder private var editor: some View {
        switch kind {
        case .footnote:
            TextField("Leading footnote", text: $leadingText)
            TextField("Trailing footnote", text: $trailingText)
            Text("Displayed on compatible supervised lock screens.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
        case .webClip:
            TextField("Shortcut title", text: $webTitle)
            TextField("https://example.com", text: $webURL)
                .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
            Toggle("Open full screen", isOn: $fullScreen)
        case .restrictions:
            restrictionsEditor
        case .notifications:
            TextField("App bundle ID (com.example.app)", text: $bundleID)
                .textInputAutocapitalization(.never).autocorrectionDisabled()
            Toggle("Allow notifications", isOn: $notificationsEnabled)
            Text("Turning this off may also suppress urgent alerts from that app.")
                .font(.caption).foregroundStyle(.orange)
        case .font:
            Button { showFontPicker = true } label: {
                Label("Choose .ttf or .otf font", systemImage: "square.and.arrow.down")
            }.buttonStyle(.bordered).tint(NoxStyle.cyan)
            if !fontFileName.isEmpty {
                Label(fontFileName, systemImage: "checkmark.circle.fill")
                    .font(.subheadline).foregroundStyle(NoxStyle.pale)
            }
            Text("Installed fonts appear only in apps that support custom fonts. This does not replace the system font.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
        case .homeLayout:
            Text("One app bundle ID per line, in the order you want icons on the first Home Screen page.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
            TextEditor(text: $layoutPageIDs).frame(height: 110)
                .scrollContentBackground(.hidden)
                .padding(6).background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 10))
            Text("Dock app bundle IDs (one per line; up to four on iPhone)")
                .font(.caption).foregroundStyle(NoxStyle.pale)
            TextEditor(text: $layoutDockIDs).frame(height: 72)
                .scrollContentBackground(.hidden)
                .padding(6).background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 10))
            Label("This LOCKS and REORDERS the Home Screen. The original layout may not return after profile removal. Make a backup first.", systemImage: "exclamationmark.triangle.fill")
                .font(.caption).foregroundStyle(.orange)
        case .importProfile:
            Button { showProfilePicker = true } label: {
                Label("Select .mobileconfig", systemImage: "doc.text.magnifyingglass")
            }.buttonStyle(.bordered).tint(NoxStyle.cyan)
            if !importedProfileSummary.isEmpty {
                Text(importedProfileSummary).font(.caption).foregroundStyle(NoxStyle.pale)
            }
            if let importedProfileURL {
                ShareLink(item: importedProfileURL) {
                    Label("Share Original Profile", systemImage: "square.and.arrow.up")
                }.buttonStyle(.bordered).tint(NoxStyle.cyan)
            }
            Text("Inspection does not install, trust, or approve a profile. Review unknown profiles carefully in Settings.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
        }
    }

    @ViewBuilder private var restrictionsEditor: some View {
            Text("Lithium 0.2 plus restriction options from the documented Lithium Shortcut 1.0 feature list. ON means the feature is restricted by the exported profile.")
                .font(.caption).foregroundStyle(NoxStyle.pale)
            Text("Some older iOS restriction keys are deprecated or ignored by recent iOS versions. They require device supervision and may not work on your installed version.")
                .font(.caption2).foregroundStyle(.orange)

            VStack(alignment: .leading, spacing: 10) {
                Label("OTA UPDATES", systemImage: "arrow.down.circle")
                    .font(.caption.bold()).foregroundStyle(NoxStyle.cyan)
                Toggle("Delay OTA Updates", isOn: $delayOTAUpdates)
                if delayOTAUpdates {
                    Stepper("Delay: \(otaDelayDays) days", value: $otaDelayDays, in: 1...90)
                    Text("Maximum 90 days. This delays eligible offered updates; it does not downgrade iOS.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                }
            }
            Divider().overlay(NoxStyle.accent.opacity(0.4))

            VStack(alignment: .leading, spacing: 10) {
                Label("APP VISIBILITY", systemImage: "eye.slash")
                    .font(.caption.bold()).foregroundStyle(NoxStyle.cyan)
                Text("Hide specific installed apps by their case-sensitive bundle IDs. Their data is not deleted.")
                    .font(.caption).foregroundStyle(NoxStyle.pale)
                TextField("Application name", text: $newAppName)
                    .textFieldStyle(.roundedBorder)
                TextField("Bundle ID (e.g. com.example.app)", text: $newAppBundleID)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .textFieldStyle(.roundedBorder)
                Button(action: addVisibilityApp) {
                    Label("Add Application", systemImage: "plus.circle.fill")
                }
                .buttonStyle(.bordered).tint(NoxStyle.cyan)
                if !appVisibilityMessage.isEmpty {
                    Text(appVisibilityMessage)
                        .font(.caption).foregroundStyle(.orange)
                }
                ForEach($visibilityApps) { $app in
                    HStack(spacing: 10) {
                        Toggle(isOn: $app.isHidden) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Hide \(app.name)").font(.subheadline)
                                Text(app.bundleID).font(.caption2).foregroundStyle(NoxStyle.pale)
                            }
                        }
                        Button(role: .destructive) {
                            visibilityApps.removeAll { $0.id == app.id }
                        } label: {
                            Image(systemName: "trash")
                        }
                        .buttonStyle(.borderless)
                        .accessibilityLabel("Remove \(app.name)")
                    }
                }
            }
            Divider().overlay(NoxStyle.accent.opacity(0.4))

            ForEach(NoxRestrictionCatalog.groups) { group in
                VStack(alignment: .leading, spacing: 9) {
                    Label(group.name.uppercased(), systemImage: group.icon)
                        .font(.caption.bold()).foregroundStyle(NoxStyle.cyan)
                    ForEach(group.features) { feature in
                        Toggle("Disable \(feature.name)", isOn: Binding(
                            get: { disabledRestrictionIDs.contains(feature.id) },
                            set: { isDisabled in
                                if isDisabled {
                                    disabledRestrictionIDs.insert(feature.id)
                                } else {
                                    disabledRestrictionIDs.remove(feature.id)
                                }
                            }
                        ))
                        if disabledRestrictionIDs.contains(feature.id), let warning = feature.warning {
                            Text(warning)
                                .font(.caption2).foregroundStyle(.orange)
                        }
                    }
                }
                Divider().overlay(NoxStyle.accent.opacity(0.4))
            }
    }

    private var canGenerate: Bool {
        switch kind {
        case .footnote: return !leadingText.isEmpty || !trailingText.isEmpty
        case .webClip:
            guard let url = URL(string: webURL), let scheme = url.scheme?.lowercased() else { return false }
            return !webTitle.isEmpty && (scheme == "https" || scheme == "http") && url.host != nil
        case .restrictions:
            return !disabledRestrictionIDs.isEmpty || delayOTAUpdates || visibilityApps.contains(where: { $0.isHidden })
        case .notifications: return bundleID.contains(".") && !bundleID.contains(" ")
        case .font: return fontFileData != nil
        case .homeLayout:
            let page = parsedBundleIDs(layoutPageIDs)
            let dock = parsedBundleIDs(layoutDockIDs)
            return !page.isEmpty && !dock.isEmpty && page.count <= 24 && dock.count <= 4 &&
                (page + dock).allSatisfy { $0.contains(".") && !$0.contains(" ") }
        case .importProfile: return false
        }
    }

    private func addVisibilityApp() {
        let name = newAppName.trimmingCharacters(in: .whitespacesAndNewlines)
        let bundleID = newAppBundleID.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, bundleID.contains("."), !bundleID.contains(" "),
              bundleID.first != ".", bundleID.last != ".",
              !visibilityApps.contains(where: { $0.bundleID == bundleID }) else {
            appVisibilityMessage = "Enter a name and a unique, valid bundle ID."
            return
        }
        visibilityApps.append(NoxVisibilityApp(name: name, bundleID: bundleID, isHidden: true))
        newAppName = ""
        newAppBundleID = ""
        appVisibilityMessage = ""
    }

    private func parsedBundleIDs(_ text: String) -> [String] {
        text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private func importFont(_ result: Result<URL, Error>) {
        switch result {
        case .failure(let error): status = "Could not open font: \(error.localizedDescription)"
        case .success(let file):
            let scoped = file.startAccessingSecurityScopedResource()
            defer { if scoped { file.stopAccessingSecurityScopedResource() } }
            let ext = file.pathExtension.lowercased()
            guard ext == "ttf" || ext == "otf" else {
                status = "Only .ttf and .otf fonts are supported."
                return
            }
            do {
                let data = try Data(contentsOf: file)
                let magic = Array(data.prefix(4))
                let validMagic = magic == [0, 1, 0, 0] ||
                    magic == Array("OTTO".utf8) || magic == Array("true".utf8)
                guard validMagic, data.count <= 10_000_000 else {
                    status = "Invalid or oversized font (10 MB maximum)."
                    return
                }
                fontFileData = data
                fontFileName = file.lastPathComponent
                exportedURL = nil
                status = "Font loaded. Create and export its profile."
            } catch {
                status = "Could not read font: \(error.localizedDescription)"
            }
        }
    }

    private func importProfile(_ result: Result<URL, Error>) {
        switch result {
        case .failure(let error): status = "Could not open profile: \(error.localizedDescription)"
        case .success(let file):
            let scoped = file.startAccessingSecurityScopedResource()
            defer { if scoped { file.stopAccessingSecurityScopedResource() } }
            guard file.pathExtension.lowercased() == "mobileconfig" else {
                status = "Choose a .mobileconfig file."
                return
            }
            do {
                let data = try Data(contentsOf: file)
                guard data.count < 12_000_000,
                      let plist = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
                      (plist["PayloadType"] as? String) == "Configuration",
                      let payloads = plist["PayloadContent"] as? [[String: Any]] else {
                    status = "Not a valid, readable configuration profile."
                    return
                }
                let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                    .appendingPathComponent("NOXERRA Profiles", isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let copy = directory.appendingPathComponent("Imported-\(UUID().uuidString.prefix(8)).mobileconfig")
                try data.write(to: copy, options: .atomic)
                importedProfileURL = copy
                let name = plist["PayloadDisplayName"] as? String ?? "Unnamed Profile"
                let kinds = payloads.compactMap { $0["PayloadType"] as? String }.joined(separator: ", ")
                importedProfileSummary = "Name: \(name)\nPayloads (\(payloads.count)): \(kinds)\nIdentifier: \(plist["PayloadIdentifier"] as? String ?? "Unknown")"
                status = "Profile inspected. Nothing was installed."
            } catch {
                importedProfileURL = nil
                importedProfileSummary = ""
                status = "Could not read profile: \(error.localizedDescription)"
            }
        }
    }

    private func generate() {
        do {
            let payload: [String: Any]
            let type: String
            switch kind {
            case .footnote:
                type = "com.apple.shareddeviceconfiguration"
                payload = ["IfLostReturnToMessage": leadingText, "AssetTagInformation": trailingText]
            case .webClip:
                type = "com.apple.webClip.managed"
                payload = ["Label": webTitle, "URL": webURL, "FullScreen": fullScreen,
                           "IsRemovable": true, "Precomposed": false, "IgnoreManifestScope": false]
            case .restrictions:
                type = "com.apple.applicationaccess"
                var restrictions: [String: Any] = [:]
                for group in NoxRestrictionCatalog.groups {
                    for feature in group.features where disabledRestrictionIDs.contains(feature.id) {
                        for key in feature.keys {
                            restrictions[key] = false
                        }
                    }
                }
                if delayOTAUpdates {
                    restrictions["forceDelayedSoftwareUpdates"] = true
                    restrictions["enforcedSoftwareUpdateDelay"] = max(1, min(90, otaDelayDays))
                }
                let blockedIDs = visibilityApps.filter { $0.isHidden }.map { $0.bundleID }
                if !blockedIDs.isEmpty {
                    restrictions["blockedAppBundleIDs"] = blockedIDs
                }
                payload = restrictions
            case .notifications:
                type = "com.apple.notificationsettings"
                payload = ["NotificationSettings": [["BundleIdentifier": bundleID,
                                                       "NotificationsEnabled": notificationsEnabled]]]
            case .font:
                guard let fontFileData else { return }
                type = "com.apple.font"
                payload = ["Font": fontFileData, "Name": fontFileName]
            case .homeLayout:
                type = "com.apple.homescreenlayout"
                let page = parsedBundleIDs(layoutPageIDs).map { ["Type": "Application", "BundleID": $0] }
                let dock = parsedBundleIDs(layoutDockIDs).map { ["Type": "Application", "BundleID": $0] }
                payload = ["Pages": [page], "Dock": dock]
            case .importProfile:
                return
            }
            let uuid = UUID().uuidString
            var content = payload
            content["PayloadType"] = type
            content["PayloadUUID"] = UUID().uuidString
            content["PayloadIdentifier"] = "app.noxerra.supervised.\(uuid)"
            content["PayloadVersion"] = 1
            let profile: [String: Any] = [
                "PayloadContent": [content], "PayloadDisplayName": "NOXERRA · \(kind.rawValue)",
                "PayloadOrganization": "NOXERRA", "PayloadDescription": kind.detail,
                "PayloadIdentifier": "app.noxerra.profile.\(uuid)", "PayloadType": "Configuration",
                "PayloadUUID": uuid, "PayloadVersion": 1
            ]
            let data = try PropertyListSerialization.data(fromPropertyList: profile, format: .xml, options: 0)
            let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("NOXERRA Profiles", isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let file = directory.appendingPathComponent("NOXERRA-\(UUID().uuidString.prefix(8)).mobileconfig")
            try data.write(to: file, options: .atomic)
            exportedURL = file
            status = "Ready to export. No sandbox exploit was used."
            NoxSound.shared.playTap()
        } catch {
            exportedURL = nil
            status = "Unable to generate profile: \(error.localizedDescription)"
        }
    }
}

// 0.2 feature names and keys cross-checked with the uploaded Lithium 0.2 source;
// additional options identified from the public Lithium Shortcut 1.0 README and
// Apple's com.apple.applicationaccess reference. This remains a NOXERRA implementation.
private struct NoxVisibilityApp: Identifiable {
    let id = UUID()
    var name: String
    var bundleID: String
    var isHidden: Bool
}

private enum NoxRestrictionCatalog {
    struct Feature: Identifiable {
        let name: String
        let keys: [String]
        var warning: String? = nil
        var id: String { keys[0] }
    }

    struct Group: Identifiable {
        let name: String
        let icon: String
        let features: [Feature]
        var id: String { name }
    }

    static let groups: [Group] = [
        Group(name: "Apps", icon: "app", features: [
            Feature(name: "App Store", keys: ["allowUIAppInstallation"]),
            Feature(name: "App Clips", keys: ["allowAppClips"],
                    warning: "Existing App Clips may be removed when this restriction applies."),
            Feature(name: "Wallpaper Modification", keys: ["allowWallpaperModification"],
                    warning: "Prevents changing the Lock or Home Screen wallpaper."),
            Feature(name: "App Installation & Removal", keys: ["allowAppInstallation", "allowAppRemoval"]),
            Feature(name: "In-App Purchases", keys: ["allowInAppPurchases"]),
            Feature(name: "Apple Music Services", keys: ["allowMusicService", "allowRadioService"]),
            Feature(name: "Automatic App Downloads", keys: ["allowAutomaticAppDownloads"]),
            Feature(name: "Bookstore", keys: ["allowBookstore"],
                    warning: "Disabling Bookstore may affect book downloads and BookRestore-based tools on some iOS versions.")
        ]),
        Group(name: "System Features", icon: "gearshape", features: [
            Feature(name: "Screen Capture", keys: ["allowScreenShot"]),
            Feature(name: "Siri", keys: ["allowAssistant"]),
            Feature(name: "Game Center", keys: ["allowGameCenter"]),
            Feature(name: "Screen Time", keys: ["allowEnablingRestrictions"],
                    warning: "This restricts enabling Screen Time settings; device policy determines the exact effect."),
            Feature(name: "Safari", keys: ["allowSafari"]),
            Feature(name: "Camera", keys: ["allowCamera"]),
            Feature(name: "Classroom Remote Screen Observation", keys: ["allowRemoteScreenObservation"],
                    warning: "Classroom supervision and management policies determine which controls apply."),
            Feature(name: "Explicit iTunes Content", keys: ["allowExplicitContent"]),
            Feature(name: "Explicit Bookstore Content", keys: ["allowBookstoreErotica"])
        ]),
        Group(name: "Sharing & External Features", icon: "iphone.radiowaves.left.and.right", features: [
            Feature(name: "Apple Watch Pairing", keys: ["allowPairedWatch"],
                    warning: "Lithium warns that disabling pairing may unpair and reset an already paired Apple Watch."),
            Feature(name: "Proximity Setup", keys: ["allowProximitySetupToNewDevice"]),
            Feature(name: "Nearby Password Requests", keys: ["allowPasswordProximityRequests"]),
            Feature(name: "Password Sharing", keys: ["allowPasswordSharing"]),
            Feature(name: "USB Restricted Mode", keys: ["allowUSBRestrictedMode"],
                    warning: "DISABLES USB Restricted Mode, permitting compatible USB accessories while locked. This REDUCES security. Do not enable unless intentional."),
            Feature(name: "NFC", keys: ["allowNFC"],
                    warning: "Disabling NFC can prevent contactless passes and cards from working."),
            Feature(name: "AirDrop", keys: ["allowAirDrop"])
        ]),
        Group(name: "System Settings", icon: "gearshape.2", features: [
            Feature(name: "Account Changes", keys: ["allowAccountModification"],
                    warning: "Prevents changing Apple Account and internet account settings."),
            Feature(name: "Erase All Content & Settings", keys: ["allowEraseContentAndSettings"],
                    warning: "Disables the erase button in Settings; does not make the device impossible to erase via other methods."),
            Feature(name: "Manual Profile Installation", keys: ["allowUIConfigurationProfileInstallation"],
                    warning: "HIGH IMPACT: may prevent installing another configuration profile or certificate. Remove this profile to restore installation access."),
            Feature(name: "Passcode Changes", keys: ["allowPasscodeModification"]),
            Feature(name: "Device Name Changes", keys: ["allowDeviceNameModification"])
        ]),
        Group(name: "Apple Intelligence (iOS 18.1+)", icon: "sparkles", features: [
            Feature(name: "Genmoji", keys: ["allowGenmoji"]),
            Feature(name: "Image Wand", keys: ["allowImageWand"]),
            Feature(name: "Mail Smart Replies", keys: ["allowMailSmartReplies"]),
            Feature(name: "Mail Summaries", keys: ["allowMailSummary"]),
            Feature(name: "Personalized Handwriting Results", keys: ["allowPersonalizedHandwritingResults"]),
            Feature(name: "Safari Summary", keys: ["allowSafariSummary"]),
            Feature(name: "Visual Intelligence Summary", keys: ["allowVisualIntelligenceSummary"]),
            Feature(name: "Writing Tools", keys: ["allowWritingTools"])
        ])
    ]
}
