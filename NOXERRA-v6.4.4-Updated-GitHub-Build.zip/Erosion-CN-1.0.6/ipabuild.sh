#!/usr/bin/env bash
# Build an unsigned iPhoneOS IPA using an available Xcode installation.
# Signing must be performed separately before installing on a device.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
PROJECT="$ROOT/Erosion.xcodeproj"
SCHEME="Erosion"
APP_NAME="Erosion"
CONFIGURATION="Release"
[[ "${1:-}" != "--debug" ]] || CONFIGURATION="Debug"

VERSION="$(sed -n 's/.*MARKETING_VERSION = \([^;]*\);/\1/p' "$PROJECT/project.pbxproj" | head -n 1 | tr -d '[:space:]')"
[[ -n "$VERSION" ]] || { echo 'Cannot read MARKETING_VERSION from Xcode project' >&2; exit 1; }
[[ -d "$PROJECT" ]] || { echo "Missing Xcode project: $PROJECT" >&2; exit 1; }

DERIVED="$ROOT/build/DerivedData"
APP_PATH="$DERIVED/Build/Products/${CONFIGURATION}-iphoneos/${APP_NAME}.app"
IPA_NAME="NOXERRA_v${VERSION}_${CONFIGURATION}.ipa"

rm -rf "$ROOT/build"
rm -f "$ROOT"/NOXERRA_v*_"$CONFIGURATION".ipa
mkdir -p "$ROOT/build"

echo "[*] Building NOXERRA v$VERSION ($CONFIGURATION) with $(xcodebuild -version | head -n1)"
xcodebuild \
    -project "$PROJECT" \
    -scheme "$SCHEME" \
    -configuration "$CONFIGURATION" \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$DERIVED" \
    CODE_SIGNING_ALLOWED=NO \
    CODE_SIGNING_REQUIRED=NO \
    CODE_SIGN_IDENTITY='' \
    clean build

[[ -d "$APP_PATH" ]] || { echo "Compiled .app is missing: $APP_PATH" >&2; exit 1; }

mkdir -p "$ROOT/build/Payload"
ditto "$APP_PATH" "$ROOT/build/Payload/${APP_NAME}.app"
(
    cd "$ROOT/build"
    /usr/bin/zip -qry "$ROOT/$IPA_NAME" Payload
)
[[ -s "$ROOT/$IPA_NAME" ]] || { echo 'IPA packaging failed' >&2; exit 1; }
echo "[*] Created unsigned IPA: $ROOT/$IPA_NAME"
