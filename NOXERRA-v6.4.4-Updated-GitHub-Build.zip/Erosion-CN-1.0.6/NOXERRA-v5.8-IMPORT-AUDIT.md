# NOXERRA v5.8 import audit (partial integration)

Source reviewed: WorkTweaks 6.1, Regitela 1.0.7, Gester 1, GestaltX 1.1.1.

New controls staged through existing MobileGestalt cache + backup/Apply workflow:
- Disable Wallpaper Parallax (UIParallaxCapability=0)
- Allow iPad Apps (9MZ5AdH43csAUajl/dU+IQ=[1,2])
- Security Research Device Flag (XYlJKKkj2hztRP1NWWnhlw=1)
- Internal Storage View (LBJfwOEzExRxzlAnSuI7eg=1)

Not duplicated: Always-On Display, AOD vibrancy, charge limit, Dynamic Island, Stage Manager, Apple Pencil, Tap to Wake, Action Button, Camera Control, Collision SOS, PWM, Internal Install, boot chime, Apple Intelligence and many others already in the original NOXERRA MobileGestalt screen.

NOT YET PORTED: Regitela's CloudConfigurationDetails.plist IsSupervised writer; WorkTweaks' CacheData iPadOS-mode patch; remaining source-specific patches and GestaltX application-media system modifications. The current iPadOS mode lock is unchanged. This release does not claim to implement these features.

No iOS compilation/device test was performed; Swift frontend parsing only.
