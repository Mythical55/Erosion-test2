import SwiftUI

struct NoxSandboxExtensionView: View {
    @State private var targetPath = MGURL.fsGestaltURL.deletingLastPathComponent().path
    @State private var status = "No access request made"
    @State private var active = false
    @State private var owned = false
    @State private var grantedPath: String?
    @State private var grantedEngine: NoxExploitBackend?
    @AppStorage(NoxExploitSelection.storageKey) private var selectedEngine = NoxExploitBackend.worseQuery.rawValue
    var body: some View {
        Form {
            Section("SANDBOX ACCESS") {
                TextField("Target path", text: $targetPath, axis: .vertical)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                HStack {
                    Button("Consume Sandbox Extension") {
                        if owned { releaseOwnedHandle() }
                        let backend = NoxExploitBackend(rawValue: selectedEngine) ?? .worseQuery
                        let requestedPath = (targetPath as NSString).standardizingPath
                        let alreadyActive = wq.hasActiveAccess(path: requestedPath, backend: backend)
                        let result = wq.grantAccess(path: requestedPath, requireWrite: false, backend: backend)
                        active = result.0
                        owned = result.0 && !alreadyActive
                        grantedPath = result.0 ? requestedPath : nil
                        grantedEngine = result.0 ? backend : nil
                        status = result.0 ? (alreadyActive ? "Access active; another tool owns its handle" : result.2) : "Error \(result.1): \(result.2)"
                    }.buttonStyle(.borderedProminent)
                    Button("Release") { releaseOwnedHandle() }
                        .buttonStyle(.bordered).disabled(!active)
                }
                Text(status).font(.caption).foregroundStyle(.secondary)
            }
            Section("INFORMATION") {
                Text("Uses the engine selected on Home. Bad Query is experimental; neither engine guarantees access. Every requested path is checked against actual iOS permissions.")
                    .font(.footnote)
            }
        }
        .navigationTitle("Sandbox Extension")
        .onChange(of: selectedEngine) { _, _ in
            if owned { releaseOwnedHandle() }
        }
    }

    private func releaseOwnedHandle() {
        if owned, let grantedPath, let grantedEngine {
            wq.releaseAccess(path: grantedPath, backend: grantedEngine)
            status = "Released \(grantedEngine.displayName) access handle."
        } else {
            status = "No handle owned by this screen."
        }
        owned = false
        active = false
        grantedPath = nil
        grantedEngine = nil
    }
}
