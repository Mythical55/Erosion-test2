//
//  ErosionApp.swift
//  Erosion
//
//  Created by lunginspector on 8/14/26.
//

import SwiftUI
import Combine
import UniformTypeIdentifiers

let device = UIDevice.current
let fm = FileManager.default
var weOnADebugBuild = false
var pipe = Pipe()
var sema = DispatchSemaphore(value: 0)

@main
struct ErosionApp: App {
    @StateObject private var mgr = ErosionManager.shared
    @StateObject private var langMgr = LocalizationManager.shared
    @State private var currentTab = 0
    @State private var didBootstrapLogs = false
    
    init() {
        UserDefaults.standard.register(defaults: [
            "mgWriteAtomically": true,
            "maxInode": 15000000,
            "mgOverrideGates": true
        ])
        if !UserDefaults.standard.bool(forKey: "mgAtomicDefaultMigrated") {
            UserDefaults.standard.set(true, forKey: "mgWriteAtomically")
            UserDefaults.standard.set(true, forKey: "mgAtomicDefaultMigrated")
        }
        
        // Consistent dark glass tab bar across all five root destinations.
        let tabAppearance = UITabBarAppearance()
        tabAppearance.configureWithDefaultBackground()
        tabAppearance.backgroundColor = UIColor(red: 0.075, green: 0.055, blue: 0.12, alpha: 0.96)
        tabAppearance.stackedLayoutAppearance.normal.iconColor = .lightGray
        tabAppearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor.lightGray]
        tabAppearance.stackedLayoutAppearance.selected.iconColor = UIColor(red: 0.75, green: 0.28, blue: 1.0, alpha: 1)
        tabAppearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor(red: 0.75, green: 0.28, blue: 1.0, alpha: 1)]
        UITabBar.appearance().standardAppearance = tabAppearance
        UITabBar.appearance().scrollEdgeAppearance = tabAppearance

        setvbuf(stdout, nil, _IONBF, 0)
        dup2(pipe.fileHandleForWriting.fileDescriptor, STDOUT_FILENO)
        
        // fix file picker
        let fixMethod = class_getInstanceMethod(UIDocumentPickerViewController.self, #selector(UIDocumentPickerViewController.fix_init(forOpeningContentTypes:asCopy:)))!
        let origMethod = class_getInstanceMethod(UIDocumentPickerViewController.self, #selector(UIDocumentPickerViewController.init(forOpeningContentTypes:asCopy:)))!
        method_exchangeImplementations(origMethod, fixMethod)
        
        #if DEBUG
        weOnADebugBuild = true
        #else
        weOnADebugBuild = false
        #endif
    }
    
    var body: some Scene {
        WindowGroup {
            TabView(selection: $currentTab) {
                ContentView(selectedTab: $currentTab)
                    .tabItem { Label("Home", systemImage: "house.fill") }
                    .tag(0)
                TweaksView()
                    .tabItem { Label("Tweaks", systemImage: "slider.horizontal.3") }
                    .tag(1)
                FMRootView()
                    .tabItem { Label("Files", systemImage: "folder.fill") }
                    .tag(2)
                NoxLogView()
                    .tabItem { Label("Log", systemImage: "text.alignleft") }
                    .tag(3)
                NoxSettingsView()
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }
                    .tag(4)
            }
            .tint(NoxStyle.accent)
            .preferredColorScheme(.dark)
            .onChange(of: currentTab) { _, _ in
                NoxSound.shared.playTap()
            }
            .id(langMgr.refreshID)
            .environment(\.locale, langMgr.effectiveLocale)
            .environmentObject(mgr)
            .onAppear {
                guard !didBootstrapLogs else { return }
                didBootstrapLogs = true
                pipe.fileHandleForReading.readabilityHandler = { fh in
                    let data = fh.availableData
                    
                    if data.isEmpty {
                        fh.readabilityHandler = nil
                        sema.signal()
                        return
                    }
                    
                    guard let text = String(data: data, encoding: .utf8) else {
                        return
                    }
                    
                    DispatchQueue.main.async {
                        mgr.logOutput.append(text)
                        // Retain the latest 256 KiB of console output to avoid
                        // unbounded SwiftUI re-rendering and memory usage.
                        if mgr.logOutput.utf8.count > 262_144 {
                            let tail = String(mgr.logOutput.suffix(180_000))
                            mgr.logOutput = "[NOXERRA] Older console output trimmed for performance.\n" + tail
                        }
                    }
                }
                print("")
                print("[*] NOXERRA Clean v\(AppInfo.appVersion) (Erosion-CN base)")
                print(L("[*] 运行环境：\(UIDevice.current.systemName) \(UIDevice.current.systemVersion)，设备标识符：\(machineName()) (\(buildNumber()))"))
                // Compatibility is advisory. A reported unsupported firmware does not
                // close the app or disable the regular file browser.
                if !isSupported() { print("[!] Sandbox escape compatibility is unverified on this iOS version") }
                group = wq.getAppGroup()
                print(L("(wq) 当前使用 App Group：\(group)"))
                if isRunningInLiveContainer() {
                    print(LocalizationManager.isEnglish
                        ? "[!] (lc) Currently running inside LiveContainer: if container authorization fails, check host App Group settings in LiveContainer or install standalone."
                        : "[!] (lc) 当前运行在 LiveContainer 内，若遇容器授权失败，请在 LiveContainer 应用设置中检查宿主 App Group 配置，或使用独立侧载安装。")
                }
            }
            .overlay {
                if mgr.shouldRespring {
                    RespringView()
                        .brightness(-1.0)
                        .ignoresSafeArea()
                }
            }
        }
    }
}

extension UIDocumentPickerViewController {
    @objc func fix_init(forOpeningContentTypes contentTypes: [UTType], asCopy: Bool) -> UIDocumentPickerViewController {
        return fix_init(forOpeningContentTypes: contentTypes, asCopy: true)
    }
}
