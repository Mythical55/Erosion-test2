# NOXERRA v5.5 — Configuration Profiles & User Restrictions

## Screens
- Tweaks → Configuration Profiles: inspect live .stub entries and all metadata; create, rename, edit UTF-8 contents, back up, export, and delete files with confirmations.
- Tweaks → User Restrictions: loads the live `UserSettings.plist` from the existing `FSURL.configProfiles` directory through the chosen NOXERRA engine. Displays every entry across `restrictedBool`, `restrictedValue`, `intersection`, `union`, `assignedObject`. Toggles bool values including `ask`, numeric value editors with min/max validation, newline list editors.
- Safe fallback: bundled sanitized catalog from supplied `UserSettings.plist` (324 restriction entries); if live file is not accessible, display **reference mode** with Save disabled. Removes the sample's code-signing identity before bundling.
- Before modifying any existing protected file, create an app-local original backup in Documents/NOXERRA/ProfileBackups (export through Files/Share before uninstall). Compare original data to prevent overwriting external changes. Verify writes by re-reading.

## Critical limitations
A `.stub` is an iOS internal store artifact; creating/renaming/deleting one does not install or uninstall a configuration profile through iOS. Manually modifying the store can be ignored/rebuilt by the system or cause inconsistent management state. Configuration profile install/uninstall remains controlled by iOS Settings/MDM. Manually changing `UserSettings.plist` does not guarantee restrictions become effective: the profile service may recompute/reassert them. Inability to write is correctly reported.

## Build
GitHub Actions builds the unsigned IPA on macOS. Syntax checks performed on Linux do not equal full iOS SDK type-checking or successful execution on an iPhone.
