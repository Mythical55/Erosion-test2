# NOXERRA — source rebuild changelog

- Installed standard PNG AppIcon.appiconset for iOS Home Screen, with in-app matching logo.
- Refreshed neon purple styling, Home date/time, compatibility matrix, Respring SpringBoard and recovery.
- Removed Restart Help / Original Tools entries from Home.
- Added per-container Consume and Release access actions on Home and MobileGestalt.
- Made MobileGestalt advanced UI options visible by default, without disabling binary/cache write safety checks.
- Added extensive editable model-name presets for iPhone and iPad families.
- Preserved original Audio Mix, WAPI, Region Code, Sales Region and Model Number engine.
- Reorganized Phone Dialer buttons and exposed Phone container path directly.
- Redesigned Files welcome section while retaining original folder browser navigation.
- Settings language selection reduced to English / Simplified Chinese, CSStore2, auto-respring, sound and animations.
- Maintained GPLv3 license and source notices; NOXERRA personalized by java in UI.

## Validation limits
Swift frontend syntax parse does not prove iOS typechecking or successful IPA packaging. Compile via GitHub Actions and test on device. Some features depend on exploit availability and signing entitlements.

- Added Mond-inspired Dismiss After Importing, and a clearly scoped foreground Keep Screen Awake setting. Persist After Reboot retains original validated in-place write semantics; failed sandbox access is never silently ignored.
