import SwiftUI
import UIKit

// NOXERRA Home keeps the dashboard short; full access results live in Access Center.
// A readable directory is not proof that an exploit caused the read permission.
struct ContentView: View {
    // Navigation shortcuts update the same TabView selection as the bottom bar.
    @Binding private var selectedTab: Int

    init(selectedTab: Binding<Int> = .constant(0)) {
        self._selectedTab = selectedTab
    }

    @EnvironmentObject private var mgr: ErosionManager
    @ObservedObject private var vault = APFSStagingVault.shared
    @ObservedObject private var launcher = NoxExploitLauncher.shared
    @State private var showRespring = false
    @State private var showRestore = false
    @State private var showCompat = false
    @State private var showAccessCenter = false
    @AppStorage(NoxExploitSelection.storageKey) private var selectedEngine = NoxExploitBackend.worseQuery.rawValue

    private var engine: NoxExploitBackend {
        NoxExploitBackend(rawValue: selectedEngine) ?? .worseQuery
    }
    private let grid = [GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        NavigationStack {
            // Normal VStack layout respects the status bar and dynamic-island safe area.
            // No overlay/alignment hacks over the system clock.
            VStack(spacing: 0) {
                brandHeader
                ScrollView {
                    VStack(alignment: .leading, spacing: 19) {
                        TimelineView(.periodic(from: .now, by: 60)) { context in
                            NoxCard {
                                HStack(spacing: 13) {
                                    Image(systemName: greetingSymbol(for: context.date))
                                        .font(.system(size: 28, weight: .semibold))
                                        .foregroundStyle(NoxStyle.accent)
                                        .frame(width: 48, height: 48)
                                        .background(NoxStyle.accent.opacity(0.15), in: RoundedRectangle(cornerRadius: 16))
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(greeting(for: context.date))
                                            .font(.title2.weight(.heavy))
                                            .foregroundStyle(.white)
                                        Text(context.date.formatted(.dateTime.weekday(.wide).month(.wide).day().hour().minute()))
                                            .font(.subheadline)
                                            .foregroundStyle(NoxStyle.pale)
                                    }
                                    Spacer(minLength: 0)
                                }
                            }
                        }

                        NoxCard {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("NOXERRA CONTROL")
                                    .font(.caption2.weight(.heavy)).tracking(1.8)
                                    .foregroundStyle(NoxStyle.accent)
                                Text("Your device. Your tools.")
                                    .font(.title2.weight(.bold))
                                Text("Open Tweaks or Files to explore your device and apply supported changes.")
                                    .font(.caption).foregroundStyle(NoxStyle.pale)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }

                        VStack(alignment: .leading, spacing: 11) {
                            sectionTitle("EXPLORE NOXERRA")
                            LazyVGrid(columns: grid, spacing: 10) {
                                quickLaunch("Tweaks", "slider.horizontal.3", tab: 1)
                                quickLaunch("Files", "folder.fill", tab: 2)
                                quickLaunch("Log", "text.alignleft", tab: 3)
                                quickLaunch("Settings", "gearshape.fill", tab: 4)
                            }
                        }

                        VStack(alignment: .leading, spacing: 11) {
                            sectionTitle("DEVICE OVERVIEW")
                            LazyVGrid(columns: grid, spacing: 11) {
                                metric("Device", machineName(), "iphone.gen3")
                                metric("iOS", UIDevice.current.systemVersion, "apple.logo")
                                metric("Free storage", freeStorageText, "internaldrive")
                                metric("System model", UIDevice.current.model, "cpu")
                            }
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            sectionTitle("QUICK CONTROLS")
                            NoxCard {
                                Button { showRespring = true; NoxSound.shared.playTap() } label: {
                                    Label("Respring SpringBoard", systemImage: "arrow.triangle.2.circlepath")
                                        .font(.headline).frame(maxWidth: .infinity, alignment: .leading)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(NoxStyle.violet)
                                Text("Some tweaks only take effect after a full device restart.")
                                    .font(.caption).foregroundStyle(NoxStyle.pale)
                            }
                            NoxCard {
                                Button { showRestore = true } label: {
                                    Label("MobileGestalt Factory Restore", systemImage: "arrow.uturn.backward.circle.fill")
                                        .font(.subheadline.weight(.semibold))
                                }
                                .tint(.orange)
                                Text("Uses original Erosion backup validation and recovery.")
                                    .font(.caption).foregroundStyle(NoxStyle.pale)
                            }
                            if vault.activeStagedItemsCount > 0 {
                                NoxCard {
                                    Label("Backup vault: \(vault.activeStagedItemsCount) pending restore(s)", systemImage: "externaldrive.badge.exclamationmark")
                                    NavigationLink("Open app save manager", destination: AppDataBackupView())
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 14)
                    .padding(.bottom, 42)
                }
                .scrollIndicators(.hidden)
            }
            .background(NoxAmbientBackground())
            .toolbar(.hidden, for: .navigationBar)
            .alert("Respring SpringBoard?", isPresented: $showRespring) {
                Button("Cancel", role: .cancel) {}
                Button("Respring") { mgr.shouldRespring = true }
            } message: {
                Text("Save your work first. Respring reloads the interface without rebooting the device.")
            }
            .alert("Restore original MobileGestalt?", isPresented: $showRestore) {
                Button("Cancel", role: .cancel) {}
                Button("Restore") { restoreGestalt() }
            } message: {
                Text("Restores a validated original backup if available.")
            }

        }
    }

    private func greeting(for date: Date) -> String {
        let hour = Calendar.current.component(.hour, from: date)
        switch hour {
        case 5..<12: return "Good morning."
        case 12..<17: return "Good afternoon."
        case 17..<22: return "Good evening."
        default: return "Good night."
        }
    }

    private func greetingSymbol(for date: Date) -> String {
        let hour = Calendar.current.component(.hour, from: date)
        return (hour >= 17 || hour < 5) ? "moon.stars.fill" : "sun.max.fill"
    }

    private var engineSummary: String {
        let items = launcher.reports(for: engine)
        guard !items.isEmpty else { return "\(engine.displayName): not tested in this session." }
        let newReads = items.filter(\.newAccessVerified).count
        let preReadable = items.filter(\.alreadyReadable).count
        let readable = items.filter(\.readable).count
        return "\(engine.displayName): \(readable)/\(items.count) readable · \(newReads) newly accessible · \(preReadable) already readable."
    }

    private func compatibilityRow(_ backend: NoxExploitBackend) -> some View {
        let status = NoxCompatibility.check(backend)
        return HStack(alignment: .top, spacing: 11) {
            Image(systemName: status.symbol)
                .foregroundStyle(status.color)
                .font(.title3)
                .frame(width: 25)
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 7) {
                    Text(backend.displayName)
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                    if engine == backend {
                        Text("SELECTED")
                            .font(.system(size: 9, weight: .heavy))
                            .foregroundStyle(NoxStyle.cyan)
                    }
                }
                Text(status.title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(status.color)
                Text(status.detail)
                    .font(.caption2)
                    .foregroundStyle(NoxStyle.pale)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
    }

    private var brandHeader: some View {
        HStack(spacing: 10) {
            Image("NoxerraMark")
                .resizable().scaledToFill()
                .frame(width: 36, height: 36)
                .clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 2) {
                Text("NOXERRA")
                    .font(.system(size: 20, weight: .black, design: .rounded)).tracking(1.4)
                Text("CONTROL YOUR EXPERIENCE")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(NoxStyle.pale)
            }
            Spacer(minLength: 0)
            Image(systemName: "sparkles").foregroundStyle(NoxStyle.accent)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(NoxStyle.background)
        .overlay(alignment: .bottom) {
            Rectangle().fill(NoxStyle.accent.opacity(0.22)).frame(height: 1)
        }
    }

    private func sectionTitle(_ text: String) -> some View {
        Text(text).font(.caption.weight(.heavy)).tracking(1.6).foregroundStyle(NoxStyle.accent)
    }
    private func quickLaunch(_ title: String, _ symbol: String, tab: Int) -> some View {
        Button {
            selectedTab = tab
            NoxSound.shared.playTap()
        } label: {
            HStack(spacing: 10) {
                Image(systemName: symbol)
                    .foregroundStyle(NoxStyle.cyan)
                    .frame(width: 22)
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                Image(systemName: "chevron.right")
                    .font(.caption2)
                    .foregroundStyle(NoxStyle.pale)
            }
            .padding(.horizontal, 12)
            .frame(height: 56)
            .background(NoxStyle.surface, in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).strokeBorder(NoxStyle.accent.opacity(0.25)))
        }
        .buttonStyle(.plain)
    }

    private func metric(_ title: String, _ value: String, _ symbol: String) -> some View {
        NoxCard {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: symbol).font(.title3).foregroundStyle(NoxStyle.accent)
                Text(title).font(.caption).foregroundStyle(NoxStyle.pale)
                Text(value).font(.subheadline.weight(.semibold)).lineLimit(2).minimumScaleFactor(0.7)
            }.frame(height: 78, alignment: .leading)
        }
    }
    private var freeStorageText: String {
        guard let attrs = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()),
              let size = attrs[.systemFreeSize] as? NSNumber else { return "Unknown" }
        return ByteCountFormatter.string(fromByteCount: size.int64Value, countStyle: .file)
    }
    private func restoreGestalt() {
        switch mgExecuteFactoryRestore(alsoResetConfigAndKeypad: false) {
        case .restoredSuccessfully(let details):
            Alertinator.shared.alert(title: "MobileGestalt restored", body: details)
        case .blockedNeedsCleanRebuild(let title, let reason):
            Alertinator.shared.alert(title: title, body: reason)
        case .failed(let reason):
            Alertinator.shared.alert(title: "Restore failed", body: reason)
        }
    }
}


// Source-reported version eligibility, deliberately separate from verified
// runtime access. Never infer a successful exploit from an OS version alone.
private struct NoxCompatibilityStatus {
    let title: String
    let detail: String
    let symbol: String
    let color: Color
}

private enum NoxCompatibility {
    static func check(_ engine: NoxExploitBackend) -> NoxCompatibilityStatus {
        let version = ProcessInfo.processInfo.operatingSystemVersion
        let build = buildNumber().trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        let major = version.majorVersion
        let minor = version.minorVersion
        let patch = version.patchVersion

        func reported(_ detail: String) -> NoxCompatibilityStatus {
            NoxCompatibilityStatus(title: "Reported compatible", detail: detail,
                                   symbol: "checkmark.circle.fill", color: .green)
        }
        func outside(_ detail: String) -> NoxCompatibilityStatus {
            NoxCompatibilityStatus(title: "Outside reported support", detail: detail,
                                   symbol: "exclamationmark.triangle.fill", color: .orange)
        }
        func unverified(_ detail: String) -> NoxCompatibilityStatus {
            NoxCompatibilityStatus(title: "Compatibility unverified", detail: detail,
                                   symbol: "questionmark.circle.fill", color: NoxStyle.cyan)
        }

        switch engine {
        case .worseQuery:
            if major == 26 {
                if minor < 7 || (minor == 7 && patch <= 2) {
                    return reported("iOS 26 range; MobileGestalt writes may still be limited.")
                }
                return outside("Later than the project's iOS 26.7.2 support limit.")
            }
            if major == 27 {
                if minor < 2 || (minor == 2 && patch <= 1) {
                    return reported("Within the published iOS 27.0–27.2.1 range.")
                }
                if minor == 3 && patch == 0 && build.hasPrefix("24C503") {
                    return reported("Detected iOS 27.3 beta 1 build family.")
                }
                if minor == 3 && patch == 0 && !build.hasPrefix("24C") {
                    return unverified("iOS 27.3 build could not be identified reliably.")
                }
                return outside("27.3 beta 2 and later are reported patched/outside support.")
            }
            return unverified("No published compatibility claim for this iOS major version.")
        case .badQuery:
            if major == 26 {
                if minor < 6 || (minor == 6 && patch <= 1) {
                    return reported("Within the published iOS 26.0–26.6.1 range.")
                }
                return outside("Later than the original Bad Query iOS 26.6.1 range.")
            }
            if major == 27 && minor == 0 {
                return unverified("Only iOS 27.0 developer beta 1–4 were reported; this screen cannot confirm a beta from the version alone.")
            }
            return outside("Outside the published Bad Query proof-of-concept range.")
        }
    }
}
