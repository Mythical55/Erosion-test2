# NOXERRA v5.9 — Neon & Quality pass

Based on v5.8. No tweak keys or exploit mechanics changed.

- Shared optional violet/cyan ambient background across Home, Tweaks, Files and Log.
- Reworked shared card rendering with optional neon edge lighting.
- Settings > Appearance & Feedback > Neon Edge Lighting switch.
- Consistent dark tab bar and active purple tab accent.
- Tweaks search now has a proper no-results state.
- Log now supports case-insensitive line filtering, visible export errors and bounded in-memory history (latest 180,000 characters when exceeding 256 KiB).
- Preserved existing tweak implementations and MobileGestalt safety paths.

Validation: Swift frontend syntax parsing and ZIP integrity. Full Xcode compilation and runtime testing are pending.
