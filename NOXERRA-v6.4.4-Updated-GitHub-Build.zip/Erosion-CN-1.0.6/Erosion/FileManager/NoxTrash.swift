import Foundation
import SwiftUI
import Combine

// Recoverable deletion shared by Files and NoxShell. Never replaces the original
// until FileManager successfully moves the item into app-owned storage.
struct NoxTrashEntry: Codable, Identifiable {
    let id: UUID
    let originalPath: String
    let storedName: String
    let deletedAt: Date
    let wasDirectory: Bool

    var displayName: String { URL(fileURLWithPath: originalPath).lastPathComponent }
}

@MainActor
final class NoxTrash: ObservableObject {
    static let shared = NoxTrash()
    static let storageWarning = "NoxTrash is NOT the iOS system trash or Recently Deleted. Deleted items are stored inside NOXERRA's own Application Support data. If you delete/uninstall NOXERRA, iOS removes the app's data, including every item in NoxTrash. Restore or export important files before deleting the app. Offloading is not the same as deleting an app."
    @Published private(set) var entries: [NoxTrashEntry] = []

    private let base: URL
    private let itemsDirectory: URL
    private let indexURL: URL
    private let fileManager = FileManager.default

    private init() {
        let appSupport = fileManager.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL.documentsDirectory
        let root = appSupport.appendingPathComponent("NOXERRA/NoxTrash", isDirectory: true)
        base = root
        itemsDirectory = root.appendingPathComponent("Items", isDirectory: true)
        indexURL = root.appendingPathComponent("index.json")
        try? fileManager.createDirectory(at: itemsDirectory, withIntermediateDirectories: true)
        if let data = try? Data(contentsOf: indexURL),
           let decoded = try? JSONDecoder().decode([NoxTrashEntry].self, from: data) {
            entries = decoded
        }
    }

    func canTrash(_ url: URL) -> Bool {
        let canonical = url.standardizedFileURL.path
        let protected = ["/", "/var", "/var/mobile", "/var/containers", "/private", "/private/var",
                         FSPaths.appContainers, FSURL.appPlugins.path, FSURL.appGroup.path,
                         FSURL.internalDaemons.path, FSURL.sysGroup.path, FSURL.systemData.path]
        let blockedPrefixes = ["/System/", "/usr/", "/bin/", "/sbin/", "/dev/", "/etc/",
                               "/var/db/", "/var/root/", "/private/var/db/", "/private/var/root/"]
        guard !protected.contains(canonical),
              !blockedPrefixes.contains(where: { canonical.hasPrefix($0) }),
              !canonical.hasPrefix(base.standardizedFileURL.path + "/"),
              canonical != base.standardizedFileURL.path,
              !canonical.hasPrefix(Bundle.main.bundleURL.standardizedFileURL.path + "/"),
              canonical != Bundle.main.bundleURL.standardizedFileURL.path,
              canonical.lowercased().hasSuffix("/com.apple.mobilegestalt.plist") == false else {
            return false
        }
        return fileManager.fileExists(atPath: canonical)
    }

    @discardableResult
    func moveToTrash(_ url: URL) throws -> NoxTrashEntry {
        guard canTrash(url) else { throw failure("This location cannot be moved to NoxTrash.") }
        let source = url.standardizedFileURL
        requestWriteAccessIfEligible(to: source.deletingLastPathComponent())
        let identifier = UUID()
        let name = source.lastPathComponent
        let storage = itemsDirectory.appendingPathComponent(identifier.uuidString, isDirectory: true)
        let destination = storage.appendingPathComponent(name)
        var isDirectory: ObjCBool = false
        guard fileManager.fileExists(atPath: source.path, isDirectory: &isDirectory) else {
            throw failure("The source no longer exists.")
        }
        try fileManager.createDirectory(at: storage, withIntermediateDirectories: true)
        do {
            try fileManager.moveItem(at: source, to: destination)
        } catch {
            try? fileManager.removeItem(at: storage)
            throw error
        }
        let item = NoxTrashEntry(id: identifier, originalPath: source.path, storedName: name,
                                 deletedAt: Date(), wasDirectory: isDirectory.boolValue)
        let updated = [item] + entries
        do {
            try persist(updated)
            entries = updated
            return item
        } catch {
            // Metadata is essential for a reliable restore. Undo the move if it wasn't saved.
            // Keep the preserved file if moving it back also fails.
            if (try? fileManager.moveItem(at: destination, to: source)) != nil {
                try? fileManager.removeItem(at: storage)
            }
            throw error
        }
    }

    func restore(_ item: NoxTrashEntry) throws {
        guard entries.contains(where: { $0.id == item.id }) else { throw failure("Trash record not found.") }
        let source = storedURL(for: item)
        let destination = URL(fileURLWithPath: item.originalPath)
        requestWriteAccessIfEligible(to: destination.deletingLastPathComponent())
        guard fileManager.fileExists(atPath: source.path) else { throw failure("Stored file is missing.") }
        guard !fileManager.fileExists(atPath: destination.path) else {
            throw failure("A file or folder already exists at the original location. Rename or move it first.")
        }
        guard fileManager.fileExists(atPath: destination.deletingLastPathComponent().path) else {
            throw failure("Original parent folder no longer exists.")
        }
        try fileManager.moveItem(at: source, to: destination)
        let updated = entries.filter { $0.id != item.id }
        do {
            try persist(updated)
            entries = updated
            try? fileManager.removeItem(at: itemsDirectory.appendingPathComponent(item.id.uuidString))
        } catch {
            try? fileManager.moveItem(at: destination, to: source)
            throw error
        }
    }

    func permanentlyDelete(_ item: NoxTrashEntry) throws {
        guard entries.contains(where: { $0.id == item.id }) else { return }
        let storage = itemsDirectory.appendingPathComponent(item.id.uuidString, isDirectory: true)
        // Remove the stored data first; retain metadata if deletion failed.
        if fileManager.fileExists(atPath: storage.path) {
            try fileManager.removeItem(at: storage)
        }
        let updated = entries.filter { $0.id != item.id }
        try persist(updated)
        entries = updated
    }

    func restore(matching identifier: String) throws -> NoxTrashEntry {
        let matches = entries.filter { $0.id.uuidString.lowercased().hasPrefix(identifier.lowercased()) }
        guard matches.count == 1, let item = matches.first else {
            throw failure(matches.isEmpty ? "No matching trash item." : "Ambiguous ID; use a longer prefix.")
        }
        try restore(item)
        return item
    }

    func empty() throws {
        for item in Array(entries) { try permanentlyDelete(item) }
    }

    private func requestWriteAccessIfEligible(to folder: URL) {
        guard !fileManager.isWritableFile(atPath: folder.path) else { return }
        let path = FMNavigationStore.canonicalPath(folder.path)
        let supportedRoots = [FSPaths.appContainers, FSURL.appPlugins.path, FSURL.appGroup.path,
                              FSURL.internalDaemons.path, FSURL.sysGroup.path, FSURL.systemData.path]
        guard supportedRoots.contains(where: { path == $0 || path.hasPrefix($0 + "/") }) else { return }
        _ = wq.grantAccess(path: path, requireWrite: true)
        // Grants are intentionally retained in wq's managed handle cache for subsequent
        // file operations. A failed grant does not bypass FileManager's actual checks.
    }

    private func storedURL(for item: NoxTrashEntry) -> URL {
        itemsDirectory.appendingPathComponent(item.id.uuidString, isDirectory: true)
            .appendingPathComponent(item.storedName)
    }

    private func persist(_ list: [NoxTrashEntry]) throws {
        try fileManager.createDirectory(at: base, withIntermediateDirectories: true)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(list).write(to: indexURL, options: .atomic)
    }

    private func failure(_ message: String) -> NSError {
        NSError(domain: "NOXERRA.NoxTrash", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
}

struct NoxTrashView: View {
    @EnvironmentObject private var mgr: ErosionManager
    @ObservedObject private var trash = NoxTrash.shared
    @State private var pendingRemoval: NoxTrashEntry?
    @State private var showStorageWarning = false
    @State private var confirmEmpty = false
    @State private var errorMessage: String?

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 7) {
                    Label("NOXTRASH", systemImage: "trash.slash.fill")
                        .font(.headline.weight(.black)).foregroundStyle(NoxStyle.accent)
                    Text("Deleted items are stored inside NOXERRA until you restore or permanently remove them.")
                        .font(.caption).foregroundStyle(NoxStyle.pale)
                    Text("App-managed trash only · never an iOS-wide recycle bin")
                        .font(.caption2).foregroundStyle(.secondary)
                }.padding(.vertical, 6)
            }
            Section {
                Button {
                    showStorageWarning = true
                } label: {
                    Label("Warning: Uninstalling NOXERRA deletes all NoxTrash data", systemImage: "exclamationmark.triangle.fill")
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.orange)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .buttonStyle(.plain)
            }
            if trash.entries.isEmpty {
                Section {
                    ContentUnavailableView("Trash is empty", systemImage: "trash", description: Text("Files moved to NoxTrash will appear here."))
                }
            } else {
                Section("RECOVERABLE ITEMS · \(trash.entries.count)") {
                    ForEach(trash.entries) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            Label(item.displayName, systemImage: item.wasDirectory ? "folder.fill" : "doc.fill")
                                .font(.subheadline.weight(.semibold))
                            Text(item.originalPath).font(.caption2.monospaced())
                                .foregroundStyle(.secondary).lineLimit(2).truncationMode(.middle)
                            Text(item.deletedAt, format: .dateTime.month().day().year().hour().minute())
                                .font(.caption2).foregroundStyle(NoxStyle.pale)
                            HStack {
                                Button("Restore", systemImage: "arrow.uturn.backward") {
                                    do { try trash.restore(item); mgr.refreshFiles.toggle() }
                                    catch { errorMessage = error.localizedDescription }
                                }.buttonStyle(.borderedProminent).tint(NoxStyle.violet)
                                Button(role: .destructive) {
                                    pendingRemoval = item
                                } label: {
                                    Label("Delete Forever", systemImage: "xmark.bin")
                                }.buttonStyle(.bordered)
                            }
                            .font(.caption)
                        }.padding(.vertical, 7)
                    }
                }
            }
        }
        .scrollContentBackground(.hidden)
        .background(NoxStyle.background)
        .navigationTitle("NoxTrash")
        .toolbar {
            if !trash.entries.isEmpty {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Empty", role: .destructive) { confirmEmpty = true }
                }
            }
        }
        .alert("NoxTrash is app-local", isPresented: $showStorageWarning) {
            Button("Understood", role: .cancel) {}
        } message: {
            Text(NoxTrash.storageWarning)
        }
        .confirmationDialog("Delete this item permanently?", isPresented: Binding(
            get: { pendingRemoval != nil },
            set: { if !$0 { pendingRemoval = nil } }
        )) {
            Button("Delete Forever", role: .destructive) {
                if let item = pendingRemoval {
                    do { try trash.permanentlyDelete(item) }
                    catch { errorMessage = error.localizedDescription }
                }
                pendingRemoval = nil
            }
        } message: { Text("This cannot be undone.") }
        .confirmationDialog("Empty NoxTrash permanently?", isPresented: $confirmEmpty) {
            Button("Empty Trash", role: .destructive) {
                do { try trash.empty() } catch { errorMessage = error.localizedDescription }
            }
        } message: { Text("Every stored item will be permanently removed.") }
        .alert("File operation failed", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) { Button("OK", role: .cancel) { errorMessage = nil } }
        message: { Text(errorMessage ?? "Unknown error") }
    }
}
